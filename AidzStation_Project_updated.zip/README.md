# AidzStation - PSX Emulator for Android

AidzStation is a high-performance PlayStation 1 (PSX) emulator for Android built using **Jetpack Compose**, **Material 3**, and the **PCSX-ReARMed** Libretro core via dynamic native JNA bindings.

## Features
- **4x Internal Resolution / Enhanced Resolution:** High-definition 3D rendering with smooth texture rendering.
- **Game Library Manager:** Automatic multi-disc handling, true disc size detection, and filtering of non-game/BIOS files.
- **Libretro Box Art Scraping:** Direct matching and caching of authentic PS1 front covers.
- **Integrated Touch Gamepad:** Responsive virtual PS1 controller with haptic feedback, customizable layout, and landscape/portrait modes.
- **Save & Load States:** Thread-safe serialization with integrity checks and multi-slot support.
- **Audio & SPU:** Low-latency PCM audio streaming via AudioTrack.
- **BIOS Management:** SCPH-1001, SCPH-5500, SCPH-7001 detection and automatic routing.

## Project Structure
- `app/src/main/java/com/example/psx/core/`: Native Libretro bridge (`LibretroBridge.kt`), JNA API definitions, and emulator engine (`PsxEmulatorEngine.kt`).
- `app/src/main/java/com/example/psx/ui/`: Jetpack Compose UI screens (Game Library, Emulation Screen, Settings, BIOS Manager).
- `app/src/main/java/com/example/psx/audio/`: Audio stream sink and PCM buffer management.
- `app/src/main/java/com/example/psx/input/`: Virtual controller touch mappings and key code translators.
- `app/src/main/jniLibs/`: Precompiled PCSX-ReARMed native shared libraries (`arm64-v8a`, `armeabi-v7a`, `x86_64`).

## Building with Android Studio
1. Open Android Studio (Ladybug / Hedgehog or newer recommended).
2. Select **Open** and choose this project directory.
3. Allow Gradle to sync.
4. Select `app` run configuration and click **Run** (or execute `./gradlew assembleDebug` from the terminal).

## Building from Command Line
```bash
# On Linux/macOS
./gradlew assembleDebug

# On Windows
gradlew.bat assembleDebug
```
The output APK will be located at:
`app/build/outputs/apk/debug/app-debug.apk`
