package com.example.psx.ui.screens

import android.view.SurfaceHolder
import android.view.SurfaceView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.psx.core.PsxEmulatorEngine
import com.example.psx.ui.components.EmulationMenuDialog
import com.example.psx.ui.components.TouchControllerOverlay
import com.example.psx.ui.theme.*

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material3.Icon
import androidx.compose.ui.draw.clip
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

@Composable
fun EmulationScreen(
    engine: PsxEmulatorEngine,
    onExitGame: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showMenu by remember { mutableStateOf(false) }
    var showEditControls by remember { mutableStateOf(false) }

    val fps by engine.fps.collectAsStateWithLifecycle()
    val isPaused by engine.isPaused.collectAsStateWithLifecycle()
    val gameTitle by engine.currentGameTitle.collectAsStateWithLifecycle()
    val recentUnlock by engine.retroAchievements.recentlyUnlocked.collectAsStateWithLifecycle()

    LaunchedEffect(recentUnlock) {
        if (recentUnlock != null) {
            delay(4500)
            engine.retroAchievements.dismissRecentlyUnlocked()
        }
    }

    BackHandler {
        engine.pause()
        showMenu = true
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("emulation_screen")
    ) {
        // Hardware Accelerated SurfaceView Layer (Direct SurfaceFlinger pipeline, 0 UI thread load)
        AndroidView(
            factory = { ctx ->
                SurfaceView(ctx).apply {
                    keepScreenOn = true
                    isFocusable = false
                    isClickable = false
                    setOnTouchListener { _, _ -> false }
                    holder.addCallback(object : SurfaceHolder.Callback {
                        override fun surfaceCreated(holder: SurfaceHolder) {
                            engine.setRenderSurface(holder)
                        }
                        override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
                            // Aspect ratio and destination rect are handled dynamically on draw
                        }
                        override fun surfaceDestroyed(holder: SurfaceHolder) {
                            engine.setRenderSurface(null)
                        }
                    })
                }
            },
            modifier = Modifier
                .fillMaxSize()
                .testTag("emulated_video_display")
        )

        // Minimal OSD HUD Bar at Top
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
                .align(Alignment.TopCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "$gameTitle",
                color = PsxTextSecondary.copy(alpha = 0.7f),
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )

            if (engine.config.showFpsCounter) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (isPaused) "PAUSED" else "%.1f FPS".format(fps),
                        color = if (isPaused) PsxYellowAccent else PsxTriangleGreen,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "NTSC",
                        color = PsxTextDisabled,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // On-screen Touch Controls Overlay
        TouchControllerOverlay(
            controllerState = engine.controllerState,
            config = engine.config,
            onMenuClick = {
                engine.pause()
                showMenu = true
            },
            modifier = Modifier.fillMaxSize()
        )

        // In-game Pause/Quick Menu
        if (showMenu) {
            EmulationMenuDialog(
                engine = engine,
                onDismiss = {
                    showMenu = false
                    engine.resume()
                },
                onExitGame = {
                    showMenu = false
                    engine.stop()
                    onExitGame()
                },
                onEditControls = {
                    showMenu = false
                    showEditControls = true
                }
            )
        }

        if (showEditControls) {
            EditControlsLayoutScreen(
                onDismiss = {
                    showEditControls = false
                    engine.resume()
                }
            )
        }

        // RetroAchievements Unlock Toast Notification
        AnimatedVisibility(
            visible = recentUnlock != null,
            enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 28.dp, start = 16.dp, end = 16.dp)
        ) {
            recentUnlock?.let { unlock ->
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(PsxSurfaceDark.copy(alpha = 0.95f))
                        .border(2.dp, PsxYellowAccent, RoundedCornerShape(12.dp))
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(PsxYellowAccent.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (unlock.badgeUrl.isNotBlank()) {
                            AsyncImage(
                                model = unlock.badgeUrl,
                                contentDescription = unlock.title,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = androidx.compose.ui.layout.ContentScale.Crop
                            )
                        } else {
                            Icon(
                                Icons.Default.EmojiEvents,
                                contentDescription = null,
                                tint = PsxYellowAccent,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "ACHIEVEMENT UNLOCKED!",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                color = PsxYellowAccent,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "+${unlock.points} pts",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = PsxTriangleGreen
                            )
                        }
                        Text(
                            text = unlock.title,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = PsxTextPrimary
                        )
                    }
                }
            }
        }
    }
}
