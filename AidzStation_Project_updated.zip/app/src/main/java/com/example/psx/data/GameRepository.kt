package com.example.psx.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.DecimalFormat

class GameRepository(private val context: Context) {
    companion object {
        private const val TAG = "GameRepository"
        private const val PREFS_GAMES = "psx_imported_games"
        private const val PREF_SOURCE_FOLDER_URI = "source_folder_uri"
        private const val PREF_SOURCE_FOLDER_NAME = "source_folder_name"
    }

    private val repositoryScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    val gamesDir = File(context.filesDir, "games").apply { mkdirs() }
    val biosDir = File(context.filesDir, "bios").apply { mkdirs() }
    val memoryCardDir = File(context.filesDir, "memorycards").apply { mkdirs() }

    private val _games = MutableStateFlow<List<GameItem>>(emptyList())
    val games: StateFlow<List<GameItem>> = _games.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _scanStatus = MutableStateFlow("")
    val scanStatus: StateFlow<String> = _scanStatus.asStateFlow()

    private val _sourceFolderName = MutableStateFlow<String?>(null)
    val sourceFolderName: StateFlow<String?> = _sourceFolderName.asStateFlow()

    init {
        val prefs = context.getSharedPreferences(PREFS_GAMES, Context.MODE_PRIVATE)
        _sourceFolderName.value = prefs.getString(PREF_SOURCE_FOLDER_NAME, null)

        // Clean out any non-game files (BIOS, memory cards) that were accidentally imported previously
        cleanStoredNonGameFiles()
        loadGames()

        // If a source folder was previously selected, automatically rescan in background
        val savedFolderUriStr = prefs.getString(PREF_SOURCE_FOLDER_URI, null)
        if (savedFolderUriStr != null) {
            try {
                val uri = Uri.parse(savedFolderUriStr)
                repositoryScope.launch {
                    scanDocumentFolder(uri, isAutomatic = true)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Could not auto-rescan saved folder: ${e.message}")
            }
        }
    }

    /**
     * Checks if a file is a BIOS dump or firmware, which must NEVER be shown in the Game Library.
     */
    fun isBiosFile(file: File): Boolean {
        val name = file.name.lowercase()
        val ext = file.extension.lowercase()

        // Common PS1 BIOS names
        if (name.contains("scph") || name.contains("dtl-") || name.contains("dtlh") ||
            name.startsWith("ps-") || name.contains("bios") || name.contains("ps1_rom") ||
            name.contains("psxonpsp")
        ) {
            return true
        }

        // Exact PS1 BIOS sizes: 512 KB (524,288 bytes), 256 KB, 1 MB with .bin or .rom extension
        if (ext in listOf("bin", "rom", "dat")) {
            val len = file.length()
            if (len == 524288L || len == 262144L || len == 1048576L) {
                return true
            }
        }

        return false
    }

    /**
     * Checks if a file is a Memory Card or save state.
     */
    fun isMemoryCardOrSaveFile(file: File): Boolean {
        val name = file.name.lowercase()
        val ext = file.extension.lowercase()
        if (ext in listOf("mcd", "mcr", "srm", "sav") || ext.startsWith("state") ||
            name.contains("memcard") || name.contains("memorycard")
        ) {
            return true
        }
        if (file.length() == 131072L && (ext == "bin" || ext == "mcd" || ext == "mcr")) {
            return true
        }
        return false
    }

    /**
     * Identifies any file that is definitively NOT a playable PS1 game.
     */
    fun isNonGameFile(file: File): Boolean {
        if (!file.exists()) return true
        if (isBiosFile(file)) return true
        if (isMemoryCardOrSaveFile(file)) return true

        val ext = file.extension.lowercase()
        if (ext in listOf("txt", "nfo", "pdf", "doc", "zip", "rar", "7z", "ips", "bps", "ppf", "cht", "png", "jpg", "jpeg")) {
            return true
        }

        // A raw .bin file with no .cue and size under 3 MB is never a real PS1 CD-ROM game
        if (ext == "bin" && file.length() < 3 * 1024 * 1024L) {
            return true
        }

        return false
    }

    /**
     * Cleans up stored non-game files: moves BIOS files to biosDir so BIOS Manager recognizes them,
     * moves memory card files to memoryCardDir, and removes them from gamesDir and stored preferences.
     */
    fun cleanStoredNonGameFiles() {
        try {
            val prefs = context.getSharedPreferences(PREFS_GAMES, Context.MODE_PRIVATE)
            val savedPaths = prefs.getStringSet("paths", emptySet())?.toMutableSet() ?: mutableSetOf()
            val pathsToRemove = mutableSetOf<String>()

            gamesDir.listFiles()?.forEach { file ->
                if (isBiosFile(file)) {
                    val target = File(biosDir, file.name)
                    if (!target.exists()) {
                        file.copyTo(target, overwrite = true)
                    }
                    file.delete()
                    pathsToRemove.add(file.absolutePath)
                } else if (isMemoryCardOrSaveFile(file)) {
                    val target = File(memoryCardDir, file.name)
                    if (!target.exists()) {
                        file.copyTo(target, overwrite = true)
                    }
                    file.delete()
                    pathsToRemove.add(file.absolutePath)
                } else if (isNonGameFile(file)) {
                    file.delete()
                    pathsToRemove.add(file.absolutePath)
                }
            }

            for (path in savedPaths) {
                val f = File(path)
                if (isNonGameFile(f)) {
                    pathsToRemove.add(path)
                }
            }

            if (pathsToRemove.isNotEmpty()) {
                savedPaths.removeAll(pathsToRemove)
                prefs.edit().putStringSet("paths", savedPaths).apply()
                Log.i(TAG, "Purged ${pathsToRemove.size} non-game/BIOS files from library")
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error cleaning stored files: ${e.message}")
        }
    }

    /**
     * Reads all available files and resolves ONLY actual games.
     */
    fun loadGames() {
        val list = mutableListOf<GameItem>()

        // 1. Built-in interactive 3D demo
        list.add(
            GameItem(
                id = "builtin_demo_01",
                title = "PlayStation 3D Polygonal & SPU Demo",
                file = null,
                format = GameDiscFormat.DEMO,
                discNumber = 1,
                totalDiscs = 1,
                fileSizeFormatted = "Interactive Demo",
                lastPlayedTime = System.currentTimeMillis(),
                isFavorite = true,
                isBuiltIn = true
            )
        )

        // 2. Collect all candidate files from games directory and imported paths
        val candidateFiles = mutableListOf<File>()
        gamesDir.listFiles()?.forEach { candidateFiles.add(it) }

        val prefs = context.getSharedPreferences(PREFS_GAMES, Context.MODE_PRIVATE)
        val savedPaths = prefs.getStringSet("paths", emptySet()) ?: emptySet()
        for (path in savedPaths) {
            val f = File(path)
            if (f.exists() && candidateFiles.none { it.absolutePath == f.absolutePath }) {
                candidateFiles.add(f)
            }
        }

        // Filter out non-game files and resolve actual games
        val resolvedGames = resolveActualGames(candidateFiles)
        list.addAll(resolvedGames)

        _games.value = list

        // Auto fetch box art for games that don't have a cached cover
        repositoryScope.launch {
            list.filter { !it.isBuiltIn && it.coverPath == null }.forEach { game ->
                triggerAutoBoxArt(game)
            }
        }
    }

    /**
     * Resolves a list of files into ONLY actual games.
     * When both a .cue and .bin exist, or multiple tracks (Track 1, Track 2),
     * only the primary game launcher (.cue, .m3u, .chd, .iso, .pbp) is included.
     * All BIOS files, memory cards, and secondary tracks are completely excluded.
     */
    private fun resolveActualGames(allFiles: List<File>): List<GameItem> {
        val nonAuxFiles = allFiles.filter { file ->
            val ext = file.extension.lowercase()
            ext in listOf("cue", "m3u", "chd", "iso", "pbp", "bin", "img") && !isNonGameFile(file)
        }

        // 1. Find all tracks and subsidiary files referenced by .cue and .m3u
        val subsidiaryFilePaths = mutableSetOf<String>()
        val cueFiles = nonAuxFiles.filter { it.extension.equals("cue", ignoreCase = true) }
        val m3uFiles = nonAuxFiles.filter { it.extension.equals("m3u", ignoreCase = true) }

        for (cue in cueFiles) {
            try {
                cue.forEachLine { line ->
                    val trimmed = line.trim()
                    if (trimmed.startsWith("FILE", ignoreCase = true)) {
                        val firstQuote = trimmed.indexOf('"')
                        val lastQuote = trimmed.lastIndexOf('"')
                        if (firstQuote != -1 && lastQuote > firstQuote) {
                            val referencedName = trimmed.substring(firstQuote + 1, lastQuote)
                            val referencedFile = File(cue.parentFile, referencedName)
                            subsidiaryFilePaths.add(referencedFile.absolutePath)
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error reading cue sheet ${cue.name}: ${e.message}")
            }

            // Also mark any companion .bin with matching base name as subsidiary
            val base = cue.nameWithoutExtension.lowercase()
            for (f in nonAuxFiles) {
                if (f.extension.equals("bin", ignoreCase = true)) {
                    val fBase = f.nameWithoutExtension.lowercase()
                    if (fBase == base || fBase.startsWith("$base (track") || fBase.startsWith("${base}_track") || fBase.startsWith("$base ")) {
                        subsidiaryFilePaths.add(f.absolutePath)
                    }
                }
            }
        }

        for (m3u in m3uFiles) {
            try {
                m3u.forEachLine { line ->
                    val trimmed = line.trim()
                    if (trimmed.isNotEmpty() && !trimmed.startsWith("#")) {
                        val ref = File(m3u.parentFile, trimmed)
                        subsidiaryFilePaths.add(ref.absolutePath)
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error reading m3u ${m3u.name}: ${e.message}")
            }
        }

        // Secondary track bin files like "Game (Track 2).bin", "Game (Track 02).bin"
        val trackPattern = Regex("(?i)\\btrack\\s*0*[2-9]\\d*\\b")
        for (f in nonAuxFiles) {
            if (trackPattern.containsMatchIn(f.nameWithoutExtension)) {
                subsidiaryFilePaths.add(f.absolutePath)
            }
        }

        val gameItems = mutableListOf<GameItem>()

        for (file in nonAuxFiles) {
            // Skip subsidiary files so they are not displayed as separate games
            if (subsidiaryFilePaths.contains(file.absolutePath)) {
                continue
            }

            val item = parseGameFile(file, nonAuxFiles)
            if (item != null) {
                gameItems.add(item)
            }
        }

        return gameItems
    }

    fun addGameFile(file: File): GameItem? {
        if (isNonGameFile(file)) {
            if (isBiosFile(file)) {
                file.copyTo(File(biosDir, file.name), overwrite = true)
            }
            return null
        }

        val item = parseGameFile(file, emptyList()) ?: return null

        val prefs = context.getSharedPreferences(PREFS_GAMES, Context.MODE_PRIVATE)
        val savedPaths = prefs.getStringSet("paths", emptySet())?.toMutableSet() ?: mutableSetOf()
        savedPaths.add(file.absolutePath)
        prefs.edit().putStringSet("paths", savedPaths).apply()

        // Reload to apply deduplication across all files
        loadGames()

        // Trigger box art for newly added game
        triggerAutoBoxArt(item)
        return item
    }

    fun removeGame(item: GameItem) {
        val current = _games.value.toMutableList()
        current.removeAll { it.id == item.id }
        _games.value = current

        item.file?.let { f ->
            val prefs = context.getSharedPreferences(PREFS_GAMES, Context.MODE_PRIVATE)
            val savedPaths = prefs.getStringSet("paths", emptySet())?.toMutableSet() ?: mutableSetOf()
            savedPaths.remove(f.absolutePath)
            prefs.edit().putStringSet("paths", savedPaths).apply()

            if (f.parentFile?.absolutePath == gamesDir.absolutePath) {
                try { f.delete() } catch (e: Exception) { Log.w(TAG, "Failed to delete file: ${e.message}") }
            }
        }
    }

    suspend fun setAndScanSourceFolder(treeUri: Uri): Int {
        try {
            val takeFlags: Int = Intent.FLAG_GRANT_READ_URI_PERMISSION
            context.contentResolver.takePersistableUriPermission(treeUri, takeFlags)
        } catch (e: Exception) {
            Log.w(TAG, "Persistable permission could not be taken: ${e.message}")
        }

        val docFile = DocumentFile.fromTreeUri(context, treeUri)
        val folderName = docFile?.name ?: "Selected Folder"

        val prefs = context.getSharedPreferences(PREFS_GAMES, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(PREF_SOURCE_FOLDER_URI, treeUri.toString())
            .putString(PREF_SOURCE_FOLDER_NAME, folderName)
            .apply()

        _sourceFolderName.value = folderName
        return scanDocumentFolder(treeUri, isAutomatic = false)
    }

    /**
     * Recursively scan a DocumentFile tree for PS1 games.
     * Automatically filters out and redirects BIOS files to biosDir.
     */
    suspend fun scanDocumentFolder(treeUri: Uri, isAutomatic: Boolean = false): Int = withContext(Dispatchers.IO) {
        _isScanning.value = true
        _scanStatus.value = "Scanning for PlayStation games..."
        var foundCount = 0

        try {
            val rootDoc = DocumentFile.fromTreeUri(context, treeUri)
            if (rootDoc == null || !rootDoc.exists()) {
                _scanStatus.value = "Source folder not accessible"
                return@withContext 0
            }

            val queue = ArrayDeque<DocumentFile>()
            queue.add(rootDoc)
            var depth = 0

            while (queue.isNotEmpty() && depth < 200) {
                depth++
                val currentDir: DocumentFile = queue.removeFirst()
                val files: Array<DocumentFile> = currentDir.listFiles()

                for (doc in files) {
                    if (doc.isDirectory) {
                        queue.add(doc)
                    } else if (doc.isFile) {
                        val name = doc.name ?: continue
                        val ext = name.substringAfterLast('.', "").lowercase()

                        // Check if file is a BIOS dump
                        val isBios = name.lowercase().contains("scph") ||
                            name.lowercase().contains("dtl-") ||
                            name.lowercase().contains("bios") ||
                            doc.length() == 524288L

                        if (isBios) {
                            val targetBios = File(biosDir, name)
                            if (!targetBios.exists()) {
                                try {
                                    context.contentResolver.openInputStream(doc.uri)?.use { inStream ->
                                        FileOutputStream(targetBios).use { outStream ->
                                            inStream.copyTo(outStream)
                                        }
                                    }
                                } catch (e: Exception) {
                                    Log.w(TAG, "Failed copying BIOS ${doc.name}: ${e.message}")
                                }
                            }
                            continue // Do NOT copy or import BIOS into gamesDir!
                        }

                        if (ext in listOf("cue", "bin", "chd", "iso", "pbp", "m3u", "img")) {
                            _scanStatus.value = "Importing $name..."

                            val targetFile = File(gamesDir, name)
                            if (!targetFile.exists() || targetFile.length() != doc.length()) {
                                try {
                                    context.contentResolver.openInputStream(doc.uri)?.use { inStream ->
                                        FileOutputStream(targetFile).use { outStream ->
                                            inStream.copyTo(outStream)
                                        }
                                    }
                                } catch (e: Exception) {
                                    Log.e(TAG, "Failed copying ${doc.name}: ${e.message}")
                                }
                            }

                            if (targetFile.exists() && targetFile.length() > 0) {
                                foundCount++
                            }
                        }
                    }
                }
            }

            cleanStoredNonGameFiles()

            // Reload games and apply deduplication so only actual games appear
            withContext(Dispatchers.Main) {
                loadGames()
            }

            val actualGameCount = _games.value.filter { !it.isBuiltIn }.size
            _scanStatus.value = "Scan complete: $actualGameCount game(s) ready"
        } catch (e: Exception) {
            Log.e(TAG, "Folder scan error: ${e.message}", e)
            _scanStatus.value = "Scan encountered an error: ${e.message}"
        } finally {
            _isScanning.value = false
        }

        foundCount
    }

    /**
     * Resets and refreshes the entire game library:
     * 1. Cleans out non-game files and BIOSes from gamesDir
     * 2. Rescans the active source folder if configured
     * 3. Purges corrupted cover placeholders and re-fetches official box arts
     */
    suspend fun refreshGameLibrary(): Int = withContext(Dispatchers.IO) {
        cleanStoredNonGameFiles()

        val prefs = context.getSharedPreferences(PREFS_GAMES, Context.MODE_PRIVATE)
        val savedFolderUriStr = prefs.getString(PREF_SOURCE_FOLDER_URI, null)
        if (savedFolderUriStr != null) {
            try {
                val uri = Uri.parse(savedFolderUriStr)
                scanDocumentFolder(uri, isAutomatic = true)
            } catch (e: Exception) {
                Log.w(TAG, "Could not rescan saved folder: ${e.message}")
            }
        }

        withContext(Dispatchers.Main) {
            loadGames()
        }

        refreshAllBoxArts()
        _games.value.filter { !it.isBuiltIn }.size
    }

    /**
     * Automatically pulls box art from the internet in the background.
     */
    fun triggerAutoBoxArt(item: GameItem) {
        if (item.isBuiltIn) return

        repositoryScope.launch {
            try {
                val coverPath = BoxArtFetcher.fetchBoxArt(context, item.id, item.title)
                if (coverPath != null) {
                    updateGameCover(item.id, coverPath)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Failed to auto-fetch box art for ${item.title}: ${e.message}")
            }
        }
    }

    suspend fun manualFetchBoxArt(game: GameItem, overrideTitle: String? = null): Boolean = withContext(Dispatchers.IO) {
        val queryTitle = overrideTitle?.ifBlank { null } ?: game.title
        val path = BoxArtFetcher.fetchBoxArt(context, game.id, queryTitle)
        if (path != null) {
            updateGameCover(game.id, path)
            true
        } else {
            false
        }
    }

    suspend fun setCustomBoxArt(game: GameItem, imageUri: Uri): Boolean = withContext(Dispatchers.IO) {
        val path = BoxArtFetcher.saveCustomCover(context, game.id, imageUri)
        if (path != null) {
            updateGameCover(game.id, path)
            true
        } else {
            false
        }
    }

    suspend fun setCustomBoxArtFromUrl(game: GameItem, imageUrl: String): Boolean = withContext(Dispatchers.IO) {
        val path = BoxArtFetcher.saveCustomCoverFromUrl(context, game.id, imageUrl)
        if (path != null) {
            updateGameCover(game.id, path)
            true
        } else {
            false
        }
    }

    fun refreshAllBoxArts() {
        repositoryScope.launch {
            val nonBuiltIn = _games.value.filter { !it.isBuiltIn }
            for (game in nonBuiltIn) {
                val path = BoxArtFetcher.fetchBoxArt(context, game.id, game.title)
                if (path != null) {
                    updateGameCover(game.id, path)
                }
            }
        }
    }

    private fun updateGameCover(gameId: String, coverPath: String) {
        val updated = _games.value.map {
            if (it.id == gameId) it.copy(coverPath = coverPath) else it
        }
        _games.value = updated
    }

    private fun parseGameFile(file: File, allAvailableFiles: List<File>): GameItem? {
        if (isNonGameFile(file)) return null

        val ext = file.extension.lowercase()
        val format = when (ext) {
            "cue" -> GameDiscFormat.CUE
            "chd" -> GameDiscFormat.CHD
            "iso" -> GameDiscFormat.ISO
            "pbp" -> GameDiscFormat.PBP
            "m3u" -> GameDiscFormat.M3U
            "bin" -> GameDiscFormat.BIN
            "img" -> GameDiscFormat.ISO
            else -> return null
        }

        // Clean user-facing display title
        var name = file.nameWithoutExtension
            .replace("_", " ")
            .replace(Regex("\\[.*?\\]"), "")
            .replace(Regex("(?i)\\(track\\s*\\d+\\)"), "")
            .replace(Regex("(?i)\\(disc\\s*(\\d+)\\)"), "Disc $1")
            .replace(Regex("\\s+"), " ")
            .trim()

        val cleanDisplayName = name.replace(Regex("(?i)\\s*\\((usa|europe|japan|australia|en,fr,de,es,it)\\)"), "").trim()

        // Calculate REAL game size:
        // If file is a .cue sheet (which is just a ~90 byte text index), determine the actual game size from its referenced .bin
        var calculatedBytes = file.length()
        if (ext == "cue") {
            var referencedBytes = 0L
            try {
                file.forEachLine { line ->
                    val trimmed = line.trim()
                    if (trimmed.startsWith("FILE", ignoreCase = true)) {
                        val firstQuote = trimmed.indexOf('"')
                        val lastQuote = trimmed.lastIndexOf('"')
                        if (firstQuote != -1 && lastQuote > firstQuote) {
                            val referencedName = trimmed.substring(firstQuote + 1, lastQuote)
                            val referencedFile = File(file.parentFile, referencedName)
                            if (referencedFile.exists()) {
                                referencedBytes += referencedFile.length()
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                // Ignore parse error
            }

            // Also check for matching base .bin in same folder
            if (referencedBytes == 0L) {
                val base = file.nameWithoutExtension.lowercase()
                file.parentFile?.listFiles()?.forEach { f ->
                    if (f.extension.equals("bin", ignoreCase = true) && f.nameWithoutExtension.lowercase().startsWith(base)) {
                        referencedBytes += f.length()
                    }
                }
            }

            if (referencedBytes > 0) {
                calculatedBytes = referencedBytes
            }
        }

        val sizeFormatted = formatFileSize(calculatedBytes)
        val cachedCover = BoxArtFetcher.getCachedCover(context, file.absolutePath)?.absolutePath

        return GameItem(
            id = file.absolutePath,
            title = if (cleanDisplayName.isNotBlank()) cleanDisplayName else file.nameWithoutExtension,
            file = file,
            format = format,
            fileSizeFormatted = sizeFormatted,
            lastPlayedTime = file.lastModified(),
            coverPath = cachedCover
        )
    }

    private fun formatFileSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB")
        val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
        return DecimalFormat("#,##0.#").format(bytes / Math.pow(1024.0, digitGroups.toDouble())) + " " + units[digitGroups]
    }
}
