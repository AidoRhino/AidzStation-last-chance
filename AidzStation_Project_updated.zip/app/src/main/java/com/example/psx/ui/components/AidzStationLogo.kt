package com.example.psx.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

// Official iconic 1994 PlayStation 4-color palette
val AidzRed = Color(0xFFE52421)
val AidzYellow = Color(0xFFFDB813)
val AidzGreen = Color(0xFF00A859)
val AidzBlue = Color(0xFF003791)

/**
 * Authentic vector canvas rendering of the AidzStation Logo in strict 1:1 aspect ratio.
 * Perfectly proportioned upright 'A' with true transparent cutout and horizontal perspective 'S'.
 * Guaranteed never to distort or stretch in any screen mode.
 */
@Composable
fun AidzStationLogo(
    modifier: Modifier = Modifier,
    size: Dp = 48.dp
) {
    Box(
        modifier = modifier
            .size(size)
            .aspectRatio(1f, matchHeightConstraintsFirst = true),
        contentAlignment = Alignment.Center
    ) {
        Canvas(
            modifier = Modifier
                .size(size)
                .aspectRatio(1f)
        ) {
            val dim = minOf(this.size.width, this.size.height)
            val ox = (this.size.width - dim) / 2f
            val oy = (this.size.height - dim) / 2f

            // 1. FLOOR PERSPECTIVE 'S' (Horizontal curves in Blue, Green & Yellow)
            // Bottom Blue sweep
            val blueBand = Path().apply {
                moveTo(ox + dim * 0.18f, oy + dim * 0.88f)
                cubicTo(
                    ox + dim * 0.35f, oy + dim * 0.96f,
                    ox + dim * 0.65f, oy + dim * 0.96f,
                    ox + dim * 0.82f, oy + dim * 0.88f
                )
                cubicTo(
                    ox + dim * 0.90f, oy + dim * 0.83f,
                    ox + dim * 0.82f, oy + dim * 0.77f,
                    ox + dim * 0.68f, oy + dim * 0.75f
                )
                cubicTo(
                    ox + dim * 0.50f, oy + dim * 0.73f,
                    ox + dim * 0.30f, oy + dim * 0.77f,
                    ox + dim * 0.18f, oy + dim * 0.88f
                )
                close()
            }
            drawPath(path = blueBand, color = AidzBlue, style = Fill)

            // Middle Green perspective curve
            val greenBand = Path().apply {
                moveTo(ox + dim * 0.24f, oy + dim * 0.78f)
                cubicTo(
                    ox + dim * 0.40f, oy + dim * 0.85f,
                    ox + dim * 0.68f, oy + dim * 0.85f,
                    ox + dim * 0.84f, oy + dim * 0.77f
                )
                cubicTo(
                    ox + dim * 0.90f, oy + dim * 0.71f,
                    ox + dim * 0.80f, oy + dim * 0.66f,
                    ox + dim * 0.64f, oy + dim * 0.64f
                )
                cubicTo(
                    ox + dim * 0.46f, oy + dim * 0.62f,
                    ox + dim * 0.32f, oy + dim * 0.67f,
                    ox + dim * 0.24f, oy + dim * 0.78f
                )
                close()
            }
            drawPath(path = greenBand, color = AidzGreen, style = Fill)

            // Yellow transition bend connecting S perspective to upright A
            val yellowBand = Path().apply {
                moveTo(ox + dim * 0.32f, oy + dim * 0.68f)
                cubicTo(
                    ox + dim * 0.46f, oy + dim * 0.73f,
                    ox + dim * 0.72f, oy + dim * 0.73f,
                    ox + dim * 0.82f, oy + dim * 0.66f
                )
                lineTo(ox + dim * 0.76f, oy + dim * 0.60f)
                cubicTo(
                    ox + dim * 0.64f, oy + dim * 0.65f,
                    ox + dim * 0.44f, oy + dim * 0.65f,
                    ox + dim * 0.32f, oy + dim * 0.60f
                )
                close()
            }
            drawPath(path = yellowBand, color = AidzYellow, style = Fill)

            // 2. UPRIGHT 'A' (Aidz) in Red with genuine hollow cutout
            val aBody = Path().apply {
                moveTo(ox + dim * 0.44f, oy + dim * 0.10f)
                lineTo(ox + dim * 0.56f, oy + dim * 0.10f)
                lineTo(ox + dim * 0.72f, oy + dim * 0.72f)
                lineTo(ox + dim * 0.58f, oy + dim * 0.72f)
                lineTo(ox + dim * 0.54f, oy + dim * 0.55f)
                lineTo(ox + dim * 0.44f, oy + dim * 0.55f)
                lineTo(ox + dim * 0.38f, oy + dim * 0.72f)
                lineTo(ox + dim * 0.24f, oy + dim * 0.72f)
                close()
            }

            // Triangular cutout (pointing UP)
            val aCutout = Path().apply {
                moveTo(ox + dim * 0.50f, oy + dim * 0.24f)
                lineTo(ox + dim * 0.56f, oy + dim * 0.45f)
                lineTo(ox + dim * 0.44f, oy + dim * 0.45f)
                close()
            }

            // Boolean subtraction produces true transparent hollow cutout inside 'A'
            val hollowA = Path()
            hollowA.op(aBody, aCutout, PathOperation.Difference)
            drawPath(path = hollowA, color = AidzRed, style = Fill)

            // 3D Isometric bevel edge on right of 'A' (in Yellow)
            val aDepth = Path().apply {
                moveTo(ox + dim * 0.56f, oy + dim * 0.10f)
                lineTo(ox + dim * 0.63f, oy + dim * 0.14f)
                lineTo(ox + dim * 0.78f, oy + dim * 0.73f)
                lineTo(ox + dim * 0.72f, oy + dim * 0.72f)
                close()
            }
            drawPath(path = aDepth, color = AidzYellow, style = Fill)

            // Horizontal crossbar highlight
            drawLine(
                color = AidzYellow,
                start = Offset(ox + dim * 0.43f, oy + dim * 0.52f),
                end = Offset(ox + dim * 0.55f, oy + dim * 0.52f),
                strokeWidth = dim * 0.04f,
                cap = StrokeCap.Round
            )
        }
    }
}
