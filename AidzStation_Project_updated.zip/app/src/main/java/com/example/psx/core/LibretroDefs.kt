package com.example.psx.core

import com.sun.jna.Callback
import com.sun.jna.Library
import com.sun.jna.NativeLong
import com.sun.jna.Pointer
import com.sun.jna.Structure
import com.sun.jna.Structure.FieldOrder

object LibretroDefs {
    const val RETRO_API_VERSION = 1

    const val RETRO_DEVICE_NONE = 0
    const val RETRO_DEVICE_JOYPAD = 1
    const val RETRO_DEVICE_MOUSE = 2
    const val RETRO_DEVICE_KEYBOARD = 3
    const val RETRO_DEVICE_LIGHTGUN = 4
    const val RETRO_DEVICE_ANALOG = 5
    const val RETRO_DEVICE_POINTER = 6

    const val RETRO_DEVICE_ID_JOYPAD_B = 0      // PS1 Cross (X)
    const val RETRO_DEVICE_ID_JOYPAD_Y = 1      // PS1 Square ([ ])
    const val RETRO_DEVICE_ID_JOYPAD_SELECT = 2 // PS1 Select
    const val RETRO_DEVICE_ID_JOYPAD_START = 3  // PS1 Start
    const val RETRO_DEVICE_ID_JOYPAD_UP = 4     // PS1 D-Pad Up
    const val RETRO_DEVICE_ID_JOYPAD_DOWN = 5   // PS1 D-Pad Down
    const val RETRO_DEVICE_ID_JOYPAD_LEFT = 6   // PS1 D-Pad Left
    const val RETRO_DEVICE_ID_JOYPAD_RIGHT = 7  // PS1 D-Pad Right
    const val RETRO_DEVICE_ID_JOYPAD_A = 8      // PS1 Circle (O)
    const val RETRO_DEVICE_ID_JOYPAD_X = 9      // PS1 Triangle (/_\)
    const val RETRO_DEVICE_ID_JOYPAD_L = 10     // PS1 L1
    const val RETRO_DEVICE_ID_JOYPAD_R = 11     // PS1 R1
    const val RETRO_DEVICE_ID_JOYPAD_L2 = 12    // PS1 L2
    const val RETRO_DEVICE_ID_JOYPAD_R2 = 13    // PS1 R2
    const val RETRO_DEVICE_ID_JOYPAD_L3 = 14    // PS1 L3
    const val RETRO_DEVICE_ID_JOYPAD_R3 = 15    // PS1 R3

    const val RETRO_DEVICE_INDEX_ANALOG_LEFT = 0
    const val RETRO_DEVICE_INDEX_ANALOG_RIGHT = 1
    const val RETRO_DEVICE_ID_ANALOG_X = 0
    const val RETRO_DEVICE_ID_ANALOG_Y = 1

    const val RETRO_PIXEL_FORMAT_0RGB1555 = 0
    const val RETRO_PIXEL_FORMAT_XRGB8888 = 1
    const val RETRO_PIXEL_FORMAT_RGB565 = 2

    const val RETRO_ENVIRONMENT_SET_ROTATION = 1
    const val RETRO_ENVIRONMENT_GET_OVERSCAN = 2
    const val RETRO_ENVIRONMENT_GET_CAN_DUPE = 3
    const val RETRO_ENVIRONMENT_SET_MESSAGE = 6
    const val RETRO_ENVIRONMENT_SHUTDOWN = 7
    const val RETRO_ENVIRONMENT_SET_PERFORMANCE_LEVEL = 8
    const val RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY = 9
    const val RETRO_ENVIRONMENT_SET_PIXEL_FORMAT = 10
    const val RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS = 11
    const val RETRO_ENVIRONMENT_GET_VARIABLE = 15
    const val RETRO_ENVIRONMENT_SET_VARIABLES = 16
    const val RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE = 17
    const val RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME = 18
    const val RETRO_ENVIRONMENT_GET_LOG_INTERFACE = 27
    const val RETRO_ENVIRONMENT_GET_CORE_ASSETS_DIRECTORY = 30
    const val RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY = 31
    const val RETRO_ENVIRONMENT_SET_GEOMETRY = 37

    const val RETRO_MEMORY_SAVE_RAM = 0 // PS1 Memory Card 1
    const val RETRO_MEMORY_RTC = 1
    const val RETRO_MEMORY_SYSTEM_RAM = 2
    const val RETRO_MEMORY_VIDEO_RAM = 3
}

@FieldOrder("library_name", "library_version", "valid_extensions", "need_fullpath", "block_extract")
open class RetroSystemInfo : Structure() {
    @JvmField var library_name: String? = null
    @JvmField var library_version: String? = null
    @JvmField var valid_extensions: String? = null
    @JvmField var need_fullpath: Boolean = false
    @JvmField var block_extract: Boolean = false
}

@FieldOrder("path", "data", "size", "meta")
open class RetroGameInfo : Structure() {
    @JvmField var path: String? = null
    @JvmField var data: Pointer? = null
    @JvmField var size: NativeLong = NativeLong(0)
    @JvmField var meta: String? = null

    class ByReference : RetroGameInfo(), Structure.ByReference
}

@FieldOrder("base_width", "base_height", "max_width", "max_height", "aspect_ratio")
open class RetroGameGeometry : Structure() {
    @JvmField var base_width: Int = 320
    @JvmField var base_height: Int = 240
    @JvmField var max_width: Int = 640
    @JvmField var max_height: Int = 480
    @JvmField var aspect_ratio: Float = 4f / 3f
}

@FieldOrder("fps", "sample_rate")
open class RetroSystemTiming : Structure() {
    @JvmField var fps: Double = 60.0
    @JvmField var sample_rate: Double = 44100.0
}

@FieldOrder("geometry", "timing")
open class RetroSystemAvInfo : Structure() {
    @JvmField var geometry: RetroGameGeometry = RetroGameGeometry()
    @JvmField var timing: RetroSystemTiming = RetroSystemTiming()
}

@FieldOrder("key", "value")
open class RetroVariable : Structure() {
    @JvmField var key: String? = null
    @JvmField var value: String? = null
}

fun interface RetroEnvironmentCallback : Callback {
    fun invoke(cmd: Int, data: Pointer?): Boolean
}

fun interface RetroVideoRefreshCallback : Callback {
    fun invoke(data: Pointer?, width: Int, height: Int, pitch: NativeLong)
}

fun interface RetroAudioSampleCallback : Callback {
    fun invoke(left: Short, right: Short)
}

fun interface RetroAudioSampleBatchCallback : Callback {
    fun invoke(data: Pointer?, frames: NativeLong): NativeLong
}

fun interface RetroInputPollCallback : Callback {
    fun invoke()
}

fun interface RetroInputStateCallback : Callback {
    fun invoke(port: Int, device: Int, index: Int, id: Int): Short
}

interface LibretroCoreApi : Library {
    fun retro_api_version(): Int
    fun retro_init()
    fun retro_deinit()
    fun retro_set_environment(cb: RetroEnvironmentCallback)
    fun retro_set_video_refresh(cb: RetroVideoRefreshCallback)
    fun retro_set_audio_sample(cb: RetroAudioSampleCallback)
    fun retro_set_audio_sample_batch(cb: RetroAudioSampleBatchCallback)
    fun retro_set_input_poll(cb: RetroInputPollCallback)
    fun retro_set_input_state(cb: RetroInputStateCallback)
    fun retro_set_controller_port_device(port: Int, device: Int)
    fun retro_reset()
    fun retro_run()
    fun retro_serialize_size(): NativeLong
    fun retro_serialize(data: Pointer?, size: NativeLong): Boolean
    fun retro_unserialize(data: Pointer?, size: NativeLong): Boolean
    fun retro_load_game(game: RetroGameInfo): Byte
    fun retro_unload_game()
    fun retro_get_memory_data(id: Int): Pointer?
    fun retro_get_memory_size(id: Int): NativeLong
    fun retro_get_system_info(info: RetroSystemInfo)
    fun retro_get_system_av_info(info: RetroSystemAvInfo)
}
