package com.example.psx.ui.theme

import androidx.compose.ui.graphics.Color

// Authentic PlayStation Blue & Heritage Palette
val PsxPlayStationBlue = Color(0xFF003791)
val PsxBlueDeep = Color(0xFF001940)
val PsxBlueMidnight = Color(0xFF001333)

val PsxNearBlack = Color(0xFF001333)       // Deep PlayStation Midnight Blue base
val PsxSurfaceDark = Color(0xFF001D4A)     // Rich PlayStation Deep Navy surface
val PsxCardSurface = Color(0xFF0A2B66)     // PlayStation Card Surface
val PsxCardElevated = Color(0xFF10367E)    // Elevated Card Blue
val PsxCardBorder = Color(0xFF224E9C)      // Subtle luminous Blue border

// Authentic Console Hardware Greys
val PsxConsoleGrey = Color(0xFF8B8B8B)
val PsxLightGrey = Color(0xFFB0B0B0)
val PsxDarkCharcoal = Color(0xFF0E2248)

// Iconic Four Button Colors & PS Heritage Accents
val PsxCrossBlue = Color(0xFF2979FF)
val PsxCircleRed = Color(0xFFFF1744)
val PsxSquarePink = Color(0xFFFF4081)
val PsxTriangleGreen = Color(0xFF00E676)
val PsxYellowAccent = Color(0xFFFFD600)

val PsxTextPrimary = Color(0xFFF4F7FC)
val PsxTextSecondary = Color(0xFFA5B8D8)
val PsxTextDisabled = Color(0xFF5A729E)
