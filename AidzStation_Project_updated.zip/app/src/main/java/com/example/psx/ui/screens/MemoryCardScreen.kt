package com.example.psx.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.psx.data.MemoryCardBlock
import com.example.psx.data.MemoryCardManager
import com.example.psx.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MemoryCardScreen(
    memoryCardManager: MemoryCardManager,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedSlot by remember { mutableIntStateOf(1) }
    var blocks by remember { mutableStateOf(memoryCardManager.getMemoryCardBlocks(selectedSlot)) }
    var actionMessage by remember { mutableStateOf<String?>(null) }

    BackHandler {
        onBack()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "PLAYSTATION MEMORY CARDS",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("memcard_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = PsxTextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PsxSurfaceDark)
            )
        },
        containerColor = Color.Transparent
    ) { paddingValues ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Slot 1 / Slot 2 Switcher Tabs
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = {
                        selectedSlot = 1
                        blocks = memoryCardManager.getMemoryCardBlocks(1)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedSlot == 1) PsxCrossBlue else PsxCardSurface
                    ),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.SdCard, contentDescription = null, tint = if (selectedSlot == 1) Color.White else PsxTextSecondary)
                    Spacer(Modifier.width(8.dp))
                    Text("SLOT 1 (128 KB)", fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        selectedSlot = 2
                        blocks = memoryCardManager.getMemoryCardBlocks(2)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedSlot == 2) PsxCrossBlue else PsxCardSurface
                    ),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.SdCard, contentDescription = null, tint = if (selectedSlot == 2) Color.White else PsxTextSecondary)
                    Spacer(Modifier.width(8.dp))
                    Text("SLOT 2 (128 KB)", fontWeight = FontWeight.Bold)
                }
            }

            // Visual Card Header
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = PsxCardSurface),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, PsxConsoleGrey.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "SONY PlayStation Memory Card",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = PsxTextPrimary
                        )
                        Text(
                            text = "15 Blocks Total • 128 Kilobytes Storage",
                            fontSize = 11.sp,
                            color = PsxTextSecondary
                        )
                    }

                    OutlinedButton(
                        onClick = {
                            val ok = memoryCardManager.formatCard(selectedSlot)
                            actionMessage = if (ok) "Slot $selectedSlot Formatted" else "Error formatting"
                            blocks = memoryCardManager.getMemoryCardBlocks(selectedSlot)
                        },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = PsxCircleRed)
                    ) {
                        Text("Format Card", fontSize = 12.sp)
                    }
                }
            }

            if (actionMessage != null) {
                Text(
                    text = actionMessage!!,
                    fontSize = 12.sp,
                    color = PsxYellowAccent,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(PsxCardElevated, RoundedCornerShape(6.dp))
                        .padding(8.dp)
                )
            }

            Text(
                text = "SAVED BLOCKS (SLOT $selectedSlot)",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = PsxTextSecondary,
                letterSpacing = 1.sp
            )

            // 15 Memory Card Blocks Grid (3 columns)
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(blocks) { block ->
                    MemoryBlockCard(block = block)
                }
            }
        }
    }
}

@Composable
private fun MemoryBlockCard(block: MemoryCardBlock) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (block.isUsed) PsxCardElevated else PsxSurfaceDark
        ),
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (block.isUsed) PsxCrossBlue.copy(alpha = 0.6f) else PsxDarkCharcoal
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "#${block.slotIndex}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (block.isUsed) PsxCrossBlue else PsxTextDisabled
                )
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(if (block.isUsed) PsxTriangleGreen else PsxDarkCharcoal, CircleShape)
                )
            }

            Text(
                text = block.title,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = if (block.isUsed) PsxTextPrimary else PsxTextDisabled,
                maxLines = 2
            )

            Text(
                text = if (block.isUsed) "8 KB Used" else "Empty Block",
                fontSize = 9.sp,
                color = PsxTextSecondary
            )
        }
    }
}
