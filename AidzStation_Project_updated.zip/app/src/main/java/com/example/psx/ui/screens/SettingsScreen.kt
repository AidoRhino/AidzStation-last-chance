package com.example.psx.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.psx.core.AspectRatioMode
import com.example.psx.core.PerformanceProfile
import com.example.psx.core.PsxConfiguration
import com.example.psx.core.PsxEmulatorEngine
import com.example.psx.core.TextureFiltering
import com.example.psx.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    engine: PsxEmulatorEngine,
    onBack: () -> Unit,
    onNavigateToEditControls: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val initialConfig = remember { PsxConfiguration.load(context) }
    var savedConfig by remember { mutableStateOf(initialConfig) }
    var config by remember { mutableStateOf(initialConfig) }
    var saveStatusMessage by remember { mutableStateOf<String?>(null) }

    val hasUnsavedChanges by remember {
        derivedStateOf { config != savedConfig }
    }

    fun applyAndSaveSettings() {
        PsxConfiguration.save(context, config)
        engine.updateConfiguration(config)
        savedConfig = config
        saveStatusMessage = "Settings saved & applied successfully!"
        Toast.makeText(context, "Settings saved & applied!", Toast.LENGTH_SHORT).show()
    }

    // Auto-save on back navigation so user changes never revert
    BackHandler {
        if (hasUnsavedChanges) {
            PsxConfiguration.save(context, config)
            engine.updateConfiguration(config)
        }
        onBack()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "EMULATOR SETTINGS",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            if (hasUnsavedChanges) {
                                PsxConfiguration.save(context, config)
                                engine.updateConfiguration(config)
                            }
                            onBack()
                        },
                        modifier = Modifier.testTag("settings_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = PsxTextPrimary)
                    }
                },
                actions = {
                    // APPLY & SAVE SETTINGS BUTTON
                    Button(
                        onClick = { applyAndSaveSettings() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (hasUnsavedChanges) PsxTriangleGreen else PsxCardElevated,
                            contentColor = if (hasUnsavedChanges) Color.Black else PsxTextPrimary
                        ),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .testTag("save_settings_top_button")
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = if (hasUnsavedChanges) "Save & Apply*" else "Saved",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PsxSurfaceDark)
            )
        },
        bottomBar = {
            // Persistent Bottom Save Bar
            Surface(
                color = PsxSurfaceDark,
                tonalElevation = 8.dp,
                border = androidx.compose.foundation.BorderStroke(1.dp, PsxDarkCharcoal)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (hasUnsavedChanges) "Unsaved configuration changes" else "All settings active",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (hasUnsavedChanges) PsxYellowAccent else PsxTriangleGreen
                        )
                        Text(
                            text = "Internal resolution: ${config.internalResolutionScale}x • Aspect: ${config.aspectRatio.label}",
                            fontSize = 11.sp,
                            color = PsxTextSecondary
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                val defaults = PsxConfiguration()
                                config = defaults
                                applyAndSaveSettings()
                            },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = PsxTextSecondary),
                            border = androidx.compose.foundation.BorderStroke(1.dp, PsxDarkCharcoal),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text("Reset", fontSize = 12.sp)
                        }

                        Button(
                            onClick = { applyAndSaveSettings() },
                            colors = ButtonDefaults.buttonColors(containerColor = PsxTriangleGreen, contentColor = Color.Black),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                            modifier = Modifier.testTag("apply_settings_bottom_button")
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Apply & Save", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        },
        containerColor = Color.Transparent
    ) { paddingValues ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Save notification banner
            if (saveStatusMessage != null) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = PsxTriangleGreen.copy(alpha = 0.2f)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, PsxTriangleGreen),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = PsxTriangleGreen)
                            Text(saveStatusMessage!!, color = PsxTriangleGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        IconButton(onClick = { saveStatusMessage = null }, modifier = Modifier.size(20.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = PsxTriangleGreen, modifier = Modifier.size(14.dp))
                        }
                    }
                }
            }

            // PERFORMANCE PROFILES
            SettingsSectionHeader(title = "PERFORMANCE PROFILE")
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PerformanceProfile.entries.forEach { prof ->
                    val isSelected = config.profile == prof
                    FilterChip(
                        selected = isSelected,
                        onClick = {
                            config = when (prof) {
                                PerformanceProfile.BATTERY_SAVER -> config.copy(profile = prof, internalResolutionScale = 1, isVsyncEnabled = false)
                                PerformanceProfile.BALANCED -> config.copy(profile = prof, internalResolutionScale = 1, isVsyncEnabled = true)
                                PerformanceProfile.ENHANCED -> config.copy(profile = prof, internalResolutionScale = 2, isVsyncEnabled = true)
                            }
                        },
                        label = { Text(prof.label, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PsxTriangleGreen,
                            selectedLabelColor = Color.Black
                        )
                    )
                }
            }

            // GRAPHICS CONFIGURATION (DUCKSTATION STYLE)
            SettingsSectionHeader(title = "GRAPHICS & DISPLAY (DUCKSTATION ENGINE)")

            SettingsDropdownCard(
                title = "Internal Resolution (Upscaling)",
                subtitle = when (config.internalResolutionScale) {
                    4 -> "4x (Ultra HD 960p / Crisp High-Res)"
                    2 -> "2x (Enhanced 640x480)"
                    else -> "1x (Native 320x240 Original PS1)"
                },
                options = listOf("1x (Native 320x240 Original)", "2x (Enhanced 640x480)", "4x (Ultra HD 960p)"),
                selectedIndex = when (config.internalResolutionScale) {
                    4 -> 2
                    2 -> 1
                    else -> 0
                },
                onSelect = { idx ->
                    val scale = when (idx) {
                        2 -> 4
                        1 -> 2
                        else -> 1
                    }
                    config = config.copy(internalResolutionScale = scale)
                }
            )

            SettingsDropdownCard(
                title = "Texture Filtering",
                subtitle = config.textureFiltering.label,
                options = TextureFiltering.entries.map { it.label },
                selectedIndex = TextureFiltering.entries.indexOf(config.textureFiltering),
                onSelect = { idx ->
                    config = config.copy(textureFiltering = TextureFiltering.entries[idx])
                }
            )

            SettingsToggleCard(
                title = "PGXP Geometry Correction",
                subtitle = "Reduces 3D polygon jitter, wobble, and texture warping",
                checked = config.pgxpGeometryCorrection,
                onCheckedChange = { config = config.copy(pgxpGeometryCorrection = it) }
            )

            SettingsToggleCard(
                title = "Hardware Dithering (True Color vs Retro)",
                subtitle = "Recreates authentic 15-bit color banding and retro dithering patterns",
                checked = config.isDitheringEnabled,
                onCheckedChange = { config = config.copy(isDitheringEnabled = it) }
            )

            SettingsToggleCard(
                title = "Widescreen Hack (16:9)",
                subtitle = "Extends 3D vertex viewport to modern widescreen screens",
                checked = config.isWidescreenHackEnabled,
                onCheckedChange = { config = config.copy(isWidescreenHackEnabled = it) }
            )

            SettingsDropdownCard(
                title = "Aspect Ratio",
                subtitle = config.aspectRatio.label,
                options = AspectRatioMode.entries.map { it.label },
                selectedIndex = AspectRatioMode.entries.indexOf(config.aspectRatio),
                onSelect = { idx ->
                    config = config.copy(aspectRatio = AspectRatioMode.entries[idx])
                }
            )

            SettingsToggleCard(
                title = "Integer Scaling (Pixel Match)",
                subtitle = "Ensures clean integer multiples of pixels with sharp edges",
                checked = config.integerScaling,
                onCheckedChange = { config = config.copy(integerScaling = it) }
            )

            SettingsToggleCard(
                title = "CRT Scanline Filter",
                subtitle = "Draws authentic retro cathode ray tube horizontal scanlines",
                checked = config.crtScanlines,
                onCheckedChange = { config = config.copy(crtScanlines = it) }
            )

            SettingsDropdownCard(
                title = "Frame Skip",
                subtitle = when (config.frameSkip) {
                    0 -> "Disabled (Smooth 60 FPS)"
                    1 -> "Skip 1 Frame (Faster on older devices)"
                    else -> "Skip 2 Frames (Maximum performance)"
                },
                options = listOf("Disabled (Off)", "Skip 1 Frame", "Skip 2 Frames"),
                selectedIndex = config.frameSkip.coerceIn(0, 2),
                onSelect = { idx ->
                    config = config.copy(frameSkip = idx)
                }
            )

            SettingsToggleCard(
                title = "Show On-Screen FPS Counter",
                subtitle = "Display real-time emulation framerate and video standard (NTSC/PAL)",
                checked = config.showFpsCounter,
                onCheckedChange = { config = config.copy(showFpsCounter = it) }
            )

            SettingsToggleCard(
                title = "Vertical Sync (VSync)",
                subtitle = "Smooth 60 FPS pacing without screen tearing",
                checked = config.isVsyncEnabled,
                onCheckedChange = { config = config.copy(isVsyncEnabled = it) }
            )

            // CONTROLLER CONFIGURATION
            SettingsSectionHeader(title = "INPUT & VIRTUAL GAMEPAD")

            // EDIT CONTROLS LAYOUT BUTTON
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToEditControls() }
                    .testTag("settings_edit_controls_button"),
                colors = CardDefaults.cardColors(containerColor = PsxCardElevated),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, PsxTriangleGreen.copy(alpha = 0.6f))
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier.size(40.dp).background(PsxTriangleGreen.copy(alpha = 0.2f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.TouchApp, contentDescription = null, tint = PsxTriangleGreen, modifier = Modifier.size(22.dp))
                        }
                        Column {
                            Text("Edit Controls Layout", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = PsxTextPrimary)
                            Text("Drag virtual buttons, shoulder triggers & D-pad", fontSize = 11.sp, color = PsxTextSecondary)
                        }
                    }
                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = PsxTextSecondary)
                }
            }

            SettingsToggleCard(
                title = "On-Screen Touch Controls",
                subtitle = "Show authentic PlayStation virtual buttons on screen",
                checked = config.touchControlsVisible,
                onCheckedChange = { config = config.copy(touchControlsVisible = it) }
            )

            SettingsSliderCard(
                title = "Touch Button Opacity",
                value = config.touchOpacity,
                valueDisplay = "${(config.touchOpacity * 100).toInt()}%",
                onValueChange = { config = config.copy(touchOpacity = it) }
            )

            SettingsToggleCard(
                title = "DualShock Analog Thumbsticks",
                subtitle = "Display L3/R3 analog circular sticks alongside D-Pad",
                checked = config.isDualShockAnalog,
                onCheckedChange = { config = config.copy(isDualShockAnalog = it) }
            )

            SettingsToggleCard(
                title = "Haptic Vibration",
                subtitle = "Vibrate device gently on button presses",
                checked = config.touchHapticsEnabled,
                onCheckedChange = { config = config.copy(touchHapticsEnabled = it) }
            )

            // EMULATION CORE SELECTION
            SettingsSectionHeader(title = "CORE ARCHITECTURE")

            SettingsToggleCard(
                title = "PCSX-ReARMed Native Core",
                subtitle = "High-performance ARM64/x86 native engine with dynarec JIT",
                checked = config.useNativeCore,
                onCheckedChange = { config = config.copy(useNativeCore = it) }
            )

            // RETROACHIEVEMENTS INTEGRATION
            SettingsSectionHeader(title = "RETROACHIEVEMENTS")
            val retroUser by engine.retroAchievements.currentUser.collectAsState()
            var showRetroDialog by remember { mutableStateOf(false) }

            if (showRetroDialog) {
                com.example.psx.ui.components.RetroAchievementsDialog(
                    manager = engine.retroAchievements,
                    onDismiss = { showRetroDialog = false }
                )
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showRetroDialog = true }
                    .testTag("settings_retroachievements_card"),
                colors = CardDefaults.cardColors(containerColor = PsxCardSurface),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, PsxDarkCharcoal)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(PsxYellowAccent.copy(alpha = 0.2f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = PsxYellowAccent)
                        }
                        Column {
                            Text(
                                "RetroAchievements Account",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = PsxTextPrimary
                            )
                            Text(
                                if (retroUser != null) "Logged in as ${retroUser?.username} (${retroUser?.score} pts)" else "Sign in to earn PS1 trophies & track progress",
                                fontSize = 11.sp,
                                color = if (retroUser != null) PsxTriangleGreen else PsxTextSecondary
                            )
                        }
                    }
                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = PsxTextSecondary)
                }
            }

            Spacer(Modifier.height(30.dp))
        }
    }
}

@Composable
private fun SettingsSectionHeader(title: String) {
    Text(
        text = title,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        color = PsxTextSecondary,
        letterSpacing = 1.sp
    )
}

@Composable
private fun SettingsToggleCard(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = PsxCardSurface),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, PsxDarkCharcoal)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = PsxTextPrimary)
                Spacer(Modifier.height(2.dp))
                Text(text = subtitle, fontSize = 11.sp, color = PsxTextSecondary)
            }
            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = PsxTriangleGreen)
            )
        }
    }
}

@Composable
private fun SettingsSliderCard(
    title: String,
    value: Float,
    valueDisplay: String,
    onValueChange: (Float) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = PsxCardSurface),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, PsxDarkCharcoal)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = PsxTextPrimary)
                Text(text = valueDisplay, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = PsxCrossBlue)
            }
            Slider(
                value = value,
                onValueChange = onValueChange,
                valueRange = 0.1f..1.0f,
                colors = SliderDefaults.colors(thumbColor = PsxCrossBlue, activeTrackColor = PsxCrossBlue)
            )
        }
    }
}

@Composable
private fun SettingsDropdownCard(
    title: String,
    subtitle: String,
    options: List<String>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = true },
        colors = CardDefaults.cardColors(containerColor = PsxCardSurface),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, PsxDarkCharcoal)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = PsxTextPrimary)
            Spacer(Modifier.height(2.dp))
            Text(text = subtitle, fontSize = 12.sp, color = PsxCrossBlue, fontWeight = FontWeight.SemiBold)

            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false },
                modifier = Modifier.background(PsxSurfaceDark)
            ) {
                options.forEachIndexed { index, opt ->
                    DropdownMenuItem(
                        text = { Text(opt, color = PsxTextPrimary) },
                        onClick = {
                            onSelect(index)
                            expanded = false
                        }
                    )
                }
            }
        }
    }
}
