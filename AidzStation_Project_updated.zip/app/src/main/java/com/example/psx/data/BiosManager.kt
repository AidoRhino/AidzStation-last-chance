package com.example.psx.data

import android.content.Context
import java.io.File
import java.security.MessageDigest

data class BiosInfo(
    val fileName: String,
    val region: String,
    val description: String,
    val expectedMd5: String,
    val isPresent: Boolean = false,
    val filePath: String? = null
)

class BiosManager(private val context: Context) {
    val biosDir = File(context.filesDir, "bios").apply { mkdirs() }

    private val officialBiosDefinitions = listOf(
        BiosInfo("scph1001.bin", "NTSC-U/C (North America)", "v2.2 Initial US Release (Recommended)", "924e392ed05558ffdb115408c163d70e"),
        BiosInfo("scph5501.bin", "NTSC-U/C (North America)", "v3.0 Most Compatible US BIOS", "8d8d214a60183307616239103df12519"),
        BiosInfo("scph5500.bin", "NTSC-J (Japan)", "v3.0 Japanese Hardware BIOS", "ff3eeb8c66eab5463bbbce7904256377"),
        BiosInfo("scph5502.bin", "PAL (Europe / Australia)", "v3.0 European PAL BIOS", "32736f17079d0b2b70244011562dcd3f"),
        BiosInfo("scph7001.bin", "NTSC-U/C (North America)", "v4.1 Late Model US BIOS", "1e68c23d3d4e357e40a0c4e177753fa9")
    )

    fun getDetectedBiosList(): List<BiosInfo> {
        val existingFiles = biosDir.listFiles() ?: emptyArray()

        return officialBiosDefinitions.map { def ->
            val match = existingFiles.firstOrNull { it.name.equals(def.fileName, ignoreCase = true) }
            if (match != null) {
                def.copy(isPresent = true, filePath = match.absolutePath)
            } else {
                def.copy(isPresent = false, filePath = null)
            }
        }
    }

    fun hasAnyOfficialBios(): Boolean {
        return getDetectedBiosList().any { it.isPresent }
    }

    fun importBiosFile(sourceFile: File): Pair<Boolean, String> {
        return try {
            val bytes = sourceFile.readBytes()
            if (bytes.size != 524288) { // Standard PS1 BIOS is exactly 512 KB
                return Pair(false, "Invalid BIOS size: ${bytes.size} bytes (must be exactly 512 KB)")
            }

            val md5 = calculateMd5(bytes)
            val matched = officialBiosDefinitions.firstOrNull { it.expectedMd5.equals(md5, ignoreCase = true) }
            val targetName = matched?.fileName ?: sourceFile.name.lowercase()

            val targetFile = File(biosDir, targetName)
            targetFile.writeBytes(bytes)

            val msg = if (matched != null) {
                "Recognized ${matched.region} BIOS (${matched.description})"
            } else {
                "Imported custom BIOS file: $targetName (MD5: $md5)"
            }
            Pair(true, msg)
        } catch (e: Exception) {
            Pair(false, "Failed to import BIOS: ${e.message}")
        }
    }

    private fun calculateMd5(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("MD5").digest(bytes)
        return digest.joinToString("") { "%02x".format(it) }
    }
}
