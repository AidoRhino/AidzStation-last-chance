package com.example.psx.input

import android.content.Context
import androidx.compose.ui.geometry.Offset

data class ControllerGroupOffsets(
    val dpadOffset: Offset = Offset.Zero,
    val actionButtonsOffset: Offset = Offset.Zero,
    val leftShoulderOffset: Offset = Offset.Zero,
    val rightShoulderOffset: Offset = Offset.Zero,
    val systemButtonsOffset: Offset = Offset.Zero,
    val menuButtonOffset: Offset = Offset.Zero,
    val leftStickOffset: Offset = Offset.Zero,
    val rightStickOffset: Offset = Offset.Zero
)

object ControllerLayoutManager {
    private const val PREFS_NAME = "psx_controller_layout_prefs"

    fun loadLayout(context: Context, isLandscape: Boolean): ControllerGroupOffsets {
        val prefix = if (isLandscape) "land_" else "port_"
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        return ControllerGroupOffsets(
            dpadOffset = Offset(
                prefs.getFloat("${prefix}dpad_x", 0f),
                prefs.getFloat("${prefix}dpad_y", 0f)
            ),
            actionButtonsOffset = Offset(
                prefs.getFloat("${prefix}action_x", 0f),
                prefs.getFloat("${prefix}action_y", 0f)
            ),
            leftShoulderOffset = Offset(
                prefs.getFloat("${prefix}lsh_x", 0f),
                prefs.getFloat("${prefix}lsh_y", 0f)
            ),
            rightShoulderOffset = Offset(
                prefs.getFloat("${prefix}rsh_x", 0f),
                prefs.getFloat("${prefix}rsh_y", 0f)
            ),
            systemButtonsOffset = Offset(
                prefs.getFloat("${prefix}sys_x", 0f),
                prefs.getFloat("${prefix}sys_y", 0f)
            ),
            menuButtonOffset = Offset(
                prefs.getFloat("${prefix}menu_x", 0f),
                prefs.getFloat("${prefix}menu_y", 0f)
            ),
            leftStickOffset = Offset(
                prefs.getFloat("${prefix}lstick_x", 0f),
                prefs.getFloat("${prefix}lstick_y", 0f)
            ),
            rightStickOffset = Offset(
                prefs.getFloat("${prefix}rstick_x", 0f),
                prefs.getFloat("${prefix}rstick_y", 0f)
            )
        )
    }

    fun saveLayout(context: Context, layout: ControllerGroupOffsets, isLandscape: Boolean) {
        val prefix = if (isLandscape) "land_" else "port_"
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        prefs.edit()
            .putFloat("${prefix}dpad_x", layout.dpadOffset.x)
            .putFloat("${prefix}dpad_y", layout.dpadOffset.y)
            .putFloat("${prefix}action_x", layout.actionButtonsOffset.x)
            .putFloat("${prefix}action_y", layout.actionButtonsOffset.y)
            .putFloat("${prefix}lsh_x", layout.leftShoulderOffset.x)
            .putFloat("${prefix}lsh_y", layout.leftShoulderOffset.y)
            .putFloat("${prefix}rsh_x", layout.rightShoulderOffset.x)
            .putFloat("${prefix}rsh_y", layout.rightShoulderOffset.y)
            .putFloat("${prefix}sys_x", layout.systemButtonsOffset.x)
            .putFloat("${prefix}sys_y", layout.systemButtonsOffset.y)
            .putFloat("${prefix}menu_x", layout.menuButtonOffset.x)
            .putFloat("${prefix}menu_y", layout.menuButtonOffset.y)
            .putFloat("${prefix}lstick_x", layout.leftStickOffset.x)
            .putFloat("${prefix}lstick_y", layout.leftStickOffset.y)
            .putFloat("${prefix}rstick_x", layout.rightStickOffset.x)
            .putFloat("${prefix}rstick_y", layout.rightStickOffset.y)
            .apply()
    }

    fun resetToDefault(context: Context, isLandscape: Boolean) {
        val prefix = if (isLandscape) "land_" else "port_"
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .remove("${prefix}dpad_x")
            .remove("${prefix}dpad_y")
            .remove("${prefix}action_x")
            .remove("${prefix}action_y")
            .remove("${prefix}lsh_x")
            .remove("${prefix}lsh_y")
            .remove("${prefix}rsh_x")
            .remove("${prefix}rsh_y")
            .remove("${prefix}sys_x")
            .remove("${prefix}sys_y")
            .remove("${prefix}menu_x")
            .remove("${prefix}menu_y")
            .remove("${prefix}lstick_x")
            .remove("${prefix}lstick_y")
            .remove("${prefix}rstick_x")
            .remove("${prefix}rstick_y")
            .apply()
    }
}
