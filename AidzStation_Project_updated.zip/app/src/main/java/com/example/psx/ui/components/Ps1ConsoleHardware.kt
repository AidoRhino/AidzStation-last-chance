package com.example.psx.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Authentic SCPH-1001/5501 PlayStation 1 Console Grey Palette
val Ps1BodyGrey = Color(0xFFA2A3A6)
val Ps1LightBevel = Color(0xFFC7C8CB)
val Ps1ShadowBevel = Color(0xFF707174)
val Ps1DeepGroove = Color(0xFF505154)
val Ps1ButtonGrey = Color(0xFF98999C)
val Ps1ButtonLight = Color(0xFFB8B9BC)
val Ps1ButtonShadow = Color(0xFF6C6D70)
val Ps1LedGreen = Color(0xFF00E676)
val Ps1LedGlow = Color(0x6600E676)

/**
 * Authentic replica of the original PlayStation 1 console deck featuring:
 * 1. Power Button: Round concave button with concentric rings, POWER label, and glowing green LED.
 * 2. Disc Lid: Large circular CD bay with stepped outer bezel, OPEN latch button,
 *    and the AidzStation 4-coloured retro logo in the center in place of the original PlayStation symbol.
 * 3. Reset Button: Round concave button with RESET / SETUP stamping matching the console hardware.
 */
@Composable
fun Ps1ConsoleHardware(
    onPowerClick: () -> Unit,
    onDiscOpenClick: () -> Unit,
    onResetClick: () -> Unit,
    onSetupClick: () -> Unit = onResetClick,
    isPoweredOn: Boolean = true,
    activeGameTitle: String? = null,
    modifier: Modifier = Modifier
) {
    // Subtle pulsating green power LED animation
    val infiniteTransition = rememberInfiniteTransition(label = "power_led_glow")
    val ledAlpha by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "led_alpha"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(
                Brush.verticalGradient(
                    listOf(
                        Ps1LightBevel,
                        Ps1BodyGrey,
                        Ps1BodyGrey,
                        Ps1ShadowBevel
                    )
                )
            )
            .border(2.dp, Ps1ShadowBevel, RoundedCornerShape(16.dp))
            .shadow(6.dp, RoundedCornerShape(16.dp))
            .padding(14.dp)
            .testTag("ps1_console_hardware_deck")
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Sony / AidzStation embossed badge strip
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "AIDZSTATION",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.sp,
                    color = Ps1DeepGroove
                )
                Text(
                    text = if (activeGameTitle != null) "DISC LOADED" else "NO DISC",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    color = if (activeGameTitle != null) Color(0xFF007A3D) else Ps1DeepGroove
                )
            }

            Spacer(Modifier.height(8.dp))

            // Main Deck: [POWER BUTTON] --- [CIRCULAR DISC LID WITH AIDZSTATION LOGO] --- [RESET / SETUP BUTTON]
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 1. AUTHENTIC CIRCULAR POWER BUTTON
                Ps1PowerButton(
                    onClick = onPowerClick,
                    isPowered = isPoweredOn,
                    ledAlpha = ledAlpha
                )

                // 2. AUTHENTIC CIRCULAR DISC LID WITH AIDZSTATION LOGO & OPEN BUTTON
                Ps1DiscLid(
                    onClick = onDiscOpenClick,
                    activeTitle = activeGameTitle
                )

                // 3. AUTHENTIC CIRCULAR RESET / REFRESH BUTTON
                Ps1ResetButton(
                    onClick = onResetClick
                )
            }
        }
    }
}

/**
 * Authentic PS1 Circular Power Button with indented well, concentric rings,
 * POWER debossed text, and green LED status indicator.
 */
@Composable
private fun Ps1PowerButton(
    onClick: () -> Unit,
    isPowered: Boolean,
    ledAlpha: Float
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // Outer circular recession well in the console chassis
        Box(
            modifier = Modifier
                .size(68.dp)
                .background(
                    Brush.verticalGradient(
                        listOf(Ps1DeepGroove, Ps1ShadowBevel, Ps1LightBevel)
                    ),
                    CircleShape
                )
                .border(1.5.dp, Ps1DeepGroove, CircleShape)
                .padding(4.dp),
            contentAlignment = Alignment.Center
        ) {
            // Tactile Button Core
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape)
                    .background(
                        if (isPressed) {
                            Brush.radialGradient(listOf(Ps1DeepGroove, Ps1ButtonShadow))
                        } else {
                            Brush.radialGradient(listOf(Ps1ButtonLight, Ps1ButtonGrey, Ps1ButtonShadow))
                        }
                    )
                    .border(
                        1.5.dp,
                        if (isPressed) Ps1DeepGroove else Ps1LightBevel,
                        CircleShape
                    )
                    .clickable(
                        interactionSource = interactionSource,
                        indication = null,
                        onClick = onClick
                    )
                    .testTag("console_power_button"),
                contentAlignment = Alignment.Center
            ) {
                // Concentric inner groove
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .border(1.dp, Ps1ShadowBevel.copy(alpha = 0.6f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        // Green Power LED
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .background(
                                    if (isPowered) Ps1LedGreen.copy(alpha = ledAlpha) else Color(0xFF334433),
                                    CircleShape
                                )
                                .border(1.dp, Color.Black.copy(alpha = 0.5f), CircleShape)
                        )
                        Spacer(Modifier.height(3.dp))
                        Text(
                            text = "POWER",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.5.sp,
                            color = Ps1DeepGroove
                        )
                    }
                }
            }
        }
        Text(
            text = "CLOSE APP",
            fontSize = 7.sp,
            fontWeight = FontWeight.Bold,
            color = Ps1DeepGroove
        )
    }
}

/**
 * Authentic PS1 Circular Disc Lid featuring:
 * - Stepped outer bezel rings
 * - Deep circular lid seam
 * - The official AidzStation 4-colour retro logo in the center in place of the original PS symbol
 * - Tactile "OPEN" latch button
 */
@Composable
private fun Ps1DiscLid(
    onClick: () -> Unit,
    activeTitle: String?
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scope = rememberCoroutineScope()
    val trayProgress = remember { Animatable(0f) }
    var isOpening by remember { mutableStateOf(false) }

    // Lid hinges open, the disc bay is revealed, then the original action runs.
    val openTray: () -> Unit = {
        if (!isOpening) {
            isOpening = true
            scope.launch {
                trayProgress.animateTo(1f, tween(650, easing = FastOutSlowInEasing))
                delay(180)
                onClick()
                trayProgress.snapTo(0f)
                isOpening = false
            }
        }
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // Outer concentric disc lid recession
        Box(
            modifier = Modifier
                .size(142.dp)
                .background(
                    Brush.radialGradient(
                        listOf(Ps1LightBevel, Ps1BodyGrey, Ps1ShadowBevel, Ps1DeepGroove)
                    ),
                    CircleShape
                )
                .border(2.dp, Ps1DeepGroove, CircleShape)
                .padding(6.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clickable(
                        interactionSource = interactionSource,
                        indication = null,
                        onClick = openTray
                    )
                    .testTag("console_open_button"),
                contentAlignment = Alignment.Center
            ) {
            // Disc bay revealed as the lid opens
            if (trayProgress.value > 0f) {
                Canvas(Modifier.fillMaxSize().clip(CircleShape)) {
                    val c = center
                    val r = size.minDimension / 2f
                    drawCircle(Brush.radialGradient(listOf(Ps1DeepGroove, Color(0xFF1B1B1D)), c, r), r, c)
                    val discR = r * 0.78f * trayProgress.value
                    drawCircle(Brush.radialGradient(listOf(Color(0xFFE8EAF0), Color(0xFF9AA0AE), Color(0xFFD5D8E0)), c, discR.coerceAtLeast(1f)), discR, c)
                    drawCircle(Color(0xFF1B1B1D), discR * 0.18f, c)
                }
            }
            // Stepped inner circular lid (hinged at the top edge)
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        transformOrigin = TransformOrigin(0.5f, 0f)
                        cameraDistance = 14f * density
                        rotationX = -78f * trayProgress.value
                        alpha = 1f - 0.35f * trayProgress.value
                    }
                    .clip(CircleShape)
                    .background(
                        if (isPressed) {
                            Brush.radialGradient(listOf(Ps1ButtonGrey, Ps1ButtonShadow, Ps1DeepGroove))
                        } else {
                            Brush.radialGradient(listOf(Ps1ButtonLight, Ps1BodyGrey, Ps1ButtonShadow))
                        }
                    )
                    .border(2.dp, Ps1LightBevel, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                // Concentric cosmetic groove ring
                Box(
                    modifier = Modifier
                        .size(104.dp)
                        .border(1.dp, Ps1ShadowBevel.copy(alpha = 0.7f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        // AIDZSTATION COLOURED LOGO IN CENTER IN PLACE OF ORIGINAL PLAYSTATION SYMBOL
                        AidzStationLogo(size = 46.dp)

                        Spacer(Modifier.height(2.dp))

                        Text(
                            text = "AidzStation",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.8.sp,
                            color = Ps1DeepGroove
                        )
                    }
                }

                // Tactile "OPEN" eject latch button at bottom right of lid perimeter
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 4.dp, bottom = 4.dp)
                        .size(width = 34.dp, height = 18.dp)
                        .clip(RoundedCornerShape(9.dp))
                        .background(
                            Brush.verticalGradient(
                                listOf(Ps1ButtonLight, Ps1ButtonGrey, Ps1ButtonShadow)
                            )
                        )
                        .border(1.dp, Ps1DeepGroove, RoundedCornerShape(9.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "OPEN",
                        fontSize = 7.sp,
                        fontWeight = FontWeight.Black,
                        color = Ps1DeepGroove
                    )
                }
            }
            }
        }

        Text(
            text = "DISC DRIVE",
            fontSize = 8.sp,
            fontWeight = FontWeight.Bold,
            color = Ps1DeepGroove
        )
    }
}

/**
 * Authentic PS1 Circular Reset / Setup Button matching the Power button styling on the opposite side.
 */
@Composable
private fun Ps1ResetButton(
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // Outer circular recession well in the console chassis
        Box(
            modifier = Modifier
                .size(68.dp)
                .background(
                    Brush.verticalGradient(
                        listOf(Ps1DeepGroove, Ps1ShadowBevel, Ps1LightBevel)
                    ),
                    CircleShape
                )
                .border(1.5.dp, Ps1DeepGroove, CircleShape)
                .padding(4.dp),
            contentAlignment = Alignment.Center
        ) {
            // Tactile Button Core
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape)
                    .background(
                        if (isPressed) {
                            Brush.radialGradient(listOf(Ps1DeepGroove, Ps1ButtonShadow))
                        } else {
                            Brush.radialGradient(listOf(Ps1ButtonLight, Ps1ButtonGrey, Ps1ButtonShadow))
                        }
                    )
                    .border(
                        1.5.dp,
                        if (isPressed) Ps1DeepGroove else Ps1LightBevel,
                        CircleShape
                    )
                    .clickable(
                        interactionSource = interactionSource,
                        indication = null,
                        onClick = onClick
                    )
                    .testTag("console_setup_button"),
                contentAlignment = Alignment.Center
            ) {
                // Concentric inner groove
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .border(1.dp, Ps1ShadowBevel.copy(alpha = 0.6f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "RESET",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.5.sp,
                            color = Ps1DeepGroove
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = "REFRESH",
                            fontSize = 6.sp,
                            fontWeight = FontWeight.Bold,
                            color = Ps1ShadowBevel
                        )
                    }
                }
            }
        }
        Text(
            text = "LIBRARY",
            fontSize = 7.sp,
            fontWeight = FontWeight.Bold,
            color = Ps1DeepGroove
        )
    }
}
