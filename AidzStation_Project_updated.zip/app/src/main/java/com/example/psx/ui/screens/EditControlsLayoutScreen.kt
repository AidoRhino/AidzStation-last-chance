package com.example.psx.ui.screens

import android.content.res.Configuration
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.psx.input.ControllerGroupOffsets
import com.example.psx.input.ControllerLayoutManager
import com.example.psx.ui.components.AidzStationLogo
import com.example.psx.ui.components.PlayStationPatternBackground
import com.example.psx.ui.components.PsxSymbolIcon
import com.example.psx.ui.components.PsxSymbolType
import com.example.psx.ui.theme.*
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditControlsLayoutScreen(
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val configuration = LocalConfiguration.current
    val isLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    val initialLayout = remember(isLandscape) {
        ControllerLayoutManager.loadLayout(context, isLandscape)
    }

    var dpadOffset by remember(initialLayout) { mutableStateOf(initialLayout.dpadOffset) }
    var actionButtonsOffset by remember(initialLayout) { mutableStateOf(initialLayout.actionButtonsOffset) }
    var leftShoulderOffset by remember(initialLayout) { mutableStateOf(initialLayout.leftShoulderOffset) }
    var rightShoulderOffset by remember(initialLayout) { mutableStateOf(initialLayout.rightShoulderOffset) }
    var systemButtonsOffset by remember(initialLayout) { mutableStateOf(initialLayout.systemButtonsOffset) }
    var menuButtonOffset by remember(initialLayout) { mutableStateOf(initialLayout.menuButtonOffset) }
    var leftStickOffset by remember(initialLayout) { mutableStateOf(initialLayout.leftStickOffset) }
    var rightStickOffset by remember(initialLayout) { mutableStateOf(initialLayout.rightStickOffset) }

    fun saveLayout() {
        val newLayout = ControllerGroupOffsets(
            dpadOffset = dpadOffset,
            actionButtonsOffset = actionButtonsOffset,
            leftShoulderOffset = leftShoulderOffset,
            rightShoulderOffset = rightShoulderOffset,
            systemButtonsOffset = systemButtonsOffset,
            menuButtonOffset = menuButtonOffset,
            leftStickOffset = leftStickOffset,
            rightStickOffset = rightStickOffset
        )
        ControllerLayoutManager.saveLayout(context, newLayout, isLandscape)
        Toast.makeText(context, "Gamepad layout saved!", Toast.LENGTH_SHORT).show()
        onDismiss()
    }

    fun resetLayout() {
        ControllerLayoutManager.resetToDefault(context, isLandscape)
        dpadOffset = Offset.Zero
        actionButtonsOffset = Offset.Zero
        leftShoulderOffset = Offset.Zero
        rightShoulderOffset = Offset.Zero
        systemButtonsOffset = Offset.Zero
        menuButtonOffset = Offset.Zero
        leftStickOffset = Offset.Zero
        rightStickOffset = Offset.Zero
        Toast.makeText(context, "Layout reset to default", Toast.LENGTH_SHORT).show()
    }

    BackHandler {
        onDismiss()
    }

    PlayStationPatternBackground(
        modifier = modifier
            .fillMaxSize()
            .testTag("edit_controls_screen")
    ) {
        // Subtle Retro Guide Grid overlay
        Canvas(modifier = Modifier.fillMaxSize().alpha(0.08f)) {
            val step = 40.dp.toPx()
            var x = 0f
            while (x < size.width) {
                drawLine(Color.White, Offset(x, 0f), Offset(x, size.height), 1f)
                x += step
            }
            var y = 0f
            while (y < size.height) {
                drawLine(Color.White, Offset(0f, y), Offset(size.width, y), 1f)
                y += step
            }
        }

        // TOP ACTION BAR WITH SAVE, CANCEL, RESET
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter),
            color = PsxSurfaceDark.copy(alpha = 0.95f),
            tonalElevation = 8.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(36.dp).background(PsxCardElevated, CircleShape)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Cancel", tint = PsxCircleRed, modifier = Modifier.size(18.dp))
                    }

                    Column {
                        Text(
                            text = "EDIT CONTROLS LAYOUT",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp,
                            color = PsxTextPrimary
                        )
                        Text(
                            text = "Drag D-Pad, Buttons & Dual Analog Sticks to customize",
                            fontSize = 9.sp,
                            color = PsxTextSecondary
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { resetLayout() },
                        colors = ButtonDefaults.buttonColors(containerColor = PsxCardElevated),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(14.dp), tint = PsxYellowAccent)
                        Spacer(Modifier.width(4.dp))
                        Text("Reset", fontSize = 11.sp, color = PsxTextPrimary)
                    }

                    Button(
                        onClick = { saveLayout() },
                        colors = ButtonDefaults.buttonColors(containerColor = PsxTriangleGreen),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.Black)
                        Spacer(Modifier.width(4.dp))
                        Text("Save", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                    }
                }
            }
        }

        // DRAGGABLE CONTROLLER COMPONENTS

        // 1. LEFT SHOULDERS (L1 / L2)
        Box(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(top = 70.dp, start = 16.dp)
                .offset { IntOffset(leftShoulderOffset.x.roundToInt(), leftShoulderOffset.y.roundToInt()) }
                .border(1.dp, PsxCrossBlue.copy(alpha = 0.6f), RoundedCornerShape(10.dp))
                .background(PsxCardElevated.copy(alpha = 0.65f), RoundedCornerShape(10.dp))
                .padding(4.dp)
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        leftShoulderOffset += dragAmount
                    }
                }
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ButtonBox("L2")
                ButtonBox("L1")
            }
        }

        // 2. QUICK MENU BUTTON
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 70.dp)
                .offset { IntOffset(menuButtonOffset.x.roundToInt(), menuButtonOffset.y.roundToInt()) }
                .size(46.dp)
                .clip(CircleShape)
                .border(2.dp, PsxYellowAccent.copy(alpha = 0.8f), CircleShape)
                .background(PsxCardElevated.copy(alpha = 0.7f), CircleShape)
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        menuButtonOffset += dragAmount
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            AidzStationLogo(size = 26.dp)
        }

        // 3. RIGHT SHOULDERS (R1 / R2)
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 70.dp, end = 16.dp)
                .offset { IntOffset(rightShoulderOffset.x.roundToInt(), rightShoulderOffset.y.roundToInt()) }
                .border(1.dp, PsxCrossBlue.copy(alpha = 0.6f), RoundedCornerShape(10.dp))
                .background(PsxCardElevated.copy(alpha = 0.65f), RoundedCornerShape(10.dp))
                .padding(4.dp)
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        rightShoulderOffset += dragAmount
                    }
                }
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ButtonBox("R1")
                ButtonBox("R2")
            }
        }

        // 4. D-PAD CLUSTER
        Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(bottom = if (isLandscape) 24.dp else 120.dp, start = 16.dp)
                .offset { IntOffset(dpadOffset.x.roundToInt(), dpadOffset.y.roundToInt()) }
                .border(1.5.dp, PsxTriangleGreen.copy(alpha = 0.7f), RoundedCornerShape(16.dp))
                .background(PsxCardElevated.copy(alpha = 0.65f), RoundedCornerShape(16.dp))
                .padding(8.dp)
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        dpadOffset += dragAmount
                    }
                }
        ) {
            Box(
                modifier = Modifier.size(126.dp),
                contentAlignment = Alignment.Center
            ) {
                // Cross guides
                Box(Modifier.size(42.dp, 122.dp).background(PsxSurfaceDark.copy(alpha = 0.8f), RoundedCornerShape(8.dp)))
                Box(Modifier.size(122.dp, 42.dp).background(PsxSurfaceDark.copy(alpha = 0.8f), RoundedCornerShape(8.dp)))
                Text("D-PAD", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = PsxTriangleGreen)
            }
        }

        // 5. LEFT ANALOG STICK (L3)
        Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(
                    bottom = if (isLandscape) 24.dp else 16.dp,
                    start = if (isLandscape) 160.dp else 36.dp
                )
                .offset { IntOffset(leftStickOffset.x.roundToInt(), leftStickOffset.y.roundToInt()) }
                .border(1.5.dp, PsxCrossBlue.copy(alpha = 0.8f), CircleShape)
                .background(PsxCardElevated.copy(alpha = 0.7f), CircleShape)
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        leftStickOffset += dragAmount
                    }
                }
        ) {
            AnalogStickEditorWidget(label = "LEFT STICK\n(L3)", accentColor = PsxCrossBlue)
        }

        // 6. SYSTEM BUTTONS (SELECT / START)
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 32.dp)
                .offset { IntOffset(systemButtonsOffset.x.roundToInt(), systemButtonsOffset.y.roundToInt()) }
                .border(1.dp, PsxYellowAccent.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                .background(PsxCardElevated.copy(alpha = 0.65f), RoundedCornerShape(12.dp))
                .padding(6.dp)
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        systemButtonsOffset += dragAmount
                    }
                }
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PillBox("SELECT")
                PillBox("START")
            }
        }

        // 7. RIGHT ANALOG STICK (R3)
        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(
                    bottom = if (isLandscape) 24.dp else 16.dp,
                    end = if (isLandscape) 160.dp else 36.dp
                )
                .offset { IntOffset(rightStickOffset.x.roundToInt(), rightStickOffset.y.roundToInt()) }
                .border(1.5.dp, PsxSquarePink.copy(alpha = 0.8f), CircleShape)
                .background(PsxCardElevated.copy(alpha = 0.7f), CircleShape)
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        rightStickOffset += dragAmount
                    }
                }
        ) {
            AnalogStickEditorWidget(label = "RIGHT STICK\n(R3)", accentColor = PsxSquarePink)
        }

        // 8. ACTION BUTTONS GROUP (TRIANGLE, CIRCLE, CROSS, SQUARE) - MOVES TOGETHER
        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = if (isLandscape) 24.dp else 120.dp, end = 16.dp)
                .offset { IntOffset(actionButtonsOffset.x.roundToInt(), actionButtonsOffset.y.roundToInt()) }
                .border(1.5.dp, PsxSquarePink.copy(alpha = 0.8f), RoundedCornerShape(20.dp))
                .background(PsxCardElevated.copy(alpha = 0.65f), RoundedCornerShape(20.dp))
                .padding(8.dp)
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        actionButtonsOffset += dragAmount
                    }
                }
        ) {
            Box(
                modifier = Modifier.size(126.dp),
                contentAlignment = Alignment.Center
            ) {
                // Top: Triangle
                Box(Modifier.align(Alignment.TopCenter).size(42.dp).background(PsxSurfaceDark, CircleShape).border(1.dp, PsxTriangleGreen, CircleShape), contentAlignment = Alignment.Center) {
                    PsxSymbolIcon(PsxSymbolType.TRIANGLE, size = 18.dp)
                }
                // Right: Circle
                Box(Modifier.align(Alignment.CenterEnd).size(42.dp).background(PsxSurfaceDark, CircleShape).border(1.dp, PsxCircleRed, CircleShape), contentAlignment = Alignment.Center) {
                    PsxSymbolIcon(PsxSymbolType.CIRCLE, size = 18.dp)
                }
                // Bottom: Cross
                Box(Modifier.align(Alignment.BottomCenter).size(42.dp).background(PsxSurfaceDark, CircleShape).border(1.dp, PsxCrossBlue, CircleShape), contentAlignment = Alignment.Center) {
                    PsxSymbolIcon(PsxSymbolType.CROSS, size = 18.dp)
                }
                // Left: Square
                Box(Modifier.align(Alignment.CenterStart).size(42.dp).background(PsxSurfaceDark, CircleShape).border(1.dp, PsxSquarePink, CircleShape), contentAlignment = Alignment.Center) {
                    PsxSymbolIcon(PsxSymbolType.SQUARE, size = 18.dp)
                }

                Text(
                    text = "ACTION GROUP",
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    color = PsxTextDisabled
                )
            }
        }
    }
}

@Composable
private fun AnalogStickEditorWidget(label: String, accentColor: Color) {
    Box(
        modifier = Modifier
            .size(92.dp)
            .padding(4.dp),
        contentAlignment = Alignment.Center
    ) {
        // Outer DualShock base ring
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(Color(0xFF2A2D35), Color(0xFF16181D))
                    )
                )
                .border(1.5.dp, accentColor.copy(alpha = 0.6f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            // Inner textured concave thumbcap
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(Color(0xFF4A4E58), Color(0xFF202228))
                        )
                    )
                    .border(1.dp, Color(0xFF6B7280), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = label,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    color = accentColor,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    lineHeight = 10.sp
                )
            }
        }
    }
}

@Composable
private fun ButtonBox(label: String) {
    Box(
        modifier = Modifier
            .size(width = 52.dp, height = 34.dp)
            .background(PsxSurfaceDark, RoundedCornerShape(6.dp))
            .border(1.dp, PsxConsoleGrey.copy(alpha = 0.5f), RoundedCornerShape(6.dp)),
        contentAlignment = Alignment.Center
    ) {
        Text(text = label, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = PsxTextPrimary)
    }
}

@Composable
private fun PillBox(label: String) {
    Box(
        modifier = Modifier
            .size(width = 52.dp, height = 26.dp)
            .background(PsxSurfaceDark, RoundedCornerShape(13.dp))
            .border(1.dp, PsxConsoleGrey.copy(alpha = 0.5f), RoundedCornerShape(13.dp)),
        contentAlignment = Alignment.Center
    ) {
        Text(text = label, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = PsxTextSecondary)
    }
}
