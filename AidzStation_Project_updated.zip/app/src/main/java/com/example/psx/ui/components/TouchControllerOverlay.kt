package com.example.psx.ui.components

import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.psx.core.PsxConfiguration
import com.example.psx.input.ControllerLayoutManager
import com.example.psx.input.ControllerState
import com.example.psx.ui.theme.*
import kotlin.math.roundToInt

@Composable
fun TouchControllerOverlay(
    controllerState: ControllerState,
    config: PsxConfiguration,
    onMenuClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (!config.touchControlsVisible) return

    val context = LocalContext.current
    val configuration = LocalConfiguration.current
    val isLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    val layout = remember(isLandscape) {
        ControllerLayoutManager.loadLayout(context, isLandscape)
    }

    val vibrator = remember { context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator }

    fun vibrate() {
        if (config.touchHapticsEnabled) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(18, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(18)
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .alpha(config.touchOpacity)
    ) {
        // TOP SHOULDER & MENU BUTTONS ROW
        // Left Shoulders (L1, L2)
        Box(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(top = 10.dp, start = 16.dp)
                .offset { IntOffset(layout.leftShoulderOffset.x.roundToInt(), layout.leftShoulderOffset.y.roundToInt()) }
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ShoulderButton("L2", onTouchChange = { pressed ->
                    controllerState.l2 = pressed
                    if (pressed) vibrate()
                })
                ShoulderButton("L1", onTouchChange = { pressed ->
                    controllerState.l1 = pressed
                    if (pressed) vibrate()
                })
            }
        }

        // Quick Menu Trigger (Center Top)
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 10.dp)
                .offset { IntOffset(layout.menuButtonOffset.x.roundToInt(), layout.menuButtonOffset.y.roundToInt()) }
                .size(46.dp)
                .clip(CircleShape)
                .background(
                    androidx.compose.ui.graphics.Brush.radialGradient(
                        listOf(Color(0xFFB8B9BC), Color(0xFFA2A3A6), Color(0xFF707174))
                    )
                )
                .border(1.5.dp, Color(0xFF505154), CircleShape)
                .clickable {
                    vibrate()
                    onMenuClick()
                }
                .testTag("in_game_menu_button"),
            contentAlignment = Alignment.Center
        ) {
            AidzStationLogo(size = 26.dp)
        }

        // Right Shoulders (R1, R2)
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 10.dp, end = 16.dp)
                .offset { IntOffset(layout.rightShoulderOffset.x.roundToInt(), layout.rightShoulderOffset.y.roundToInt()) }
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ShoulderButton("R1", onTouchChange = { pressed ->
                    controllerState.r1 = pressed
                    if (pressed) vibrate()
                })
                ShoulderButton("R2", onTouchChange = { pressed ->
                    controllerState.r2 = pressed
                    if (pressed) vibrate()
                })
            }
        }

        // BOTTOM CONTROLS

        // 1. D-PAD & LEFT ANALOG
        // 1. D-PAD CLUSTER
        Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(bottom = if (isLandscape) 20.dp else 120.dp, start = 16.dp)
                .offset { IntOffset(layout.dpadOffset.x.roundToInt(), layout.dpadOffset.y.roundToInt()) }
        ) {
            PsxDpad(
                controllerState = controllerState,
                onVibrate = { vibrate() }
            )
        }

        // 2. LEFT ANALOG STICK (L3)
        if (config.isDualShockAnalog) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(
                        bottom = if (isLandscape) 20.dp else 16.dp,
                        start = if (isLandscape) 160.dp else 36.dp
                    )
                    .offset { IntOffset(layout.leftStickOffset.x.roundToInt(), layout.leftStickOffset.y.roundToInt()) }
            ) {
                AnalogThumbstick(
                    label = "L3",
                    onPositionChange = { x, y ->
                        controllerState.leftStickX = (x * 32767).toInt().toShort()
                        controllerState.leftStickY = (y * 32767).toInt().toShort()
                    },
                    onThumbClick = {
                        controllerState.l3 = true
                        vibrate()
                    },
                    onThumbRelease = {
                        controllerState.l3 = false
                    }
                )
            }
        }

        // 3. SYSTEM BUTTONS (SELECT & START)
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 24.dp)
                .offset { IntOffset(layout.systemButtonsOffset.x.roundToInt(), layout.systemButtonsOffset.y.roundToInt()) }
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                PillSystemButton("SELECT", onTouchChange = { pressed ->
                    controllerState.select = pressed
                    if (pressed) vibrate()
                })
                PillSystemButton("START", onTouchChange = { pressed ->
                    controllerState.start = pressed
                    if (pressed) vibrate()
                })
            }
        }

        // 4. RIGHT ANALOG STICK (R3)
        if (config.isDualShockAnalog) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(
                        bottom = if (isLandscape) 20.dp else 16.dp,
                        end = if (isLandscape) 160.dp else 36.dp
                    )
                    .offset { IntOffset(layout.rightStickOffset.x.roundToInt(), layout.rightStickOffset.y.roundToInt()) }
            ) {
                AnalogThumbstick(
                    label = "R3",
                    onPositionChange = { x, y ->
                        controllerState.rightStickX = (x * 32767).toInt().toShort()
                        controllerState.rightStickY = (y * 32767).toInt().toShort()
                    },
                    onThumbClick = {
                        controllerState.r3 = true
                        vibrate()
                    },
                    onThumbRelease = {
                        controllerState.r3 = false
                    }
                )
            }
        }

        // 5. ACTION BUTTONS (TRIANGLE, CIRCLE, CROSS, SQUARE) - MOVES AS GROUP
        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = if (isLandscape) 20.dp else 120.dp, end = 16.dp)
                .offset { IntOffset(layout.actionButtonsOffset.x.roundToInt(), layout.actionButtonsOffset.y.roundToInt()) }
        ) {
            PsxActionButtons(
                controllerState = controllerState,
                onVibrate = { vibrate() }
            )
        }
    }
}

private fun Modifier.gamepadButton(
    onTouchChange: (Boolean) -> Unit,
    onVisualChange: (Boolean) -> Unit
): Modifier = this.pointerInput(Unit) {
    awaitPointerEventScope {
        var currentlyPressed = false
        while (true) {
            val event = awaitPointerEvent()
            val margin = 24f
            val isNowPressed = event.changes.any { change ->
                change.pressed &&
                change.position.x >= -margin && change.position.x <= size.width + margin &&
                change.position.y >= -margin && change.position.y <= size.height + margin
            }
            if (isNowPressed != currentlyPressed) {
                currentlyPressed = isNowPressed
                onVisualChange(isNowPressed)
                onTouchChange(isNowPressed)
            }
            event.changes.forEach { it.consume() }
        }
    }
}

@Composable
private fun ShoulderButton(label: String, onTouchChange: (Boolean) -> Unit) {
    var isPressed by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .size(width = 56.dp, height = 38.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(if (isPressed) PsxConsoleGrey else PsxCardElevated.copy(alpha = 0.9f))
            .border(1.dp, PsxConsoleGrey.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
            .gamepadButton(
                onTouchChange = onTouchChange,
                onVisualChange = { isPressed = it }
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = if (isPressed) Color.Black else PsxTextPrimary
        )
    }
}

@Composable
private fun PillSystemButton(label: String, onTouchChange: (Boolean) -> Unit) {
    var isPressed by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .size(width = 54.dp, height = 28.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(if (isPressed) PsxLightGrey else PsxCardSurface.copy(alpha = 0.85f))
            .border(1.dp, PsxConsoleGrey.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
            .gamepadButton(
                onTouchChange = onTouchChange,
                onVisualChange = { isPressed = it }
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = if (isPressed) Color.Black else PsxTextSecondary
        )
    }
}

@Composable
private fun PsxDpad(controllerState: ControllerState, onVibrate: () -> Unit) {
    val size = 130.dp
    val buttonSize = 44.dp

    Box(
        modifier = Modifier
            .size(size)
            .background(Color.Transparent)
    ) {
        // Center cross background body
        Box(
            modifier = Modifier
                .size(44.dp, 126.dp)
                .align(Alignment.Center)
                .clip(RoundedCornerShape(6.dp))
                .background(PsxCardElevated.copy(alpha = 0.9f))
                .border(1.dp, PsxCardBorder, RoundedCornerShape(6.dp))
        )
        Box(
            modifier = Modifier
                .size(126.dp, 44.dp)
                .align(Alignment.Center)
                .clip(RoundedCornerShape(6.dp))
                .background(PsxCardElevated.copy(alpha = 0.9f))
                .border(1.dp, PsxCardBorder, RoundedCornerShape(6.dp))
        )

        // UP
        DpadDirectionButton(
            arrow = "▲",
            modifier = Modifier.align(Alignment.TopCenter).size(buttonSize),
            onTouchChange = { pressed ->
                controllerState.dpadUp = pressed
                if (pressed) onVibrate()
            }
        )
        // DOWN
        DpadDirectionButton(
            arrow = "▼",
            modifier = Modifier.align(Alignment.BottomCenter).size(buttonSize),
            onTouchChange = { pressed ->
                controllerState.dpadDown = pressed
                if (pressed) onVibrate()
            }
        )
        // LEFT
        DpadDirectionButton(
            arrow = "◀",
            modifier = Modifier.align(Alignment.CenterStart).size(buttonSize),
            onTouchChange = { pressed ->
                controllerState.dpadLeft = pressed
                if (pressed) onVibrate()
            }
        )
        // RIGHT
        DpadDirectionButton(
            arrow = "▶",
            modifier = Modifier.align(Alignment.CenterEnd).size(buttonSize),
            onTouchChange = { pressed ->
                controllerState.dpadRight = pressed
                if (pressed) onVibrate()
            }
        )
    }
}

@Composable
private fun DpadDirectionButton(
    arrow: String,
    modifier: Modifier,
    onTouchChange: (Boolean) -> Unit
) {
    var isPressed by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(if (isPressed) PsxConsoleGrey else Color.Transparent)
            .gamepadButton(
                onTouchChange = onTouchChange,
                onVisualChange = { isPressed = it }
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = arrow,
            fontSize = 14.sp,
            color = if (isPressed) Color.Black else PsxTextPrimary
        )
    }
}

@Composable
private fun PsxActionButtons(controllerState: ControllerState, onVibrate: () -> Unit) {
    val size = 130.dp
    val buttonSize = 46.dp

    Box(
        modifier = Modifier
            .size(size)
            .background(Color.Transparent)
    ) {
        // TRIANGLE (Green) - Top
        PsxActionButton(
            type = PsxSymbolType.TRIANGLE,
            symbolColor = PsxTriangleGreen,
            modifier = Modifier.align(Alignment.TopCenter).size(buttonSize),
            onTouchChange = { pressed ->
                controllerState.triangle = pressed
                if (pressed) onVibrate()
            }
        )
        // CIRCLE (Red) - Right
        PsxActionButton(
            type = PsxSymbolType.CIRCLE,
            symbolColor = PsxCircleRed,
            modifier = Modifier.align(Alignment.CenterEnd).size(buttonSize),
            onTouchChange = { pressed ->
                controllerState.circle = pressed
                if (pressed) onVibrate()
            }
        )
        // CROSS (Blue) - Bottom
        PsxActionButton(
            type = PsxSymbolType.CROSS,
            symbolColor = PsxCrossBlue,
            modifier = Modifier.align(Alignment.BottomCenter).size(buttonSize),
            onTouchChange = { pressed ->
                controllerState.cross = pressed
                if (pressed) onVibrate()
            }
        )
        // SQUARE (Pink) - Left
        PsxActionButton(
            type = PsxSymbolType.SQUARE,
            symbolColor = PsxSquarePink,
            modifier = Modifier.align(Alignment.CenterStart).size(buttonSize),
            onTouchChange = { pressed ->
                controllerState.square = pressed
                if (pressed) onVibrate()
            }
        )
    }
}

@Composable
private fun PsxActionButton(
    type: PsxSymbolType,
    symbolColor: Color,
    modifier: Modifier,
    onTouchChange: (Boolean) -> Unit
) {
    var isPressed by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .clip(CircleShape)
            .background(if (isPressed) symbolColor.copy(alpha = 0.45f) else PsxCardElevated.copy(alpha = 0.9f))
            .border(2.dp, symbolColor.copy(alpha = if (isPressed) 1f else 0.7f), CircleShape)
            .gamepadButton(
                onTouchChange = onTouchChange,
                onVisualChange = { isPressed = it }
            ),
        contentAlignment = Alignment.Center
    ) {
        PsxSymbolIcon(
            type = type,
            size = 20.dp,
            strokeWidth = 2.8.dp,
            customColor = if (isPressed) Color.White else symbolColor
        )
    }
}

@Composable
private fun AnalogThumbstick(
    label: String,
    onPositionChange: (Float, Float) -> Unit,
    onThumbClick: () -> Unit,
    onThumbRelease: () -> Unit
) {
    val outerSize = 80.dp
    val thumbSize = 38.dp
    var offsetX by remember { mutableStateOf(0f) }
    var offsetY by remember { mutableStateOf(0f) }
    val maxRadius = 32f

    Box(
        modifier = Modifier
            .size(outerSize)
            .clip(CircleShape)
            .background(PsxCardElevated.copy(alpha = 0.8f))
            .border(1.5.dp, PsxConsoleGrey.copy(alpha = 0.5f), CircleShape)
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull()
                        if (change != null && change.pressed) {
                            val rawX = change.position.x - size.width / 2f
                            val rawY = change.position.y - size.height / 2f
                            val dist = kotlin.math.sqrt(rawX * rawX + rawY * rawY)
                            if (dist > 0f) {
                                val clampedDist = dist.coerceAtMost(maxRadius)
                                offsetX = (rawX / dist) * clampedDist
                                offsetY = (rawY / dist) * clampedDist
                            } else {
                                offsetX = 0f
                                offsetY = 0f
                            }
                            val normX = (offsetX / maxRadius).coerceIn(-1f, 1f)
                            val normY = (offsetY / maxRadius).coerceIn(-1f, 1f)
                            onPositionChange(normX, normY)
                            change.consume()
                        } else {
                            offsetX = 0f
                            offsetY = 0f
                            onPositionChange(0f, 0f)
                        }
                    }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
                .size(thumbSize)
                .clip(CircleShape)
                .background(PsxLightGrey)
                .border(1.5.dp, Color(0xFF6B6D74), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF33353B)
            )
        }
    }
}
