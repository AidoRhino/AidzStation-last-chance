package com.example.psx.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.psx.data.GameDiscFormat
import com.example.psx.data.GameItem
import com.example.psx.data.GameRepository
import com.example.psx.ui.components.PlayStationPatternBackground
import com.example.psx.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs

enum class LibraryDisplayMode {
    CAROUSEL,
    LIST
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun GameLibraryScreen(
    repository: GameRepository,
    onLaunchGame: (GameItem) -> Unit,
    onBack: () -> Unit,
    errorMessage: String? = null,
    onDismissError: () -> Unit = {},
    onNavigateSettings: () -> Unit = {},
    onNavigateControls: () -> Unit = {},
    onNavigateMemoryCards: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val games by repository.games.collectAsState()
    val isScanning by repository.isScanning.collectAsState()
    val scanStatus by repository.scanStatus.collectAsState()
    val sourceFolderName by repository.sourceFolderName.collectAsState()

    var displayMode by remember { mutableStateOf(LibraryDisplayMode.CAROUSEL) }
    var searchQuery by remember { mutableStateOf("") }
    var isSearchActive by remember { mutableStateOf(false) }
    var infoMessage by remember { mutableStateOf<String?>(null) }
    var isImporting by remember { mutableStateOf(false) }
    var importStatusText by remember { mutableStateOf("") }

    // Persistent editing game ID across lifecycle & pickers
    var activeEditingGameId by rememberSaveable { mutableStateOf<String?>(null) }
    var showBoxArtDialog by remember { mutableStateOf(false) }
    var customSearchTitle by remember { mutableStateOf("") }
    var customImageUrl by remember { mutableStateOf("") }
    var isFetchingCoverForGameId by remember { mutableStateOf<String?>(null) }

    val activeEditingGame = remember(activeEditingGameId, games) {
        games.firstOrNull { it.id == activeEditingGameId }
    }

    BackHandler {
        if (isSearchActive) {
            isSearchActive = false
            searchQuery = ""
        } else {
            onBack()
        }
    }

    // Local Box Art Picker using GetContent ("image/*")
    val localImagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        val game = activeEditingGame
        if (uri != null && game != null) {
            coroutineScope.launch {
                val ok = repository.setCustomBoxArt(game, uri)
                infoMessage = if (ok) "Box art updated for ${game.title}!" else "Could not load selected image"
                showBoxArtDialog = false
                activeEditingGameId = null
            }
        }
    }

    // Storage Access Framework Folder Picker for automatic PS1 game detection
    val folderPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { treeUri: Uri? ->
        if (treeUri != null) {
            coroutineScope.launch {
                val count = repository.setAndScanSourceFolder(treeUri)
                infoMessage = "Source folder scanned: found $count game disc(s)."
            }
        }
    }

    // Multiple Document Picker launcher allowing importing BOTH .cue AND .bin files together
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri>? ->
        if (!uris.isNullOrEmpty()) {
            coroutineScope.launch {
                isImporting = true
                importStatusText = "Importing ${uris.size} disc file(s)..."
                try {
                    val contentResolver = context.contentResolver
                    var importedCount = 0

                    withContext(Dispatchers.IO) {
                        for ((index, uri) in uris.withIndex()) {
                            var displayName = "game_disc_$index.bin"
                            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                                val nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                                if (nameIndex >= 0 && cursor.moveToFirst()) {
                                    displayName = cursor.getString(nameIndex)
                                }
                            }

                            val gamesDir = File(context.filesDir, "games").apply { mkdirs() }
                            val targetFile = File(gamesDir, displayName)

                            contentResolver.openInputStream(uri)?.use { input ->
                                FileOutputStream(targetFile).use { output ->
                                    input.copyTo(output)
                                }
                            }
                            importedCount++
                        }
                    }

                    importStatusText = "Scanning new discs..."
                    val count = repository.refreshGameLibrary()
                    infoMessage = "Successfully imported $importedCount file(s)! Library has $count game(s)."
                } catch (e: Exception) {
                    infoMessage = "Import failed: ${e.localizedMessage}"
                } finally {
                    isImporting = false
                }
            }
        }
    }

    val filteredGames = remember(games, searchQuery) {
        games.filter { game ->
            searchQuery.isBlank() ||
                game.title.contains(searchQuery, ignoreCase = true) ||
                game.format.name.contains(searchQuery, ignoreCase = true)
        }
    }

    PlayStationPatternBackground {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        if (isSearchActive) {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                placeholder = { Text("Search PlayStation games...", color = PsxTextSecondary, fontSize = 13.sp) },
                                singleLine = true,
                                trailingIcon = {
                                    IconButton(onClick = { isSearchActive = false; searchQuery = "" }) {
                                        Icon(Icons.Default.Close, contentDescription = "Close Search", tint = PsxTextPrimary)
                                    }
                                },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = PsxCrossBlue,
                                    unfocusedBorderColor = Color.Transparent,
                                    focusedContainerColor = PsxCardSurface.copy(alpha = 0.9f),
                                    unfocusedContainerColor = PsxCardSurface.copy(alpha = 0.9f),
                                    focusedTextColor = PsxTextPrimary,
                                    unfocusedTextColor = PsxTextPrimary
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("game_search_input")
                            )
                        } else {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    text = "GAME LIBRARY",
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.sp,
                                    fontSize = 16.sp,
                                    color = PsxTextPrimary
                                )
                                Box(
                                    modifier = Modifier
                                        .background(PsxCrossBlue, RoundedCornerShape(10.dp))
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "${filteredGames.size} DISCS",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onBack, modifier = Modifier.testTag("library_back_button")) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = PsxTextPrimary)
                        }
                    },
                    actions = {
                        if (!isSearchActive) {
                            IconButton(onClick = { isSearchActive = true }) {
                                Icon(Icons.Default.Search, contentDescription = "Search", tint = PsxTextPrimary)
                            }
                            IconButton(
                                onClick = {
                                    displayMode = if (displayMode == LibraryDisplayMode.CAROUSEL) LibraryDisplayMode.LIST else LibraryDisplayMode.CAROUSEL
                                },
                                modifier = Modifier.testTag("library_view_toggle")
                            ) {
                                Icon(
                                    imageVector = if (displayMode == LibraryDisplayMode.CAROUSEL) Icons.Default.ViewList else Icons.Default.ViewCarousel,
                                    contentDescription = "Toggle View",
                                    tint = PsxYellowAccent
                                )
                            }
                            Button(
                                onClick = { filePickerLauncher.launch(arrayOf("*/*")) },
                                colors = ButtonDefaults.buttonColors(containerColor = PsxTriangleGreen),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.padding(end = 8.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("+ Import", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
                )
            },
            bottomBar = {
                // PlayStation Classic Controller Button Guide Bar (Footer)
                Surface(
                    color = Color(0xFFF0F4FA),
                    tonalElevation = 6.dp,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFD0D8E6))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 7.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ControllerGuideItem(symbol = "✕", label = "Enter / Play", symbolColor = PsxCrossBlue)
                        ControllerGuideItem(symbol = "△", label = "Box Art", symbolColor = PsxTriangleGreen)
                        ControllerGuideItem(symbol = "□", label = "Scan Folder", symbolColor = PsxSquarePink)
                        ControllerGuideItem(symbol = "○", label = "Back", symbolColor = PsxCircleRed)
                    }
                }
            },
            containerColor = Color.Transparent
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentAlignment = Alignment.TopCenter
            ) {
                Column(
                    modifier = modifier
                        .fillMaxSize()
                        .padding(horizontal = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Scanning or status alerts
                    if (isScanning || isImporting || infoMessage != null) {
                        val alertText = when {
                            isScanning -> scanStatus
                            isImporting -> importStatusText
                            else -> infoMessage ?: ""
                        }
                        val alertColor = when {
                            isScanning -> PsxTriangleGreen
                            isImporting -> PsxYellowAccent
                            else -> PsxCrossBlue
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .background(PsxCardElevated, RoundedCornerShape(8.dp))
                                .border(1.dp, alertColor.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                if (isScanning || isImporting) {
                                    CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp, color = alertColor)
                                }
                                Text(text = alertText, fontSize = 11.sp, color = alertColor, maxLines = 1)
                            }
                            if (infoMessage != null && !isScanning && !isImporting) {
                                IconButton(onClick = { infoMessage = null }, modifier = Modifier.size(20.dp)) {
                                    Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = PsxTextSecondary, modifier = Modifier.size(14.dp))
                                }
                            }
                        }
                    }

                    if (filteredGames.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Icon(Icons.Default.DiscFull, contentDescription = null, tint = PsxConsoleGrey, modifier = Modifier.size(64.dp))
                                Text("No PlayStation Games Found", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = PsxTextPrimary)
                                Text("Tap '+ Import' or 'Scan Folder' to load PS1 games (.cue, .bin, .chd, .iso, .pbp)", fontSize = 12.sp, color = PsxTextSecondary)
                                Button(
                                    onClick = { folderPickerLauncher.launch(null) },
                                    colors = ButtonDefaults.buttonColors(containerColor = PsxCrossBlue)
                                ) {
                                    Text("Select Games Folder")
                                }
                            }
                        }
                    } else if (displayMode == LibraryDisplayMode.CAROUSEL) {
                        // PLAYSTATION CLASSIC ARCUATE JEWEL-CASE CAROUSEL
                        PsClassicCarouselView(
                            games = filteredGames,
                            onPlayGame = onLaunchGame,
                            onEditBoxArt = { game ->
                                activeEditingGameId = game.id
                                customSearchTitle = game.title
                                customImageUrl = ""
                                showBoxArtDialog = true
                            },
                            onDeleteGame = { game -> repository.removeGame(game) },
                            onOpenSettings = onNavigateSettings,
                            onOpenControls = onNavigateControls,
                            onOpenMemoryCards = onNavigateMemoryCards,
                            onOpenFolderScan = { folderPickerLauncher.launch(null) },
                            isFetchingCoverId = isFetchingCoverForGameId,
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                        )
                    } else {
                        // COMPACT LIST VIEW WITH UNZOOMED JEWEL CASE COVERS
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                        ) {
                            items(filteredGames, key = { it.id }) { game ->
                                GameListItem(
                                    game = game,
                                    isFetchingCover = isFetchingCoverForGameId == game.id,
                                    onPlay = { onLaunchGame(game) },
                                    onDelete = { repository.removeGame(game) },
                                    onEditBoxArt = {
                                        activeEditingGameId = game.id
                                        customSearchTitle = game.title
                                        customImageUrl = ""
                                        showBoxArtDialog = true
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // Custom Box Art Dialog
            if (showBoxArtDialog && activeEditingGame != null) {
                val game = activeEditingGame
                AlertDialog(
                    onDismissRequest = { showBoxArtDialog = false },
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Image, contentDescription = null, tint = PsxYellowAccent)
                            Text("PS1 Box Art Options", color = PsxTextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                    },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(text = "Game: ${game.title}", fontSize = 13.sp, color = PsxTextSecondary)

                            // 1. Choose from device / Gallery / Files
                            Button(
                                onClick = { localImagePicker.launch("image/*") },
                                colors = ButtonDefaults.buttonColors(containerColor = PsxCrossBlue),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("choose_local_boxart_button")
                            ) {
                                Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text("Choose Image from Device", fontWeight = FontWeight.Bold)
                            }

                            HorizontalDivider(color = PsxDarkCharcoal)

                            // 2. Search internet by title
                            Text("Search Online (Libretro Thumbnails)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PsxTextPrimary)
                            OutlinedTextField(
                                value = customSearchTitle,
                                onValueChange = { customSearchTitle = it },
                                placeholder = { Text("e.g. Final Fantasy IX (USA)") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Button(
                                onClick = {
                                    coroutineScope.launch {
                                        isFetchingCoverForGameId = game.id
                                        val ok = repository.manualFetchBoxArt(game, customSearchTitle)
                                        infoMessage = if (ok) "Box art updated!" else "No box art found for '$customSearchTitle'."
                                        isFetchingCoverForGameId = null
                                        showBoxArtDialog = false
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = PsxTriangleGreen)
                            ) {
                                Text("Search & Download Box Art", color = Color.Black, fontWeight = FontWeight.Bold)
                            }

                            HorizontalDivider(color = PsxDarkCharcoal)

                            // 3. Paste image URL
                            Text("Paste Image URL", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PsxTextPrimary)
                            OutlinedTextField(
                                value = customImageUrl,
                                onValueChange = { customImageUrl = it },
                                placeholder = { Text("https://example.com/cover.png") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            if (customImageUrl.isNotBlank()) {
                                Button(
                                    onClick = {
                                        coroutineScope.launch {
                                            val ok = repository.setCustomBoxArtFromUrl(game, customImageUrl.trim())
                                            infoMessage = if (ok) "Box art set from URL!" else "Failed to download image from URL"
                                            showBoxArtDialog = false
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = PsxCardElevated)
                                ) {
                                    Text("Apply Image URL")
                                }
                            }
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = { showBoxArtDialog = false }) {
                            Text("Done", color = PsxTextSecondary)
                        }
                    },
                    containerColor = PsxSurfaceDark,
                    shape = RoundedCornerShape(16.dp)
                )
            }

            // Error Dialog
            if (errorMessage != null) {
                AlertDialog(
                    onDismissRequest = onDismissError,
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = PsxCircleRed)
                            Text("Boot Error", color = PsxTextPrimary, fontWeight = FontWeight.Bold)
                        }
                    },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(text = errorMessage, fontSize = 13.sp, color = PsxTextPrimary)
                            Text(
                                text = "Tip: For .cue/.bin games, import BOTH the .cue and all .bin tracks together.",
                                fontSize = 11.sp,
                                color = PsxTextSecondary
                            )
                        }
                    },
                    confirmButton = {
                        Button(onClick = onDismissError, colors = ButtonDefaults.buttonColors(containerColor = PsxCrossBlue)) {
                            Text("OK")
                        }
                    },
                    containerColor = PsxSurfaceDark,
                    shape = RoundedCornerShape(16.dp)
                )
            }
        }
    }
}

/**
 * PlayStation Classic Arcuate Carousel.
 * Matches the official PlayStation Classic UI (download_42ad8f71.jpeg):
 * - Prominent 3D jewel case in center with adjacent games curving away
 * - Right-side game metadata (Title, Publisher, Year, 🎮 1 Player)
 * - Colorful PlayStation paint splash with bold "PLAY" button
 * - Bottom system icon dock (Briefcase, Gamepad, Memory Card, Display)
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PsClassicCarouselView(
    games: List<GameItem>,
    onPlayGame: (GameItem) -> Unit,
    onEditBoxArt: (GameItem) -> Unit,
    onDeleteGame: (GameItem) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenControls: () -> Unit,
    onOpenMemoryCards: () -> Unit,
    onOpenFolderScan: () -> Unit,
    isFetchingCoverId: String?,
    modifier: Modifier = Modifier
) {
    val pagerState = rememberPagerState(pageCount = { games.size })
    val activeGame = games.getOrNull(pagerState.currentPage) ?: games.first()
    val isLandscape = LocalConfiguration.current.screenWidthDp > LocalConfiguration.current.screenHeightDp

    Column(
        modifier = modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // TOP / CENTER: Curved Arc Carousel of 3D PS1 Jewel Cases
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            contentAlignment = Alignment.Center
        ) {
            HorizontalPager(
                state = pagerState,
                contentPadding = PaddingValues(horizontal = if (isLandscape) 180.dp else 70.dp),
                pageSpacing = if (isLandscape) 28.dp else 16.dp,
                modifier = Modifier.fillMaxSize()
            ) { page ->
                val game = games[page]
                val pageOffset = (pagerState.currentPage - page) + pagerState.currentPageOffsetFraction
                val absOffset = abs(pageOffset).coerceIn(0f, 2f)

                // Arcuate curve transformation (PlayStation Classic arch)
                val scale = 1.0f - (absOffset * 0.22f)
                val alpha = (1.0f - (absOffset * 0.38f)).coerceIn(0.4f, 1.0f)
                val translationY = absOffset * absOffset * 22.dp.value

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                            this.alpha = alpha
                            this.translationY = translationY
                        },
                    contentAlignment = Alignment.Center
                ) {
                    if (isLandscape) {
                        // Landscape / Wide: Side-by-side Case + Metadata (matching exact PS Classic screen)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp)
                        ) {
                            Ps1JewelCase3D(
                                game = game,
                                isFocused = absOffset < 0.2f,
                                isFetching = isFetchingCoverId == game.id,
                                onPlay = { onPlayGame(game) },
                                onEditBoxArt = { onEditBoxArt(game) },
                                modifier = Modifier.size(240.dp)
                            )

                            Spacer(Modifier.width(28.dp))

                            GameMetadataPanel(
                                game = game,
                                modifier = Modifier.widthIn(max = 280.dp)
                            )
                        }
                    } else {
                        // Portrait: Stacked Case + Centered Info
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Ps1JewelCase3D(
                                game = game,
                                isFocused = absOffset < 0.2f,
                                isFetching = isFetchingCoverId == game.id,
                                onPlay = { onPlayGame(game) },
                                onEditBoxArt = { onEditBoxArt(game) },
                                modifier = Modifier.size(210.dp)
                            )

                            if (absOffset < 0.3f) {
                                Spacer(Modifier.height(10.dp))
                                GameMetadataPanel(
                                    game = game,
                                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // PLAY SPLASH BUTTON (underneath featured case, exactly like the reference image)
        PlayStationPlaySplashButton(
            onClick = { onPlayGame(activeGame) },
            modifier = Modifier.padding(vertical = 4.dp)
        )

        // PLAYSTATION CLASSIC SYSTEM DOCK
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 6.dp, top = 2.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                PsClassicDockButton(
                    icon = Icons.Default.WorkOutline,
                    label = "Settings",
                    onClick = onOpenSettings
                )
                PsClassicDockButton(
                    icon = Icons.Default.Gamepad,
                    label = "Controls",
                    onClick = onOpenControls
                )
                PsClassicDockButton(
                    icon = Icons.Default.SdCard,
                    label = "Mem Cards",
                    onClick = onOpenMemoryCards
                )
                PsClassicDockButton(
                    icon = Icons.Default.FolderOpen,
                    label = "Folder",
                    onClick = onOpenFolderScan
                )
                PsClassicDockButton(
                    icon = Icons.Default.Image,
                    label = "Box Art",
                    onClick = { onEditBoxArt(activeGame) }
                )
            }
        }
    }
}

/**
 * Authentic 3D PS1 Jewel Case.
 * Features:
 * - Transparent acrylic glass double-beveled border with specular gloss
 * - Ridged black plastic hinge spine along left edge with authentic PlayStation vertical banner
 * - Uncropped square box art inside using ContentScale.Fit (guarantees the black PlayStation bar is never cut off!)
 * - Corner acrylic hinge clips
 */
@Composable
fun Ps1JewelCase3D(
    game: GameItem,
    isFocused: Boolean,
    isFetching: Boolean,
    onPlay: () -> Unit,
    onEditBoxArt: () -> Unit,
    modifier: Modifier = Modifier
) {
    val elevation = if (isFocused) 16.dp else 6.dp

    Box(
        modifier = modifier
            .shadow(elevation, RoundedCornerShape(8.dp), ambientColor = Color.Black, spotColor = Color(0xFF001940))
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF0A0F1D))
            .border(
                width = if (isFocused) 2.dp else 1.dp,
                brush = Brush.verticalGradient(
                    colors = if (isFocused) {
                        listOf(Color(0xFFE2EDFF), Color(0xFF5A8EE0), Color(0xFF1E3A70))
                    } else {
                        listOf(Color(0xFF6B7E9C), Color(0xFF2B3A54), Color(0xFF101B2E))
                    }
                ),
                shape = RoundedCornerShape(8.dp)
            )
            .clickable { onPlay() }
    ) {
        Row(modifier = Modifier.fillMaxSize()) {
            // AUTHENTIC LEFT HINGE SPINE (Black ridged plastic + vertical PlayStation strip)
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .width(22.dp)
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                Color(0xFF15171C), // deep edge shadow
                                Color(0xFF383C47), // ridged spine highlight
                                Color(0xFF1A1C22)  // inner crease
                            )
                        )
                    )
            ) {
                // Ridged horizontal texture lines
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val ridgeSpacing = 4.dp.toPx()
                    var y = 6.dp.toPx()
                    while (y < size.height - 6.dp.toPx()) {
                        drawLine(
                            color = Color.Black.copy(alpha = 0.6f),
                            start = Offset(0f, y),
                            end = Offset(size.width, y),
                            strokeWidth = 1.dp.toPx()
                        )
                        drawLine(
                            color = Color.White.copy(alpha = 0.2f),
                            start = Offset(0f, y + 1.dp.toPx()),
                            end = Offset(size.width, y + 1.dp.toPx()),
                            strokeWidth = 0.8.dp.toPx()
                        )
                        y += ridgeSpacing
                    }
                }

                // Vertical "PlayStation" strip
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .width(7.dp)
                        .align(Alignment.CenterEnd)
                        .background(Color.Black)
                )
            }

            // MAIN FRONT COVER ARTWORK AREA (Uncropped ContentScale.Fit)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                if (isFetching) {
                    CircularProgressIndicator(modifier = Modifier.size(32.dp), color = PsxCrossBlue, strokeWidth = 3.dp)
                } else if (game.coverPath != null && File(game.coverPath).exists()) {
                    AsyncImage(
                        model = File(game.coverPath),
                        contentDescription = "Official PS1 Box Art for ${game.title}",
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(2.dp),
                        contentScale = ContentScale.Fit // PRESERVES ENTIRE COVER & BLACK PLAYSTATION BAR
                    )
                } else {
                    // Fallback procedural CD disc artwork
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier.clickable { onEditBoxArt() }
                    ) {
                        Icon(Icons.Default.Album, contentDescription = null, tint = PsxConsoleGrey, modifier = Modifier.size(48.dp))
                        Spacer(Modifier.height(4.dp))
                        Text("NO COVER", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = PsxTextDisabled)
                        Text("+ Add Art", fontSize = 9.sp, color = PsxTriangleGreen)
                    }
                }

                // Specular Glass Reflection Sheen (diagonal light reflection across acrylic cover)
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val glossBrush = Brush.linearGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.18f),
                            Color.White.copy(alpha = 0.04f),
                            Color.Transparent,
                            Color.White.copy(alpha = 0.08f),
                            Color.Transparent
                        ),
                        start = Offset(0f, 0f),
                        end = Offset(size.width, size.height)
                    )
                    drawRect(brush = glossBrush)
                }
            }
        }

        // Top & Bottom Acrylic Hinge Clips
        Box(
            modifier = Modifier
                .size(width = 16.dp, height = 6.dp)
                .align(Alignment.TopStart)
                .offset(x = 10.dp, y = 2.dp)
                .background(Color.White.copy(alpha = 0.25f), RoundedCornerShape(2.dp))
        )
        Box(
            modifier = Modifier
                .size(width = 16.dp, height = 6.dp)
                .align(Alignment.BottomStart)
                .offset(x = 10.dp, y = (-2).dp)
                .background(Color.White.copy(alpha = 0.25f), RoundedCornerShape(2.dp))
        )
    }
}

/**
 * Game Metadata Panel (matching the right side of the PlayStation Classic screen)
 */
@Composable
private fun GameMetadataPanel(
    game: GameItem,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(
            text = game.title,
            fontSize = 17.sp,
            fontWeight = FontWeight.Black,
            color = Color.White,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            letterSpacing = 0.5.sp
        )

        // Inferred/clean publisher and format
        val publisherName = when {
            game.title.contains("Grand Theft", ignoreCase = true) -> "Rockstar Games"
            game.title.contains("Final Fantasy", ignoreCase = true) -> "Square Enix"
            game.title.contains("Metal Gear", ignoreCase = true) -> "Konami"
            game.title.contains("Resident Evil", ignoreCase = true) -> "Capcom"
            game.title.contains("Crash", ignoreCase = true) -> "Naughty Dog / Sony"
            game.title.contains("Gran Turismo", ignoreCase = true) -> "Polyphony Digital"
            game.title.contains("Tekken", ignoreCase = true) -> "Namco"
            game.isBuiltIn -> "Sony Computer Entertainment"
            else -> "PlayStation CD-ROM"
        }

        Text(
            text = publisherName,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = PsxTextSecondary
        )

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = if (game.isBuiltIn) "Interactive 3D" else game.format.name,
                fontSize = 11.sp,
                color = PsxCrossBlue,
                fontWeight = FontWeight.Bold
            )

            if (game.totalDiscs > 1) {
                Text(
                    text = "• Disc ${game.discNumber}/${game.totalDiscs}",
                    fontSize = 11.sp,
                    color = PsxYellowAccent
                )
            }

            if (game.fileSizeFormatted.isNotEmpty()) {
                Text(
                    text = "• ${game.fileSizeFormatted}",
                    fontSize = 11.sp,
                    color = PsxTextSecondary
                )
            }
        }

        Spacer(Modifier.height(2.dp))

        // "🎮 1 Player" or "🎮 1-2 Players" badge (iconic PlayStation Classic touch)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier
                .background(Color.White.copy(alpha = 0.12f), RoundedCornerShape(6.dp))
                .padding(horizontal = 8.dp, vertical = 3.dp)
        ) {
            Text(
                text = "🎮 1 Player",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}

/**
 * Colorful PlayStation Spray Paint Splash with Chunky "PLAY" Button.
 * Recreates the iconic PlayStation spray splash beneath the selected game.
 */
@Composable
private fun PlayStationPlaySplashButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clickable { onClick() }
            .testTag("classic_play_button"),
        contentAlignment = Alignment.Center
    ) {
        // Multi-color dynamic paint splatter canvas
        Canvas(modifier = Modifier.size(width = 170.dp, height = 52.dp)) {
            val w = size.width
            val h = size.height

            // Cyan/Blue splash (bottom-left)
            drawCircle(
                color = Color(0xFF00B0FF).copy(alpha = 0.75f),
                radius = 20.dp.toPx(),
                center = Offset(w * 0.32f, h * 0.62f)
            )

            // Magenta/Pink splash (top-right)
            drawCircle(
                color = Color(0xFFFF4081).copy(alpha = 0.75f),
                radius = 22.dp.toPx(),
                center = Offset(w * 0.66f, h * 0.38f)
            )

            // Yellow accent splash (top-left)
            drawCircle(
                color = Color(0xFFFFD600).copy(alpha = 0.85f),
                radius = 12.dp.toPx(),
                center = Offset(w * 0.22f, h * 0.35f)
            )

            // Royal PlayStation blue splash (bottom-right)
            drawCircle(
                color = Color(0xFF2979FF).copy(alpha = 0.8f),
                radius = 18.dp.toPx(),
                center = Offset(w * 0.72f, h * 0.68f)
            )

            // Green splatter dots
            drawCircle(color = Color(0xFF00E676), radius = 3.5.dp.toPx(), center = Offset(w * 0.16f, h * 0.58f))
            drawCircle(color = Color(0xFFFF5252), radius = 3.5.dp.toPx(), center = Offset(w * 0.84f, h * 0.42f))
            drawCircle(color = Color(0xFF00E5FF), radius = 2.5.dp.toPx(), center = Offset(w * 0.5f, h * 0.88f))
        }

        // Bold white "PLAY" text with shadow
        Text(
            text = "PLAY",
            fontSize = 24.sp,
            fontWeight = FontWeight.Black,
            color = Color.White,
            letterSpacing = 2.sp,
            style = androidx.compose.ui.text.TextStyle(
                shadow = androidx.compose.ui.graphics.Shadow(
                    color = Color.Black.copy(alpha = 0.8f),
                    offset = Offset(2f, 2f),
                    blurRadius = 4f
                )
            )
        )
    }
}

/**
 * PlayStation Classic Floating Bottom Dock Button.
 */
@Composable
private fun PsClassicDockButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp),
        modifier = Modifier.clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color.White.copy(alpha = 0.18f))
                .border(1.5.dp, Color.White.copy(alpha = 0.45f), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = Color.White,
                modifier = Modifier.size(22.dp)
            )
        }
        Text(
            text = label,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = PsxTextSecondary
        )
    }
}

/**
 * Controller Button Guide item for the bottom footer
 */
@Composable
private fun ControllerGuideItem(
    symbol: String,
    label: String,
    symbolColor: Color
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Box(
            modifier = Modifier
                .size(18.dp)
                .background(Color(0xFF2B3A54), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = symbol,
                fontSize = 11.sp,
                fontWeight = FontWeight.Black,
                color = symbolColor
            )
        }
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color(0xFF2B3A54)
        )
    }
}

/**
 * List Item for the compact list view
 */
@Composable
private fun GameListItem(
    game: GameItem,
    isFetchingCover: Boolean,
    onPlay: () -> Unit,
    onDelete: () -> Unit,
    onEditBoxArt: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onPlay() },
        colors = CardDefaults.cardColors(containerColor = PsxCardSurface.copy(alpha = 0.9f)),
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, PsxDarkCharcoal)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                // Miniature Jewel Case
                Ps1JewelCase3D(
                    game = game,
                    isFocused = false,
                    isFetching = isFetchingCover,
                    onPlay = onPlay,
                    onEditBoxArt = onEditBoxArt,
                    modifier = Modifier.size(54.dp)
                )

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = game.title,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = PsxTextPrimary,
                        maxLines = 1
                    )
                    Spacer(Modifier.height(2.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = game.format.name,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = PsxCrossBlue
                        )
                        if (game.totalDiscs > 1) {
                            Text(
                                text = "• Disc ${game.discNumber}/${game.totalDiscs}",
                                fontSize = 10.sp,
                                color = PsxYellowAccent
                            )
                        }
                        if (game.fileSizeFormatted.isNotEmpty()) {
                            Text(
                                text = "• ${game.fileSizeFormatted}",
                                fontSize = 10.sp,
                                color = PsxTextSecondary
                            )
                        }
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onPlay) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = PsxTriangleGreen, modifier = Modifier.size(24.dp))
                }
                IconButton(onClick = onEditBoxArt) {
                    Icon(Icons.Default.Image, contentDescription = "Edit Box Art", tint = PsxYellowAccent, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}
