package com.example.psx.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.psx.core.PerformanceProfile
import com.example.psx.core.PsxConfiguration
import com.example.psx.core.PsxEmulatorEngine
import com.example.psx.data.BiosManager
import com.example.psx.ui.theme.*

@Composable
fun SetupWizardScreen(
    engine: PsxEmulatorEngine,
    biosManager: BiosManager,
    onComplete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var step by remember { mutableIntStateOf(1) }
    var selectedProfile by remember { mutableStateOf(engine.config.profile) }

    BackHandler {
        if (step > 1) step-- else onComplete()
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(PsxNearBlack)
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState()),
            colors = CardDefaults.cardColors(containerColor = PsxCardSurface),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, PsxConsoleGrey.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Step Indicator Dots
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    for (i in 1..3) {
                        Box(
                            modifier = Modifier
                                .size(if (i == step) 10.dp else 6.dp)
                                .background(
                                    if (i == step) PsxTriangleGreen else PsxDarkCharcoal,
                                    CircleShape
                                )
                        )
                        if (i < 3) Spacer(Modifier.width(8.dp))
                    }
                }

                when (step) {
                    1 -> {
                        // WELCOME & LEGAL NOTICE
                        Text(
                            text = "WELCOME TO PLAYSTATION RETRO",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            color = PsxTextPrimary,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "A high-performance PlayStation 1 emulator powered by the PCSX-ReARMed native core with authentic 1994 console design.",
                            fontSize = 13.sp,
                            color = PsxTextSecondary,
                            lineHeight = 18.sp
                        )

                        Card(
                            colors = CardDefaults.cardColors(containerColor = PsxCardElevated),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("LEGAL NOTICE & ROM USAGE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = PsxYellowAccent)
                                Text(
                                    "Please use games created from your own legally purchased PlayStation game discs. This application respects copyright and does not bundle proprietary commercial games.",
                                    fontSize = 12.sp,
                                    color = PsxTextSecondary,
                                    lineHeight = 16.sp
                                )
                            }
                        }

                        Button(
                            onClick = { step = 2 },
                            colors = ButtonDefaults.buttonColors(containerColor = PsxCrossBlue),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth().testTag("wizard_step1_next")
                        ) {
                            Text("Next: BIOS & Compatibility", fontWeight = FontWeight.Bold)
                        }
                    }

                    2 -> {
                        // BIOS SETUP
                        Text(
                            text = "STEP 2: BIOS CONFIGURATION",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            color = PsxTextPrimary,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "AidzStation comes with a built-in PCSX High-Level Emulation (HLE) BIOS engine that plays most titles out of the box without any setup.",
                            fontSize = 13.sp,
                            color = PsxTextSecondary,
                            lineHeight = 18.sp
                        )

                        Card(
                            colors = CardDefaults.cardColors(containerColor = PsxCardElevated),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = PsxTriangleGreen)
                                Column {
                                    Text("HLE BIOS Active", fontWeight = FontWeight.Bold, color = PsxTriangleGreen, fontSize = 13.sp)
                                    Text("Official dumps (SCPH1001.BIN) can also be imported at any time in the BIOS manager.", fontSize = 11.sp, color = PsxTextSecondary)
                                }
                            }
                        }

                        Button(
                            onClick = { step = 3 },
                            colors = ButtonDefaults.buttonColors(containerColor = PsxCrossBlue),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth().testTag("wizard_step2_next")
                        ) {
                            Text("Next: Performance Profile", fontWeight = FontWeight.Bold)
                        }
                    }

                    3 -> {
                        // PERFORMANCE PROFILE SELECTION
                        Text(
                            text = "STEP 3: SELECT PERFORMANCE PROFILE",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            color = PsxTextPrimary,
                            letterSpacing = 1.sp
                        )

                        PerformanceProfile.entries.forEach { prof ->
                            val isSelected = selectedProfile == prof
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(
                                        1.5.dp,
                                        if (isSelected) PsxTriangleGreen else PsxDarkCharcoal,
                                        RoundedCornerShape(10.dp)
                                    ),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) PsxCardElevated else PsxSurfaceDark
                                )
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    RadioButton(
                                        selected = isSelected,
                                        onClick = { selectedProfile = prof },
                                        colors = RadioButtonDefaults.colors(selectedColor = PsxTriangleGreen)
                                    )
                                    Column {
                                        Text(prof.label, fontWeight = FontWeight.Bold, color = PsxTextPrimary, fontSize = 13.sp)
                                        Text(prof.description, fontSize = 11.sp, color = PsxTextSecondary)
                                    }
                                }
                            }
                        }

                        Button(
                            onClick = {
                                val newConfig = engine.config.copy(profile = selectedProfile)
                                PsxConfiguration.save(context, newConfig)
                                onComplete()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PsxTriangleGreen),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth().testTag("wizard_finish_button")
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = Color.Black)
                            Spacer(Modifier.width(6.dp))
                            Text("FINISH SETUP & ENTER CONSOLE", color = Color.Black, fontWeight = FontWeight.Black)
                        }
                    }
                }
            }
        }
    }
}
