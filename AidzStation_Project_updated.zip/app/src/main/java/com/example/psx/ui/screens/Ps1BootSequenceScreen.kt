package com.example.psx.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.psx.audio.Ps1BootAudioSynth
import com.example.psx.ui.components.AidzStationLogo
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Authentic 1994 PS1-style boot sequence.
 * Stage 1: White screen with luminous diamond and ethereal chime (~3.2s).
 * Stage 2: Deep black screen with 3D logo zoom and resonant synth bass tone (~3.8s).
 * User can tap anywhere to skip instantly.
 */
@Composable
fun Ps1BootSequenceScreen(
    onFinished: () -> Unit,
    modifier: Modifier = Modifier
) {
    var stage by remember { mutableStateOf(1) } // 1 = White Chime Screen, 2 = Black Logo Screen
    var showSkipHint by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        // Start procedural audio synthesis
        Ps1BootAudioSynth.playBootChimeAndDrone()

        // Reveal subtle skip prompt after 1.5s
        delay(1500)
        showSkipHint = true

        // Advance to Stage 2 (Black screen) at 3.3s
        delay(1800)
        stage = 2

        // Complete boot sequence at 7.0s
        delay(3700)
        Ps1BootAudioSynth.stop()
        onFinished()
    }

    DisposableEffect(Unit) {
        onDispose {
            Ps1BootAudioSynth.stop()
        }
    }

    val interactionSource = remember { MutableInteractionSource() }

    Box(
        modifier = modifier
            .fillMaxSize()
            .clickable(
                interactionSource = interactionSource,
                indication = null
            ) {
                // Instant skip
                Ps1BootAudioSynth.stop()
                onFinished()
            },
        contentAlignment = Alignment.Center
    ) {
        if (stage == 1) {
            // STAGE 1: CRISP WHITE BACKGROUND WITH GLOWING DIAMOND CHIME
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFFEDEDED)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    // Luminous Orange/Gold Diamond Emblem
                    Canvas(modifier = Modifier.size(110.dp)) {
                        val w = size.width
                        val h = size.height
                        val cx = w / 2f
                        val cy = h / 2f
                        val r = w * 0.38f

                        // Outer golden diamond
                        val diamond = Path().apply {
                            moveTo(cx, cy - r)
                            lineTo(cx + r, cy)
                            lineTo(cx, cy + r)
                            lineTo(cx - r, cy)
                            close()
                        }
                        drawPath(path = diamond, color = Color(0xFFF58220), style = Fill)

                        // Inner dark cutout
                        val innerR = r * 0.45f
                        val innerDiamond = Path().apply {
                            moveTo(cx, cy - innerR)
                            lineTo(cx + innerR, cy)
                            lineTo(cx, cy + innerR)
                            lineTo(cx - innerR, cy)
                            close()
                        }
                        drawPath(path = innerDiamond, color = Color(0xFF1E2025), style = Fill)

                        // Diamond specular bevel line
                        drawPath(path = diamond, color = Color(0xFFFFD54F), style = Stroke(width = 3.dp.toPx()))
                    }

                    Spacer(Modifier.height(28.dp))

                    Text(
                        text = "AIDZ COMPUTER ENTERTAINMENT",
                        color = Color(0xFF1C1E24),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 2.5.sp,
                        fontFamily = FontFamily.SansSerif
                    )

                    Spacer(Modifier.height(8.dp))

                    Text(
                        text = "LICENSED BY RETRO SYSTEMS",
                        color = Color(0xFF555964),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                }
            }
        } else {
            // STAGE 2: DEEP BLACK WITH 3D LOGO AND RESONANT SYNTH TONE
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF0A0B0E)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    // Geometric 3D AidzStation Symbol
                    AidzStationLogo(
                        size = 130.dp
                    )

                    Spacer(Modifier.height(26.dp))

                    Text(
                        text = "AidzStation",
                        color = Color(0xFFF0F2F6),
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 3.sp,
                        fontFamily = FontFamily.SansSerif
                    )

                    Spacer(Modifier.height(10.dp))

                    Text(
                        text = "PCSX-ReARMed High Performance Core",
                        color = Color(0xFF9EA3B0),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        letterSpacing = 1.2.sp
                    )

                    Spacer(Modifier.height(4.dp))

                    Text(
                        text = "Enhanced 3D Precision & Audio Architecture",
                        color = Color(0xFF646975),
                        fontSize = 9.sp,
                        letterSpacing = 1.sp
                    )
                }
            }
        }

        // Tap to skip prompt
        AnimatedVisibility(
            visible = showSkipHint,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 28.dp)
        ) {
            Text(
                text = "TAP SCREEN TO SKIP",
                color = if (stage == 1) Color(0xFF888B94) else Color(0xFF4C515D),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp
            )
        }
    }
}
