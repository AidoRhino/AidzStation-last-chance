package com.example.psx.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Process
import android.util.Log
import java.util.concurrent.atomic.AtomicBoolean

/**
 * High-performance, asynchronous AudioTrack streamer for PSX emulation.
 * Features an internal Ring Buffer that decouples the emulation thread from audio hardware writes.
 * Enforces strict stereo pair alignment (multiples of 2 shorts) to prevent channel-phase swapping
 * and robotic audio distortion in games like Spyro the Dragon and Final Fantasy IX.
 */
class PsxAudioPlayer(private val sampleRate: Int = 44100) {
    companion object {
        private const val TAG = "PsxAudioPlayer"

        // Exactly 65,536 shorts (32,768 stereo frames, ~743ms buffer at 44.1kHz).
        // Power-of-two size guarantees bitwise AND mask wrapping never misaligns stereo Left/Right pairs.
        private const val RING_BUFFER_SIZE = 65536
        private const val RING_BUFFER_MASK = 65535

        // Prebuffer ~46ms of audio before starting initial output to prevent cold-start underruns
        private const val PREBUFFER_THRESHOLD = 2048
    }

    private var audioTrack: AudioTrack? = null
    private val isRunning = AtomicBoolean(false)
    private var volume: Float = 1.0f

    // Ring Buffer & Thread Sync
    private val ringBuffer = ShortArray(RING_BUFFER_SIZE)
    private var writePos = 0
    private var readPos = 0
    private var bufferedCount = 0
    private val bufferLock = Object()
    private var hasPrebuffered = false

    private var feederThread: Thread? = null

    init {
        initTrack()
    }

    @Synchronized
    private fun initTrack() {
        try {
            val minBufferSize = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_STEREO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            // Generous hardware buffer size (4x min buffer size) to prevent hardware underruns
            val hardwareBufferSize = if (minBufferSize > 0) (minBufferSize * 4).coerceAtLeast(16384) else 32768

            val attributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()

            val format = AudioFormat.Builder()
                .setSampleRate(sampleRate)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                .build()

            audioTrack = AudioTrack(
                attributes,
                format,
                hardwareBufferSize,
                AudioTrack.MODE_STREAM,
                AudioManager.AUDIO_SESSION_ID_GENERATE
            )
            setVolume(volume)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize AudioTrack: ${e.message}")
        }
    }

    @Synchronized
    fun start() {
        if (isRunning.get()) return
        isRunning.set(true)
        hasPrebuffered = false

        try {
            audioTrack?.play()
        } catch (e: Exception) {
            Log.e(TAG, "Audio play error: ${e.message}")
        }

        startFeederThread()
    }

    private fun startFeederThread() {
        feederThread?.interrupt()
        feederThread = Thread({
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            val chunk = ShortArray(1024) // 512 stereo frames

            while (isRunning.get()) {
                var toRead = 0

                synchronized(bufferLock) {
                    // Initial pre-buffering check
                    while ((!hasPrebuffered && bufferedCount < PREBUFFER_THRESHOLD || bufferedCount < 128) && isRunning.get()) {
                        try {
                            bufferLock.wait(4)
                        } catch (e: InterruptedException) {
                            return@Thread
                        }
                    }

                    if (!isRunning.get()) return@Thread
                    hasPrebuffered = true

                    // Always read an exact even number of shorts (stereo pairs)
                    toRead = minOf(chunk.size, bufferedCount) and 1.inv()

                    if (toRead > 0) {
                        val firstPart = minOf(toRead, RING_BUFFER_SIZE - readPos)
                        System.arraycopy(ringBuffer, readPos, chunk, 0, firstPart)
                        if (toRead > firstPart) {
                            System.arraycopy(ringBuffer, 0, chunk, firstPart, toRead - firstPart)
                        }
                        readPos = (readPos + toRead) and RING_BUFFER_MASK
                        bufferedCount -= toRead
                        if (bufferedCount < 0) bufferedCount = 0
                    }
                }

                if (toRead > 0) {
                    val track = audioTrack
                    if (track != null && track.playState == AudioTrack.PLAYSTATE_PLAYING) {
                        var written = 0
                        while (written < toRead && isRunning.get()) {
                            val res = track.write(chunk, written, toRead - written, AudioTrack.WRITE_BLOCKING)
                            if (res > 0) {
                                written += res
                            } else {
                                break
                            }
                        }
                    }
                }
            }
        }, "PsxAudioFeederThread").apply {
            isDaemon = true
            priority = Thread.MAX_PRIORITY
            start()
        }
    }

    @Synchronized
    fun pause() {
        isRunning.set(false)
        synchronized(bufferLock) {
            bufferLock.notifyAll()
        }
        try {
            feederThread?.join(50)
        } catch (_: Exception) {}
        feederThread = null

        try {
            audioTrack?.pause()
            audioTrack?.flush()
        } catch (e: Exception) {
            Log.e(TAG, "Audio pause error: ${e.message}")
        }

        // Clear ring buffer on pause
        synchronized(bufferLock) {
            writePos = 0
            readPos = 0
            bufferedCount = 0
        }
    }

    /**
     * Non-blocking sample write from the emulation core.
     * Enforces even stereo boundaries so left and right audio channels never desync.
     */
    fun writeSamples(samples: ShortArray, offset: Int, count: Int, blocking: Boolean = false) {
        if (count <= 0) return
        // Enforce strictly even sample count (stereo pairs)
        val evenCount = count and 1.inv()
        if (evenCount <= 0) return

        if (!isRunning.get()) return // paused/stopped: drop samples instead of restarting the feeder

        synchronized(bufferLock) {
            val freeSpace = RING_BUFFER_SIZE - bufferedCount
            if (evenCount > freeSpace) {
                // Drop excess in strictly even multiples of 2 to keep stereo alignment
                val excess = (evenCount - freeSpace + 1) and 1.inv()
                readPos = (readPos + excess) and RING_BUFFER_MASK
                bufferedCount -= excess
                if (bufferedCount < 0) bufferedCount = 0
            }

            val firstPart = minOf(evenCount, RING_BUFFER_SIZE - writePos)
            System.arraycopy(samples, offset, ringBuffer, writePos, firstPart)
            if (evenCount > firstPart) {
                System.arraycopy(samples, offset + firstPart, ringBuffer, 0, evenCount - firstPart)
            }
            writePos = (writePos + evenCount) and RING_BUFFER_MASK
            bufferedCount += evenCount

            bufferLock.notify()
        }
    }

    fun writeSampleBatch(buffer: ShortArray, count: Int, blocking: Boolean = false) {
        writeSamples(buffer, 0, count, blocking)
    }

    fun getBufferedCount(): Int = synchronized(bufferLock) { bufferedCount }

    @Synchronized
    fun setVolume(vol: Float) {
        this.volume = vol.coerceIn(0f, 1f)
        try {
            audioTrack?.setVolume(volume)
        } catch (_: Exception) {}
    }

    @Synchronized
    fun release() {
        pause()
        try {
            audioTrack?.stop()
            audioTrack?.release()
        } catch (_: Exception) {}
        audioTrack = null
    }
}
