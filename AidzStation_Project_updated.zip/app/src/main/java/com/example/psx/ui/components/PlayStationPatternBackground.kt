package com.example.psx.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

/**
 * Authentic PlayStation Blue gradient background filled with a repeating geometric
 * pattern of iconic PlayStation symbols: Cross (X), Triangle, Square, and Circle.
 */
@Composable
fun PlayStationPatternBackground(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF001940), // Deep PlayStation Blue Top
                        Color(0xFF00296B), // Classic PlayStation Royal Blue Middle
                        Color(0xFF001333)  // Midnight PlayStation Blue Bottom
                    )
                )
            )
    ) {
        // Tiled Repeating PlayStation Geometry Pattern (X, Triangle, Square, Circle)
        Canvas(modifier = Modifier.fillMaxSize()) {
            val step = 56.dp.toPx()
            val symbolRadius = 7.dp.toPx()
            val strokeWidth = 1.6.dp.toPx()
            val patternStroke = Stroke(
                width = strokeWidth,
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
            val patternColor = Color(0xFF90B8FF).copy(alpha = 0.085f)

            var row = 0
            var y = step * 0.5f
            while (y < size.height + step) {
                var col = 0
                val rowOffset = if (row % 2 == 1) step * 0.5f else 0f
                var x = step * 0.5f - rowOffset

                while (x < size.width + step) {
                    val symbolIndex = (row * 3 + col) % 4
                    when (symbolIndex) {
                        0 -> {
                            // CROSS (X)
                            val span = symbolRadius * 0.85f
                            drawLine(
                                color = patternColor,
                                start = Offset(x - span, y - span),
                                end = Offset(x + span, y + span),
                                strokeWidth = strokeWidth,
                                cap = StrokeCap.Round
                            )
                            drawLine(
                                color = patternColor,
                                start = Offset(x - span, y + span),
                                end = Offset(x + span, y - span),
                                strokeWidth = strokeWidth,
                                cap = StrokeCap.Round
                            )
                        }
                        1 -> {
                            // TRIANGLE
                            val path = Path().apply {
                                moveTo(x, y - symbolRadius)
                                lineTo(x + symbolRadius * 0.95f, y + symbolRadius * 0.8f)
                                lineTo(x - symbolRadius * 0.95f, y + symbolRadius * 0.8f)
                                close()
                            }
                            drawPath(path, color = patternColor, style = patternStroke)
                        }
                        2 -> {
                            // CIRCLE
                            drawCircle(
                                color = patternColor,
                                radius = symbolRadius * 0.88f,
                                center = Offset(x, y),
                                style = patternStroke
                            )
                        }
                        3 -> {
                            // SQUARE
                            val halfW = symbolRadius * 0.82f
                            drawRoundRect(
                                color = patternColor,
                                topLeft = Offset(x - halfW, y - halfW),
                                size = Size(halfW * 2f, halfW * 2f),
                                cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx()),
                                style = patternStroke
                            )
                        }
                    }
                    x += step
                    col++
                }
                y += step * 0.86f
                row++
            }
        }

        content()
    }
}
