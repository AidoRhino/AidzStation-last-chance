package com.example.psx.data

import java.io.File

enum class GameDiscFormat(val extension: String, val label: String) {
    CUE("cue", "CUE/BIN Sheet"),
    BIN("bin", "Raw Binary"),
    CHD("chd", "Compressed Hunks of Data (CHD)"),
    ISO("iso", "Standard ISO-9660"),
    PBP("pbp", "PlayStation Portable PBP"),
    M3U("m3u", "Multi-Disc Playlist"),
    EXE("exe", "PS-X Executable"),
    DEMO("demo", "Built-in Tech Demo")
}

data class GameItem(
    val id: String,
    val title: String,
    val file: File?,
    val format: GameDiscFormat,
    val discNumber: Int = 1,
    val totalDiscs: Int = 1,
    val fileSizeFormatted: String = "",
    val lastPlayedTime: Long = 0L,
    val isFavorite: Boolean = false,
    val coverResId: Int? = null,
    val coverPath: String? = null,
    val isBuiltIn: Boolean = false
)
