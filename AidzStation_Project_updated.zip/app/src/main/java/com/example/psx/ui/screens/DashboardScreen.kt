package com.example.psx.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.psx.core.PsxEmulatorEngine
import com.example.psx.data.BiosManager
import com.example.psx.data.GameItem
import com.example.psx.data.GameRepository
import com.example.psx.ui.components.AidzStationLogo
import com.example.psx.ui.components.Ps1ConsoleHardware
import com.example.psx.ui.theme.*
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun DashboardScreen(
    engine: PsxEmulatorEngine,
    repository: GameRepository,
    biosManager: BiosManager,
    onLaunchGame: (GameItem) -> Unit,
    onNavigateToLibrary: () -> Unit,
    onNavigateToBios: () -> Unit,
    onNavigateToMemoryCard: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToWizard: () -> Unit,
    onNavigateToEditControls: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var refreshStatusMessage by remember { mutableStateOf<String?>(null) }

    val games by repository.games.collectAsState()
    val hasBios = remember { biosManager.hasAnyOfficialBios() }
    val featuredGame = games.firstOrNull()
    val sourceFolderName by repository.sourceFolderName.collectAsState()
    val config = engine.config

    val lastPlayedGame = remember(games, config.lastPlayedGamePath) {
        games.find { it.file?.absolutePath == config.lastPlayedGamePath } ?: featuredGame
    }
    val recentGames = remember(games, config.recentGamePaths) {
        val matched = config.recentGamePaths.mapNotNull { path ->
            games.find { it.file?.absolutePath == path }
        }
        if (matched.isNotEmpty()) matched else games.take(5)
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .testTag("dashboard_screen")
    ) {
        val isLandscape = maxWidth > maxHeight

        Column(modifier = Modifier.fillMaxSize()) {
            // TOP APP BAR WITH AIDZSTATION LOGO
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(PsxSurfaceDark)
                    .padding(horizontal = 20.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    AidzStationLogo(size = 28.dp)

                    Text(
                        text = "AIDZSTATION",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 2.sp,
                        color = PsxTextPrimary
                    )
                    Text(
                        text = "PSX",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = PsxTriangleGreen
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconButton(
                        onClick = onNavigateToLibrary,
                        modifier = Modifier
                            .size(36.dp)
                            .background(PsxCardElevated, CircleShape)
                            .testTag("dashboard_library_icon_button")
                    ) {
                        Icon(Icons.Default.Folder, contentDescription = "Library", tint = PsxTextPrimary, modifier = Modifier.size(18.dp))
                    }

                    IconButton(
                        onClick = onNavigateToSettings,
                        modifier = Modifier
                            .size(36.dp)
                            .background(PsxCardElevated, CircleShape)
                            .testTag("dashboard_settings_button")
                    ) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings", tint = PsxTextPrimary, modifier = Modifier.size(18.dp))
                    }
                }
            }

            if (refreshStatusMessage != null) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = PsxTriangleGreen.copy(alpha = 0.2f)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, PsxTriangleGreen),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, tint = PsxTriangleGreen, modifier = Modifier.size(16.dp))
                            Text(
                                text = refreshStatusMessage!!,
                                color = PsxTriangleGreen,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        IconButton(onClick = { refreshStatusMessage = null }, modifier = Modifier.size(20.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = PsxTriangleGreen, modifier = Modifier.size(14.dp))
                        }
                    }
                }
            }

            if (isLandscape) {
                // LANDSCAPE TWO-PANE LAYOUT: Preserves authentic console aspect ratio and stops stretching!
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // LEFT PANE: PlayStation Hardware Deck + Active Disc
                    Column(
                        modifier = Modifier
                            .weight(1.1f)
                            .fillMaxHeight()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Hardware deck with proportional constraints so it maintains square PlayStation shape
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .widthIn(max = 420.dp)
                        ) {
                            Ps1ConsoleHardware(
                                onPowerClick = {
                                    (context as? android.app.Activity)?.finishAffinity()
                                },
                                onDiscOpenClick = onNavigateToLibrary,
                                onResetClick = {
                                    coroutineScope.launch {
                                        val count = repository.refreshGameLibrary()
                                        refreshStatusMessage = "Game Library Refreshed ($count games ready)"
                                    }
                                },
                                isPoweredOn = true,
                                activeGameTitle = featuredGame?.title
                            )
                        }
                    }

                    // RIGHT PANE: System Navigation & Box Art Library
                    Column(
                        modifier = Modifier
                            .weight(1.2f)
                            .fillMaxHeight()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Ps1ShortcutTilesSection(
                            lastPlayedGame = lastPlayedGame,
                            recentGames = recentGames,
                            onLaunchGame = onLaunchGame,
                            onNavigateToSettings = onNavigateToSettings,
                            onNavigateToEditControls = onNavigateToEditControls
                        )

                        RecentBoxArtSection(
                            games = games,
                            onLaunchGame = onLaunchGame,
                            onNavigateToLibrary = onNavigateToLibrary
                        )
                    }
                }
            } else {
                // PORTRAIT LAYOUT: Clean vertical flow with max width constraint
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(bottom = 24.dp)
                        .widthIn(max = 600.dp)
                        .align(Alignment.CenterHorizontally),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Spacer(Modifier.height(4.dp))

                    // AUTHENTIC PS1 CONSOLE HARDWARE DECK
                    Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                        Ps1ConsoleHardware(
                            onPowerClick = {
                                (context as? android.app.Activity)?.finishAffinity()
                            },
                            onDiscOpenClick = onNavigateToLibrary,
                            onResetClick = {
                                coroutineScope.launch {
                                    val count = repository.refreshGameLibrary()
                                    refreshStatusMessage = "Game Library Refreshed ($count games ready)"
                                }
                            },
                            isPoweredOn = true,
                            activeGameTitle = lastPlayedGame?.title ?: featuredGame?.title
                        )
                    }

                    // PLAYSTATION SHORTCUT TILES (CONTINUE LAST GAME, GRAPHICS, EDIT CONTROLS, RECENT)
                    Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                        Ps1ShortcutTilesSection(
                            lastPlayedGame = lastPlayedGame,
                            recentGames = recentGames,
                            onLaunchGame = onLaunchGame,
                            onNavigateToSettings = onNavigateToSettings,
                            onNavigateToEditControls = onNavigateToEditControls
                        )
                    }

                    // BOX ART LIBRARY
                    Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                        RecentBoxArtSection(
                            games = games,
                            onLaunchGame = onLaunchGame,
                            onNavigateToLibrary = onNavigateToLibrary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ActiveDiscCard(
    game: GameItem,
    resolutionScale: Int,
    onPlay: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onPlay() }
            .testTag("featured_game_card"),
        colors = CardDefaults.cardColors(containerColor = PsxCardElevated),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, PsxCrossBlue.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(PsxDarkCharcoal)
                        .border(1.5.dp, PsxCrossBlue, RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (game.coverPath != null && File(game.coverPath).exists()) {
                        AsyncImage(
                            model = File(game.coverPath),
                            contentDescription = "Box Art for ${game.title}",
                            modifier = Modifier.fillMaxSize().padding(1.dp),
                            contentScale = ContentScale.Fit
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.SportsEsports,
                            contentDescription = null,
                            tint = PsxCrossBlue,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Column {
                    Text(
                        text = "ACTIVE DISC IN TRAY",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = PsxTextSecondary,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = game.title,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = PsxTextPrimary,
                        maxLines = 1
                    )
                    Spacer(Modifier.height(2.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "PlayStation Disc",
                            fontSize = 10.sp,
                            color = PsxTriangleGreen,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "• ${resolutionScale}x Res",
                            fontSize = 10.sp,
                            color = PsxYellowAccent
                        )
                    }
                }
            }

            Button(
                onClick = onPlay,
                colors = ButtonDefaults.buttonColors(containerColor = PsxTriangleGreen),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                modifier = Modifier.testTag("featured_play_button")
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(2.dp))
                Text("PLAY", color = Color.Black, fontWeight = FontWeight.Black, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun Ps1ShortcutTilesSection(
    lastPlayedGame: GameItem?,
    recentGames: List<GameItem>,
    onLaunchGame: (GameItem) -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToEditControls: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = "PLAYSTATION SHORTCUTS",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = PsxTextSecondary,
            letterSpacing = 1.sp
        )

        // 1. CONTINUE LAST GAME SHORTCUT TILE
        if (lastPlayedGame != null) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onLaunchGame(lastPlayedGame) }
                    .testTag("shortcut_continue_game"),
                colors = CardDefaults.cardColors(containerColor = PsxCardElevated),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, PsxTriangleGreen.copy(alpha = 0.7f))
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(PsxDarkCharcoal)
                                .border(1.dp, PsxTriangleGreen, RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (lastPlayedGame.coverPath != null && java.io.File(lastPlayedGame.coverPath).exists()) {
                                AsyncImage(
                                    model = java.io.File(lastPlayedGame.coverPath),
                                    contentDescription = null,
                                    modifier = Modifier.fillMaxSize().padding(1.dp),
                                    contentScale = ContentScale.Fit
                                )
                            } else {
                                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = PsxTriangleGreen, modifier = Modifier.size(26.dp))
                            }
                        }

                        Column {
                            Box(
                                modifier = Modifier
                                    .background(PsxTriangleGreen, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("CONTINUE LAST GAME", fontSize = 8.sp, fontWeight = FontWeight.Black, color = Color.Black)
                            }
                            Spacer(Modifier.height(3.dp))
                            Text(
                                text = lastPlayedGame.title,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = PsxTextPrimary,
                                maxLines = 1
                            )
                        }
                    }

                    Icon(Icons.Default.PlayCircle, contentDescription = "Play", tint = PsxTriangleGreen, modifier = Modifier.size(30.dp))
                }
            }
        }

        // 2. GRAPHICS SETTINGS & EDIT CONTROLS SHORTCUT TILES ROW
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // GRAPHICS SETTINGS
            Card(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onNavigateToSettings() }
                    .testTag("shortcut_graphics_settings"),
                colors = CardDefaults.cardColors(containerColor = PsxCardElevated),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, PsxSquarePink.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier.size(36.dp).background(PsxSquarePink.copy(alpha = 0.2f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Tune, contentDescription = null, tint = PsxSquarePink, modifier = Modifier.size(18.dp))
                    }
                    Column {
                        Text("Graphics", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PsxTextPrimary)
                        Text("DuckStation options", fontSize = 9.sp, color = PsxTextSecondary)
                    }
                }
            }

            // EDIT CONTROLS LAYOUT
            Card(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onNavigateToEditControls() }
                    .testTag("shortcut_edit_controls"),
                colors = CardDefaults.cardColors(containerColor = PsxCardElevated),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, PsxCrossBlue.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier.size(36.dp).background(PsxCrossBlue.copy(alpha = 0.2f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.TouchApp, contentDescription = null, tint = PsxCrossBlue, modifier = Modifier.size(18.dp))
                    }
                    Column {
                        Text("Edit Controls", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PsxTextPrimary)
                        Text("Custom gamepad", fontSize = 9.sp, color = PsxTextSecondary)
                    }
                }
            }
        }

        // 3. RECENT GAMES ROW (ONE TAP TO START)
        if (recentGames.isNotEmpty()) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "RECENT GAMES",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = PsxTextSecondary,
                    letterSpacing = 0.8.sp
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(recentGames) { game ->
                        Card(
                            modifier = Modifier
                                .width(110.dp)
                                .clickable { onLaunchGame(game) }
                                .testTag("shortcut_recent_game_${game.id}"),
                            colors = CardDefaults.cardColors(containerColor = PsxCardElevated),
                            shape = RoundedCornerShape(10.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, PsxCardBorder)
                        ) {
                            Column(modifier = Modifier.padding(6.dp)) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(95.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(PsxDarkCharcoal),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (game.coverPath != null && java.io.File(game.coverPath).exists()) {
                                        AsyncImage(
                                            model = java.io.File(game.coverPath),
                                            contentDescription = null,
                                            modifier = Modifier.fillMaxSize().padding(1.dp),
                                            contentScale = ContentScale.Fit
                                        )
                                    } else {
                                        Icon(Icons.Default.SportsEsports, contentDescription = null, tint = PsxCrossBlue, modifier = Modifier.size(24.dp))
                                    }
                                }
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = game.title,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = PsxTextPrimary,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RecentBoxArtSection(
    games: List<GameItem>,
    onLaunchGame: (GameItem) -> Unit,
    onNavigateToLibrary: () -> Unit
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "ORIGINAL PS1 BOX ART",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = PsxTextSecondary,
                letterSpacing = 1.sp
            )
            Text(
                text = "VIEW ALL",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = PsxCrossBlue,
                modifier = Modifier.clickable { onNavigateToLibrary() }
            )
        }

        Spacer(Modifier.height(8.dp))

        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(games) { game ->
                GameMiniTile(game = game, onClick = { onLaunchGame(game) })
            }
        }
    }
}

@Composable
private fun NavModuleCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    tag: String
) {
    Card(
        modifier = modifier
            .clickable { onClick() }
            .testTag(tag),
        colors = CardDefaults.cardColors(containerColor = PsxCardSurface),
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, PsxDarkCharcoal)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .background(iconColor.copy(alpha = 0.15f), RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(18.dp))
            }
            Column {
                Text(text = title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PsxTextPrimary)
                Text(text = subtitle, fontSize = 10.sp, color = PsxTextSecondary)
            }
        }
    }
}

@Composable
private fun GameMiniTile(game: GameItem, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .width(82.dp)
            .clickable { onClick() },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(width = 82.dp, height = 82.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(PsxCardElevated)
                .border(1.dp, PsxDarkCharcoal, RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
        ) {
            if (game.coverPath != null && File(game.coverPath).exists()) {
                AsyncImage(
                    model = File(game.coverPath),
                    contentDescription = game.title,
                    modifier = Modifier.fillMaxSize().padding(1.dp),
                    contentScale = ContentScale.Fit
                )
            } else {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        Icons.Default.DiscFull,
                        contentDescription = null,
                        tint = PsxConsoleGrey,
                        modifier = Modifier.size(28.dp)
                    )
                    Text(
                        text = "PS1",
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        color = PsxTriangleGreen
                    )
                }
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            text = game.title,
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium,
            color = PsxTextPrimary,
            maxLines = 1,
            lineHeight = 12.sp
        )
    }
}
