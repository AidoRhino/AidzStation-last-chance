package com.example.psx.core

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.example.psx.audio.PsxAudioPlayer
import com.example.psx.input.ControllerState
import com.sun.jna.Memory
import com.sun.jna.Native
import com.sun.jna.NativeLong
import com.sun.jna.Pointer
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

class LibretroBridge(
    private val context: Context,
    private val systemDir: File,
    private val saveDir: File,
    private val audioPlayer: PsxAudioPlayer,
    private val controllerState: ControllerState,
    initialConfig: PsxConfiguration
) {
    companion object {
        private const val TAG = "LibretroBridge"
        private const val LIB_NAME = "pcsx_rearmed_libretro_android"
    }

    @Volatile var hasVariableUpdates = false

    var config: PsxConfiguration = initialConfig
        set(value) {
            field = value
            hasVariableUpdates = true
        }

    private var activeSaveRamFile: File? = null
    private var saveRamSyncCounter = 0

    private var coreApi: LibretroCoreApi? = null
    var isInitialized = false
        private set
    var isGameLoaded = false
        private set
    var lastErrorMessage: String? = null
        private set

    // Persistent Memory objects to prevent garbage collection of C strings
    private val systemPathMemory = Memory((systemDir.absolutePath.length + 1).toLong()).apply {
        setString(0, systemDir.absolutePath)
    }
    private val savePathMemory = Memory((saveDir.absolutePath.length + 1).toLong()).apply {
        setString(0, saveDir.absolutePath)
    }
    private val varMemoryMap = mutableMapOf<String, Memory>()

    // Video output state
    @Volatile var currentBitmap: Bitmap? = null
        private set
    private var pixelBuffer: ByteBuffer? = null
    private var currentPixelFormat: Int = LibretroDefs.RETRO_PIXEL_FORMAT_RGB565
    private var currentWidth = 320
    private var currentHeight = 240
    var targetFps: Double = 59.94

    // Pre-allocated static buffers to completely eliminate per-frame GC allocations
    private var reusablePixelArray = ByteArray(1024 * 512 * 4)
    private var reusableRowArray = ByteArray(4096)
    private var reusableAudioBuffer = ShortArray(16384)
    private val singleSampleBuf = ShortArray(2)

    // Frame callback for display
    var onFrameRendered: ((Bitmap) -> Unit)? = null

    // Callbacks to hold references so GC doesn't collect them
    private val envCallback = RetroEnvironmentCallback { cmd, data -> handleEnvironment(cmd, data) }
    private val videoCallback = RetroVideoRefreshCallback { ptr, width, height, pitch ->
        handleVideoRefresh(ptr, width, height, pitch.toLong())
    }
    private val audioSampleCallback = RetroAudioSampleCallback { left, right ->
        singleSampleBuf[0] = left
        singleSampleBuf[1] = right
        audioPlayer.writeSamples(singleSampleBuf, 0, 2, false)
    }
    private val audioBatchCallback = RetroAudioSampleBatchCallback { ptr, frames ->
        val frameCount = frames.toLong()
        if (ptr != null && frameCount > 0) {
            val totalShorts = (frameCount * 2).toInt()
            if (reusableAudioBuffer.size < totalShorts) {
                reusableAudioBuffer = ShortArray(totalShorts * 2)
            }
            ptr.read(0, reusableAudioBuffer, 0, totalShorts)
            audioPlayer.writeSamples(reusableAudioBuffer, 0, totalShorts, false)
            NativeLong(frameCount)
        } else {
            NativeLong(0)
        }
    }
    private val inputPollCallback = RetroInputPollCallback {
        // Input state is polled dynamically from controllerState
    }
    private val inputStateCallback = RetroInputStateCallback { port, device, index, id ->
        if (port == 0) {
            val baseDevice = device and 0xff
            when (baseDevice) {
                LibretroDefs.RETRO_DEVICE_JOYPAD -> controllerState.getButtonState(id)
                LibretroDefs.RETRO_DEVICE_ANALOG -> {
                    if (index == 2 || id > 1) {
                        // Digital button on analog controller
                        controllerState.getButtonState(id)
                    } else {
                        // Analog axes
                        controllerState.getAnalogState(index, id)
                    }
                }
                else -> {
                    if (id in 0..15) controllerState.getButtonState(id) else 0
                }
            }
        } else {
            0
        }
    }

    fun loadCore(): Boolean {
        return try {
            Log.d(TAG, "Loading native libretro core: $LIB_NAME")

            val nativeLibFile = File(context.applicationInfo.nativeLibraryDir, "lib$LIB_NAME.so")
            Log.i(TAG, "Native library path: ${nativeLibFile.absolutePath}, exists=${nativeLibFile.exists()}")

            // 1. Load library into runtime address space
            if (nativeLibFile.exists()) {
                try {
                    System.load(nativeLibFile.absolutePath)
                    Log.i(TAG, "System.load(${nativeLibFile.absolutePath}) succeeded")
                } catch (t: Throwable) {
                    Log.w(TAG, "System.load failed: ${t.message}")
                }
            } else {
                try {
                    System.loadLibrary(LIB_NAME)
                    Log.i(TAG, "System.loadLibrary($LIB_NAME) succeeded")
                } catch (t: Throwable) {
                    Log.w(TAG, "System.loadLibrary failed: ${t.message}")
                }
            }

            // 2. Bind through JNA: Prefer direct absolute path if file exists
            val api = if (nativeLibFile.exists()) {
                Native.load(nativeLibFile.absolutePath, LibretroCoreApi::class.java)
            } else {
                Native.load(LIB_NAME, LibretroCoreApi::class.java)
            }
            coreApi = api
            val version = api.retro_api_version()
            Log.i(TAG, "Libretro core loaded successfully! API Version: $version")

            api.retro_set_environment(envCallback)
            api.retro_set_video_refresh(videoCallback)
            api.retro_set_audio_sample(audioSampleCallback)
            api.retro_set_audio_sample_batch(audioBatchCallback)
            api.retro_set_input_poll(inputPollCallback)
            api.retro_set_input_state(inputStateCallback)

            api.retro_init()
            isInitialized = true
            lastErrorMessage = null
            true
        } catch (t: Throwable) {
            val msg = "Failed to load PCSX-ReARMed native core: ${t.message}"
            Log.e(TAG, msg, t)
            lastErrorMessage = msg
            false
        }
    }

    private fun handleEnvironment(cmd: Int, data: Pointer?): Boolean {
        when (cmd) {
            LibretroDefs.RETRO_ENVIRONMENT_SET_PIXEL_FORMAT -> {
                if (data != null) {
                    val format = data.getInt(0)
                    Log.d(TAG, "RETRO_ENVIRONMENT_SET_PIXEL_FORMAT: $format")
                    currentPixelFormat = format
                    return format == LibretroDefs.RETRO_PIXEL_FORMAT_RGB565 || format == LibretroDefs.RETRO_PIXEL_FORMAT_XRGB8888
                }
            }
            LibretroDefs.RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY -> {
                if (data != null) {
                    systemDir.mkdirs()
                    data.setPointer(0, systemPathMemory)
                    return true
                }
            }
            LibretroDefs.RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY -> {
                if (data != null) {
                    saveDir.mkdirs()
                    data.setPointer(0, savePathMemory)
                    return true
                }
            }
            LibretroDefs.RETRO_ENVIRONMENT_GET_CAN_DUPE -> {
                data?.setInt(0, 1)
                return true
            }
            LibretroDefs.RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE -> {
                val updated = hasVariableUpdates
                data?.setInt(0, if (updated) 1 else 0)
                hasVariableUpdates = false
                return true
            }
            LibretroDefs.RETRO_ENVIRONMENT_GET_VARIABLE -> {
                if (data != null) {
                    val key = data.getPointer(0)?.getString(0)
                    val value = when (key) {
                        "pcsx_rearmed_frameskip" -> "0"
                        "pcsx_rearmed_region" -> "Auto"
                        "pcsx_rearmed_pad1type" -> "standard"
                        "pcsx_rearmed_memcard1" -> "libretro" // Active Libretro Save RAM integration
                        "pcsx_rearmed_memcard2" -> "libretro"
                        "pcsx_rearmed_dithering" -> if (config.isDitheringEnabled) "enabled" else "disabled"
                        "pcsx_rearmed_bios" -> "auto"
                        "pcsx_rearmed_neon_enhancement_enable" -> if (config.internalResolutionScale >= 2) "enabled" else "disabled"
                        "pcsx_rearmed_neon_interlace_enable_v2" -> "disabled"
                        "pcsx_rearmed_neon_enhancement_no_main" -> if (config.internalResolutionScale >= 4) "enabled" else "disabled"
                        "pcsx_rearmed_nocdaudio" -> "disabled" // keep CD-DA music on
                        "pcsx_rearmed_noxadecoding" -> "disabled" // keep XA audio on
                        "pcsx_rearmed_spu_interpolation" -> "gaussian"
                        "pcsx_rearmed_spu_reverb" -> "enabled"
                        "pcsx_rearmed_spu_thread" -> "disabled"
                        "pcsx_rearmed_cd_readahead" -> "64"
                        "pcsx_rearmed_psxclock" -> "55"
                        "pcsx_rearmed_icache_emulation" -> "disabled"
                        "pcsx_rearmed_drc" -> "enabled"
                        "pcsx_rearmed_multitap1" -> "disabled"
                        "pcsx_rearmed_multitap2" -> "disabled"
                        "pcsx_rearmed_show_bios_bootlogo" -> "disabled"
                        else -> null
                    }
                    if (value != null) {
                        val valMem = varMemoryMap.getOrPut(value) {
                            Memory((value.length + 1).toLong()).apply { setString(0, value) }
                        }
                        data.setPointer(Native.POINTER_SIZE.toLong(), valMem)
                        return true
                    }
                }
            }
        }
        return false
    }

    private fun handleVideoRefresh(ptr: Pointer?, width: Int, height: Int, pitch: Long) {
        if (ptr == null) {
            // Frame dupe: Libretro core requests to re-present the previous frame
            currentBitmap?.let { onFrameRendered?.invoke(it) }
            return
        }
        if (width <= 0 || height <= 0) return

        if (currentBitmap == null || currentWidth != width || currentHeight != height) {
            currentWidth = width
            currentHeight = height
            val config = if (currentPixelFormat == LibretroDefs.RETRO_PIXEL_FORMAT_RGB565) {
                Bitmap.Config.RGB_565
            } else {
                Bitmap.Config.ARGB_8888
            }
            currentBitmap = Bitmap.createBitmap(width, height, config)
            val bytesPerPixel = if (currentPixelFormat == LibretroDefs.RETRO_PIXEL_FORMAT_RGB565) 2 else 4
            pixelBuffer = ByteBuffer.allocateDirect(width * height * bytesPerPixel).order(ByteOrder.nativeOrder())
        }

        val bmp = currentBitmap ?: return
        val buffer = pixelBuffer ?: return
        buffer.rewind()

        val bytesPerPixel = if (currentPixelFormat == LibretroDefs.RETRO_PIXEL_FORMAT_RGB565) 2 else 4
        val rowBytes = width * bytesPerPixel
        val totalBytes = rowBytes * height

        if (pitch.toInt() == rowBytes) {
            if (reusablePixelArray.size < totalBytes) {
                reusablePixelArray = ByteArray(totalBytes)
            }
            ptr.read(0, reusablePixelArray, 0, totalBytes)
            buffer.put(reusablePixelArray, 0, totalBytes)
        } else {
            // Strided pitch: reuse pre-allocated row buffer
            if (reusableRowArray.size < rowBytes) {
                reusableRowArray = ByteArray(rowBytes)
            }
            for (y in 0 until height) {
                ptr.read(y * pitch, reusableRowArray, 0, rowBytes)
                buffer.put(reusableRowArray, 0, rowBytes)
            }
        }

        buffer.rewind()
        bmp.copyPixelsFromBuffer(buffer)
        onFrameRendered?.invoke(bmp)
    }

    /**
     * Prepares and loads a PS1 game disc.
     * Automatically handles CUE/BIN association and generates CUE descriptors for raw BIN/ISO files.
     */
    fun loadGame(gameFile: File): Boolean {
        val api = coreApi
        if (api == null) {
            lastErrorMessage = "PCSX core API is not loaded"
            return false
        }

        if (!gameFile.exists()) {
            lastErrorMessage = "File does not exist: ${gameFile.name}"
            return false
        }

        if (gameFile.length() <= 0) {
            lastErrorMessage = "File is empty (0 bytes): ${gameFile.name}. Please re-import the complete disc."
            return false
        }

        // Determine effective boot file
        var bootFile = gameFile
        val ext = gameFile.extension.lowercase()

        // If raw .bin or .iso without .cue, auto-generate matching .cue file
        if (ext == "bin" || ext == "iso") {
            val candidateCue = File(gameFile.parentFile, "${gameFile.nameWithoutExtension}.cue")
            if (!candidateCue.exists()) {
                try {
                    val cueContent = "FILE \"${gameFile.name}\" BINARY\n  TRACK 01 MODE2/2352\n    INDEX 01 00:00:00\n"
                    candidateCue.writeText(cueContent)
                    Log.i(TAG, "Generated CUE descriptor for ${gameFile.name} -> ${candidateCue.name}")
                    bootFile = candidateCue
                } catch (e: Exception) {
                    Log.w(TAG, "Could not auto-generate CUE: ${e.message}")
                }
            } else {
                bootFile = candidateCue
            }
        } else if (ext == "cue") {
            // Verify that referenced .bin file in CUE actually exists
            try {
                val cueLines = gameFile.readLines()
                val fileLine = cueLines.firstOrNull { it.trim().startsWith("FILE", ignoreCase = true) }
                if (fileLine != null) {
                    val match = Regex("FILE\\s+\"([^\"]+)\"", RegexOption.IGNORE_CASE).find(fileLine)
                    val referencedName = match?.groupValues?.getOrNull(1)
                    if (referencedName != null) {
                        val referencedFile = File(gameFile.parentFile, referencedName)
                        if (!referencedFile.exists()) {
                            // Try case-insensitive lookup
                            val sibling = gameFile.parentFile?.listFiles()?.firstOrNull {
                                it.name.equals(referencedName, ignoreCase = true) || it.name.endsWith(".bin", ignoreCase = true)
                            }
                            if (sibling != null) {
                                // Fix CUE content to point to actual existing sibling filename
                                val fixedContent = gameFile.readText().replace(referencedName, sibling.name)
                                gameFile.writeText(fixedContent)
                                Log.i(TAG, "Repaired CUE reference: $referencedName -> ${sibling.name}")
                            } else {
                                val err = "CUE references '$referencedName', but it was not found in ${gameFile.parentFile?.name}. Please import both the .cue and .bin together."
                                Log.e(TAG, err)
                                lastErrorMessage = err
                                return false
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error checking CUE references: ${e.message}")
            }
        }

        val gameInfo = RetroGameInfo().apply {
            path = bootFile.absolutePath
            data = null
            size = NativeLong(bootFile.length())
            meta = null
        }
        gameInfo.write()

        return try {
            Log.i(TAG, "Invoking retro_load_game with path: ${bootFile.absolutePath} (${bootFile.length()} bytes)")
            val result = api.retro_load_game(gameInfo)
            val success = result.toInt() != 0
            isGameLoaded = success
            if (success) {
                api.retro_set_controller_port_device(0, LibretroDefs.RETRO_DEVICE_JOYPAD)
                lastErrorMessage = null
                loadSaveRam(bootFile)

                // Query exact game AV info (FPS, native aspect ratio, sample rate)
                try {
                    val avInfo = RetroSystemAvInfo()
                    api.retro_get_system_av_info(avInfo)
                    if (avInfo.timing.fps in 40.0..75.0) {
                        targetFps = avInfo.timing.fps
                    }
                    Log.i(TAG, "retro_load_game SUCCESS for ${bootFile.name}: fps=$targetFps, aspect=${avInfo.geometry.aspect_ratio}")
                } catch (e: Exception) {
                    Log.i(TAG, "retro_load_game SUCCESS for ${bootFile.name} with memory card mounted")
                }
            } else {
                lastErrorMessage = "PCSX core rejected disc '${bootFile.name}'. Verify disc format and BIOS settings."
                Log.e(TAG, "retro_load_game returned 0 (FAILURE)")
            }
            success
        } catch (t: Throwable) {
            val err = "Error during retro_load_game: ${t.message}"
            Log.e(TAG, err, t)
            lastErrorMessage = err
            false
        }
    }

    val coreLock = Any()

    fun runFrame() {
        val api = coreApi ?: return
        if (isGameLoaded) {
            synchronized(coreLock) {
                api.retro_run()
            }
            saveRamSyncCounter++
            if (saveRamSyncCounter >= 300) {
                saveRamSyncCounter = 0
                flushSaveRam()
            }
        }
    }

    fun reset() {
        flushSaveRam()
        synchronized(coreLock) {
            coreApi?.retro_reset()
        }
    }

    fun unloadGame() {
        flushSaveRam()
        synchronized(coreLock) {
            if (isGameLoaded) {
                try {
                    coreApi?.retro_unload_game()
                } catch (t: Throwable) {
                    Log.e(TAG, "Error during unload: ${t.message}")
                }
                isGameLoaded = false
            }
        }
    }

    fun loadSaveRam(bootFile: File) {
        val api = coreApi ?: return
        try {
            val size = api.retro_get_memory_size(LibretroDefs.RETRO_MEMORY_SAVE_RAM).toInt()
            if (size <= 0) {
                Log.w(TAG, "retro_get_memory_size returned 0 for SAVE_RAM")
                return
            }
            val ptr = api.retro_get_memory_data(LibretroDefs.RETRO_MEMORY_SAVE_RAM) ?: return
            val srmFile = File(saveDir, "${bootFile.nameWithoutExtension}.srm")
            activeSaveRamFile = srmFile

            val globalMcr = File(File(context.filesDir, "memorycards"), "memcard1.mcr")
            val pcsxMcd = File(saveDir, "pcsx-card1.mcd")

            val existingBytes: ByteArray? = when {
                srmFile.exists() && srmFile.length() == size.toLong() -> srmFile.readBytes()
                pcsxMcd.exists() && pcsxMcd.length() == size.toLong() -> pcsxMcd.readBytes()
                globalMcr.exists() && globalMcr.length() == size.toLong() -> globalMcr.readBytes()
                else -> null
            }

            val cardData = if (existingBytes != null) {
                existingBytes
            } else {
                val formatted = com.example.psx.data.MemoryCardManager.createFormattedMemoryCard()
                srmFile.parentFile?.mkdirs()
                srmFile.writeBytes(formatted)
                pcsxMcd.parentFile?.mkdirs()
                pcsxMcd.writeBytes(formatted)
                if (!globalMcr.exists()) {
                    globalMcr.parentFile?.mkdirs()
                    globalMcr.writeBytes(formatted)
                }
                formatted
            }

            ptr.write(0, cardData, 0, minOf(size, cardData.size))
            Log.i(TAG, "PS1 Memory Card 1 mounted successfully: ${cardData.size} bytes (${srmFile.name})")
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to load save RAM: ${t.message}", t)
        }
    }

    fun flushSaveRam() {
        val api = coreApi ?: return
        if (!isGameLoaded) return
        try {
            val size = api.retro_get_memory_size(LibretroDefs.RETRO_MEMORY_SAVE_RAM).toInt()
            if (size <= 0) return
            val ptr = api.retro_get_memory_data(LibretroDefs.RETRO_MEMORY_SAVE_RAM) ?: return
            val bytes = ptr.getByteArray(0, size)

            activeSaveRamFile?.let { srm ->
                srm.parentFile?.mkdirs()
                srm.writeBytes(bytes)
            }
            val pcsxMcd = File(saveDir, "pcsx-card1.mcd")
            pcsxMcd.parentFile?.mkdirs()
            pcsxMcd.writeBytes(bytes)

            val globalMcr = File(File(context.filesDir, "memorycards"), "memcard1.mcr")
            globalMcr.parentFile?.mkdirs()
            globalMcr.writeBytes(bytes)
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to flush save RAM: ${t.message}")
        }
    }

    fun saveState(file: File): Boolean {
        val api = coreApi ?: return false
        if (!isGameLoaded) return false
        flushSaveRam()
        return synchronized(coreLock) {
            try {
                val size = api.retro_serialize_size().toLong()
                if (size <= 0) {
                    Log.w(TAG, "Core reports serialize size <= 0: $size")
                    return@synchronized false
                }
                val memory = Memory(size)
                val success = api.retro_serialize(memory, NativeLong(size))
                if (success) {
                    val data = memory.getByteArray(0, size.toInt())
                    file.parentFile?.mkdirs()
                    val tempFile = File(file.parentFile, "${file.name}.tmp")
                    tempFile.writeBytes(data)
                    if (file.exists()) file.delete()
                    tempFile.renameTo(file)
                    Log.i(TAG, "Save state written successfully ($size bytes) to ${file.name}")
                } else {
                    Log.w(TAG, "Core failed to serialize state")
                }
                success
            } catch (t: Throwable) {
                Log.e(TAG, "Failed to save state: ${t.message}", t)
                false
            }
        }
    }

    fun loadState(file: File): Boolean {
        val api = coreApi ?: return false
        if (!isGameLoaded || !file.exists() || file.length() <= 0) return false
        return synchronized(coreLock) {
            try {
                val expectedSize = api.retro_serialize_size().toLong()
                if (expectedSize <= 0) {
                    Log.w(TAG, "Core reports serialize size <= 0: $expectedSize")
                    return@synchronized false
                }
                val bytes = file.readBytes()
                if (bytes.size.toLong() != expectedSize) {
                    Log.w(TAG, "Save state size mismatch: file is ${bytes.size} bytes, core expected $expectedSize bytes")
                    return@synchronized false
                }
                val memory = Memory(bytes.size.toLong())
                memory.write(0, bytes, 0, bytes.size)
                val success = api.retro_unserialize(memory, NativeLong(bytes.size.toLong()))
                Log.i(TAG, "State load result: $success from ${file.name}")
                success
            } catch (t: Throwable) {
                Log.e(TAG, "Failed to load state: ${t.message}", t)
                false
            }
        }
    }

    fun shutdown() {
        unloadGame()
        if (isInitialized) {
            try {
                coreApi?.retro_deinit()
            } catch (t: Throwable) {
                Log.e(TAG, "Error in deinit: ${t.message}")
            }
            isInitialized = false
        }
        currentBitmap = null
        pixelBuffer = null
    }
}
