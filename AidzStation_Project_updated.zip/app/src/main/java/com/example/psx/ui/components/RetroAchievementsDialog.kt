package com.example.psx.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.psx.data.RetroAchievement
import com.example.psx.data.RetroAchievementsManager
import com.example.psx.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun RetroAchievementsDialog(
    manager: RetroAchievementsManager,
    onDismiss: () -> Unit
) {
    val user by manager.currentUser.collectAsState()
    val achievements by manager.currentGameAchievements.collectAsState()
    val isLoading by manager.isLoading.collectAsState()
    val statusMsg by manager.statusMessage.collectAsState()

    val scope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current

    var usernameInput by remember { mutableStateOf("") }
    var passwordInput by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
                .clip(RoundedCornerShape(16.dp))
                .border(2.dp, PsxConsoleGrey, RoundedCornerShape(16.dp)),
            color = PsxSurfaceDark,
            tonalElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(PsxYellowAccent.copy(alpha = 0.2f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.EmojiEvents,
                                contentDescription = null,
                                tint = PsxYellowAccent,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "RETROACHIEVEMENTS",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                color = PsxTextPrimary,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = if (user != null) "Signed in as ${user?.username}" else "Earn PS1 Trophies",
                                fontSize = 12.sp,
                                color = PsxTriangleGreen
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(34.dp)
                            .background(PsxCardElevated, CircleShape)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = PsxTextPrimary)
                    }
                }

                if (!statusMsg.isNullOrBlank()) {
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = statusMsg ?: "",
                        fontSize = 12.sp,
                        color = PsxYellowAccent,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(PsxCardSurface, RoundedCornerShape(6.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }

                Spacer(Modifier.height(14.dp))

                if (user == null) {
                    // SIGN IN FORM
                    Text(
                        "SIGN IN TO RETROACHIEVEMENTS",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = PsxTextSecondary
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Sign in to track real PS1 achievements, earn trophies, and compete on community leaderboards.",
                        fontSize = 12.sp,
                        color = PsxTextSecondary
                    )

                    Spacer(Modifier.height(14.dp))

                    OutlinedTextField(
                        value = usernameInput,
                        onValueChange = { usernameInput = it },
                        label = { Text("Username") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PsxCrossBlue,
                            unfocusedBorderColor = PsxDarkCharcoal,
                            focusedTextColor = PsxTextPrimary,
                            unfocusedTextColor = PsxTextPrimary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("retro_username_input"),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
                    )

                    Spacer(Modifier.height(10.dp))

                    OutlinedTextField(
                        value = passwordInput,
                        onValueChange = { passwordInput = it },
                        label = { Text("Password or Web API Key") },
                        singleLine = true,
                        visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                                Icon(
                                    if (isPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = null,
                                    tint = PsxTextSecondary
                                )
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PsxCrossBlue,
                            unfocusedBorderColor = PsxDarkCharcoal,
                            focusedTextColor = PsxTextPrimary,
                            unfocusedTextColor = PsxTextPrimary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("retro_password_input"),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = {
                            focusManager.clearFocus()
                            if (usernameInput.isNotBlank() && passwordInput.isNotBlank()) {
                                scope.launch {
                                    manager.login(usernameInput, passwordInput)
                                }
                            }
                        })
                    )

                    Spacer(Modifier.height(16.dp))

                    Button(
                        onClick = {
                            focusManager.clearFocus()
                            scope.launch {
                                manager.login(usernameInput, passwordInput)
                            }
                        },
                        enabled = usernameInput.isNotBlank() && passwordInput.isNotBlank() && !isLoading,
                        colors = ButtonDefaults.buttonColors(containerColor = PsxCrossBlue),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("retro_signin_button")
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Default.Login, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Sign In", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }

                    Spacer(Modifier.height(8.dp))

                    OutlinedButton(
                        onClick = {
                            focusManager.clearFocus()
                            manager.loginAsGuest(usernameInput.ifBlank { "PlayStationPlayer" })
                        },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = PsxTriangleGreen),
                        border = androidx.compose.foundation.BorderStroke(1.dp, PsxTriangleGreen.copy(alpha = 0.6f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("retro_guest_button")
                    ) {
                        Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(18.dp), tint = PsxTriangleGreen)
                        Spacer(Modifier.width(8.dp))
                        Text("Play as Guest (Offline Trophies)", color = PsxTriangleGreen, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                } else {
                    // SIGNED IN USER PROFILE & ACHIEVEMENTS LIST
                    val activeUser = user!!
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(PsxCardElevated, RoundedCornerShape(10.dp))
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            if (activeUser.avatarUrl.isNotBlank()) {
                                AsyncImage(
                                    model = activeUser.avatarUrl,
                                    contentDescription = activeUser.username,
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .border(2.dp, PsxCrossBlue, CircleShape),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .background(PsxCrossBlue, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        activeUser.username.take(1).uppercase(),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp,
                                        color = Color.White
                                    )
                                }
                            }

                            Column {
                                Text(
                                    text = activeUser.username,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = PsxTextPrimary
                                )
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${activeUser.score} pts",
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 12.sp,
                                        color = PsxYellowAccent
                                    )
                                    Text("•", color = PsxTextSecondary)
                                    Text(
                                        text = activeUser.rank,
                                        fontSize = 12.sp,
                                        color = PsxTriangleGreen
                                    )
                                }
                            }
                        }

                        IconButton(
                            onClick = { manager.logout() },
                            modifier = Modifier
                                .size(36.dp)
                                .background(PsxCardSurface, CircleShape)
                        ) {
                            Icon(Icons.Default.Logout, contentDescription = "Sign Out", tint = PsxCircleRed, modifier = Modifier.size(18.dp))
                        }
                    }

                    Spacer(Modifier.height(14.dp))

                    // ACHIEVEMENTS LIST
                    val unlockedCount = achievements.count { it.isUnlocked }
                    val totalCount = achievements.size

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "GAME ACHIEVEMENTS",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = PsxTextSecondary
                        )
                        Text(
                            text = "$unlockedCount / $totalCount Unlocked",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (unlockedCount > 0) PsxYellowAccent else PsxTextSecondary
                        )
                    }

                    Spacer(Modifier.height(8.dp))

                    if (achievements.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp)
                                .background(PsxCardSurface, RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "No achievements found for this game or offline",
                                fontSize = 12.sp,
                                color = PsxTextSecondary
                            )
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 280.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(achievements) { item ->
                                AchievementItemRow(
                                    achievement = item,
                                    onTestUnlock = { manager.unlockAchievement(item.id) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AchievementItemRow(
    achievement: RetroAchievement,
    onTestUnlock: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(if (achievement.isUnlocked) PsxCardElevated else PsxCardSurface)
            .border(
                1.dp,
                if (achievement.isUnlocked) PsxYellowAccent.copy(alpha = 0.5f) else Color.Transparent,
                RoundedCornerShape(8.dp)
            )
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Badge or Icon
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(if (achievement.isUnlocked) PsxYellowAccent.copy(alpha = 0.2f) else PsxDarkCharcoal),
            contentAlignment = Alignment.Center
        ) {
            if (achievement.badgeUrl.isNotBlank()) {
                AsyncImage(
                    model = achievement.badgeUrl,
                    contentDescription = achievement.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Icon(
                    if (achievement.isUnlocked) Icons.Default.EmojiEvents else Icons.Default.Lock,
                    contentDescription = null,
                    tint = if (achievement.isUnlocked) PsxYellowAccent else PsxTextSecondary,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        // Details
        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = achievement.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = if (achievement.isUnlocked) PsxTextPrimary else PsxTextSecondary
                )
                Text(
                    text = "${achievement.points} pts",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = if (achievement.isUnlocked) PsxYellowAccent else PsxTextSecondary
                )
            }
            Text(
                text = achievement.description,
                fontSize = 11.sp,
                color = PsxTextSecondary,
                maxLines = 2
            )
        }

        // Unlock status / test button
        if (achievement.isUnlocked) {
            Icon(
                Icons.Default.CheckCircle,
                contentDescription = "Unlocked",
                tint = PsxTriangleGreen,
                modifier = Modifier.size(20.dp)
            )
        } else {
            IconButton(
                onClick = onTestUnlock,
                modifier = Modifier.size(28.dp)
            ) {
                Icon(
                    Icons.Default.LockOpen,
                    contentDescription = "Unlock",
                    tint = PsxTextSecondary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
