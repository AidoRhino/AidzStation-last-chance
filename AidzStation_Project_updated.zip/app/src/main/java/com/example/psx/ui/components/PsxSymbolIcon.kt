package com.example.psx.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.psx.ui.theme.*

enum class PsxSymbolType {
    TRIANGLE,
    CIRCLE,
    CROSS,
    SQUARE
}

/**
 * Geometric, pixel-perfect PlayStation action button symbol renderer.
 * All four symbols share identical visual optical weight, centered coordinates,
 * and uniform stroke thickness.
 */
@Composable
fun PsxSymbolIcon(
    type: PsxSymbolType,
    modifier: Modifier = Modifier,
    size: Dp = 22.dp,
    strokeWidth: Dp = 2.8.dp,
    customColor: Color? = null
) {
    val color = customColor ?: when (type) {
        PsxSymbolType.TRIANGLE -> PsxTriangleGreen
        PsxSymbolType.CIRCLE -> PsxCircleRed
        PsxSymbolType.CROSS -> PsxCrossBlue
        PsxSymbolType.SQUARE -> PsxSquarePink
    }

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val s = minOf(this.size.width, this.size.height)
            val strokePx = strokeWidth.toPx()
            val style = Stroke(
                width = strokePx,
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )

            // Half-size radius/extent with 18% optical margin
            val pad = s * 0.16f
            val cx = this.size.width / 2f
            val cy = this.size.height / 2f
            val radius = (s / 2f) - pad

            when (type) {
                PsxSymbolType.TRIANGLE -> {
                    // Equilateral triangle centered optically
                    val topY = cy - radius
                    val botY = cy + radius * 0.85f
                    val halfW = radius * 1.05f

                    val path = Path().apply {
                        moveTo(cx, topY)
                        lineTo(cx + halfW, botY)
                        lineTo(cx - halfW, botY)
                        close()
                    }
                    drawPath(path = path, color = color, style = style)
                }

                PsxSymbolType.CIRCLE -> {
                    drawCircle(
                        color = color,
                        radius = radius * 0.92f,
                        center = Offset(cx, cy),
                        style = style
                    )
                }

                PsxSymbolType.CROSS -> {
                    val span = radius * 0.86f
                    drawLine(
                        color = color,
                        start = Offset(cx - span, cy - span),
                        end = Offset(cx + span, cy + span),
                        strokeWidth = strokePx,
                        cap = StrokeCap.Round
                    )
                    drawLine(
                        color = color,
                        start = Offset(cx - span, cy + span),
                        end = Offset(cx + span, cy - span),
                        strokeWidth = strokePx,
                        cap = StrokeCap.Round
                    )
                }

                PsxSymbolType.SQUARE -> {
                    val halfW = radius * 0.86f
                    drawRoundRect(
                        color = color,
                        topLeft = Offset(cx - halfW, cy - halfW),
                        size = Size(halfW * 2f, halfW * 2f),
                        cornerRadius = CornerRadius(strokePx * 0.4f, strokePx * 0.4f),
                        style = style
                    )
                }
            }
        }
    }
}
