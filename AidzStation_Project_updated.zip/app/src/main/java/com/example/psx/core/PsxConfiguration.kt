package com.example.psx.core

import android.content.Context
import android.content.SharedPreferences

enum class AspectRatioMode(val label: String, val ratio: Float?) {
    AUTO("Auto Detect", 4f / 3f),
    ORIGINAL_4_3("4:3 Original", 4f / 3f),
    WIDESCREEN_16_9("16:9 Widescreen", 16f / 9f),
    INTEGER_SCALE("1:1 Pixel Match", 4f / 3f),
    STRETCH_FULL("Fill Screen (Stretch)", null)
}

enum class TextureFiltering(val label: String) {
    NEAREST("Nearest-Neighbor (Pixelated)"),
    SMOOTH("Bilinear Smooth (Filtered)")
}

enum class PerformanceProfile(val label: String, val description: String) {
    BATTERY_SAVER("Battery Saver", "Native 1x, conservative CPU cycles, maximum battery longevity"),
    BALANCED("Balanced", "Default authentic 60 FPS, balanced audio latency and sync"),
    ENHANCED("Enhanced (High-End)", "Upscaled resolution, texture enhancements, widescreen presentation")
}

enum class BiosMode(val label: String) {
    AUTO_OR_HLE("Auto (Detect BIOS or HLE)"),
    FORCE_HLE("Force Built-in HLE BIOS"),
    OFFICIAL("Official BIOS Required")
}

data class PsxConfiguration(
    // Graphics Options (DuckStation-style)
    val internalResolutionScale: Int = 1, // 1x Native, 2x Enhanced, 4x Ultra HD
    val textureFiltering: TextureFiltering = TextureFiltering.SMOOTH,
    val pgxpGeometryCorrection: Boolean = false, // Reduces wobbly polygons
    val isDitheringEnabled: Boolean = true, // True color vs authentic dithering
    val isWidescreenHackEnabled: Boolean = false,
    val aspectRatio: AspectRatioMode = AspectRatioMode.ORIGINAL_4_3,
    val integerScaling: Boolean = false,
    val crtScanlines: Boolean = false,
    val frameSkip: Int = 0, // 0 = Off, 1 = 1 Frame, 2 = 2 Frames
    val showFpsCounter: Boolean = true,
    val isVsyncEnabled: Boolean = true,
    val fastBoot: Boolean = false, // Skip boot intro

    // Performance & Audio
    val fastForwardSpeed: Float = 2.0f,
    val isFastForwardActive: Boolean = false,
    val masterVolume: Float = 1.0f,
    val audioBufferMs: Int = 64,
    val isAudioSyncEnabled: Boolean = true,

    // BIOS Settings
    val biosMode: BiosMode = BiosMode.AUTO_OR_HLE,
    val selectedBiosPath: String = "",

    // Controls
    val touchControlsVisible: Boolean = true,
    val touchOpacity: Float = 0.75f,
    val touchScale: Float = 1.0f,
    val touchHapticsEnabled: Boolean = true,
    val isDualShockAnalog: Boolean = true,
    val analogDeadzone: Float = 0.15f,

    // System Profiles & Core
    val profile: PerformanceProfile = PerformanceProfile.BALANCED,
    val useNativeCore: Boolean = true,

    // Recent Game History for Shortcuts
    val lastPlayedGamePath: String = "",
    val recentGamePaths: List<String> = emptyList()
) {
    companion object {
        private const val PREFS_NAME = "psx_retro_preferences"

        fun load(context: Context): PsxConfiguration {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val recentCsv = prefs.getString("recent_games_csv", "") ?: ""
            val recentList = if (recentCsv.isNotBlank()) recentCsv.split(";;").filter { it.isNotBlank() } else emptyList()

            return PsxConfiguration(
                internalResolutionScale = prefs.getInt("resolution_scale", 1),
                textureFiltering = try {
                    TextureFiltering.valueOf(prefs.getString("texture_filtering", TextureFiltering.SMOOTH.name) ?: TextureFiltering.SMOOTH.name)
                } catch (_: Exception) { TextureFiltering.SMOOTH },
                pgxpGeometryCorrection = prefs.getBoolean("pgxp_geometry", false),
                isDitheringEnabled = prefs.getBoolean("dithering", true),
                isWidescreenHackEnabled = prefs.getBoolean("widescreen", false),
                aspectRatio = try {
                    AspectRatioMode.valueOf(prefs.getString("aspect_ratio", AspectRatioMode.ORIGINAL_4_3.name) ?: AspectRatioMode.ORIGINAL_4_3.name)
                } catch (_: Exception) { AspectRatioMode.ORIGINAL_4_3 },
                integerScaling = prefs.getBoolean("integer_scaling", false),
                crtScanlines = prefs.getBoolean("crt_scanlines", false),
                frameSkip = prefs.getInt("frame_skip", 0),
                showFpsCounter = prefs.getBoolean("show_fps_counter", true),
                isVsyncEnabled = prefs.getBoolean("vsync", true),
                fastBoot = prefs.getBoolean("fast_boot", false),

                masterVolume = prefs.getFloat("volume", 1.0f),
                audioBufferMs = prefs.getInt("audio_buffer", 64),
                isAudioSyncEnabled = prefs.getBoolean("audio_sync", true),

                biosMode = try {
                    BiosMode.valueOf(prefs.getString("bios_mode", BiosMode.AUTO_OR_HLE.name) ?: BiosMode.AUTO_OR_HLE.name)
                } catch (_: Exception) { BiosMode.AUTO_OR_HLE },
                selectedBiosPath = prefs.getString("selected_bios_path", "") ?: "",

                touchControlsVisible = prefs.getBoolean("touch_visible", true),
                touchOpacity = prefs.getFloat("touch_opacity", 0.75f),
                touchScale = prefs.getFloat("touch_scale", 1.0f),
                touchHapticsEnabled = prefs.getBoolean("touch_haptics", true),
                isDualShockAnalog = prefs.getBoolean("dualshock_analog", true),

                profile = try {
                    PerformanceProfile.valueOf(prefs.getString("profile", PerformanceProfile.BALANCED.name) ?: PerformanceProfile.BALANCED.name)
                } catch (_: Exception) { PerformanceProfile.BALANCED },
                useNativeCore = prefs.getBoolean("use_native_core", true),

                lastPlayedGamePath = prefs.getString("last_played_path", "") ?: "",
                recentGamePaths = recentList
            )
        }

        fun save(context: Context, config: PsxConfiguration) {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val recentCsv = config.recentGamePaths.take(6).joinToString(";;")

            prefs.edit()
                .putInt("resolution_scale", config.internalResolutionScale)
                .putString("texture_filtering", config.textureFiltering.name)
                .putBoolean("pgxp_geometry", config.pgxpGeometryCorrection)
                .putBoolean("dithering", config.isDitheringEnabled)
                .putBoolean("widescreen", config.isWidescreenHackEnabled)
                .putString("aspect_ratio", config.aspectRatio.name)
                .putBoolean("integer_scaling", config.integerScaling)
                .putBoolean("crt_scanlines", config.crtScanlines)
                .putInt("frame_skip", config.frameSkip)
                .putBoolean("show_fps_counter", config.showFpsCounter)
                .putBoolean("vsync", config.isVsyncEnabled)
                .putBoolean("fast_boot", config.fastBoot)

                .putFloat("volume", config.masterVolume)
                .putInt("audio_buffer", config.audioBufferMs)
                .putBoolean("audio_sync", config.isAudioSyncEnabled)

                .putString("bios_mode", config.biosMode.name)
                .putString("selected_bios_path", config.selectedBiosPath)

                .putBoolean("touch_visible", config.touchControlsVisible)
                .putFloat("touch_opacity", config.touchOpacity)
                .putFloat("touch_scale", config.touchScale)
                .putBoolean("touch_haptics", config.touchHapticsEnabled)
                .putBoolean("dualshock_analog", config.isDualShockAnalog)

                .putString("profile", config.profile.name)
                .putBoolean("use_native_core", config.useNativeCore)

                .putString("last_played_path", config.lastPlayedGamePath)
                .putString("recent_games_csv", recentCsv)
                .apply()
        }
    }
}
