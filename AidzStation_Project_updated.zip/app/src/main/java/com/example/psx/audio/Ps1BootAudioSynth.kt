package com.example.psx.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * Procedural synthesizer closely representing the authentic 1994 PlayStation 1 console startup sound.
 * Procedurally synthesizes the shimmering ascending chime arpeggio and the deep orchestral
 * sub-bass drone and choir swell entirely in software (no copyrighted recordings or samples).
 */
object Ps1BootAudioSynth {
    private var currentTrack: AudioTrack? = null

    suspend fun playBootChimeAndDrone() = withContext(Dispatchers.IO) {
        stop()
        try {
            val sampleRate = 44100
            val totalSeconds = 7.5
            val numSamples = (sampleRate * totalSeconds).toInt()
            val buffer = ShortArray(numSamples)

            // Phase 1: Ascending SCE Chime arpeggio note frequencies (D Major 9th / Lydian crystal chime)
            // D4, F#4, A4, D5, F#5, A5, C#6
            val chimeNotes = doubleArrayOf(293.66, 369.99, 440.00, 587.33, 739.99, 880.00, 1108.73)
            val noteStagger = 0.055 // 55ms stagger between bell strikes

            // Phase 2: Orchestral Sub-Bass Drone & Choir Swell (PlayStation Diamond Logo)
            // Deep sub fundamental (48 Hz), fifths and major triad (D1=36.7Hz, D2=73.4Hz, A2=110Hz, D3=146.8Hz, F#3=185.0Hz, A3=220Hz, D4=293.66Hz)
            val droneTones = doubleArrayOf(36.71, 48.00, 73.42, 110.00, 146.83, 185.00, 220.00, 293.66)

            for (i in 0 until numSamples) {
                val t = i.toDouble() / sampleRate
                var sample = 0.0

                // PHASE 1: Ascending crystal chime arpeggio (0.0s to 3.4s)
                if (t < 3.4) {
                    for ((index, baseFreq) in chimeNotes.withIndex()) {
                        val noteStart = index * noteStagger
                        if (t >= noteStart) {
                            val dt = t - noteStart
                            // Bell strike envelope: instant attack, exponential decay with long resonance
                            val bellEnv = exp(-dt * 1.35) * (1.0 - exp(-dt * 80.0))

                            // Bell fundamental + metallic inharmonic partials (characteristic of PS1 boot bell)
                            val f1 = sin(2.0 * PI * baseFreq * dt) * 0.16
                            val f2 = sin(2.0 * PI * (baseFreq * 2.756) * dt) * 0.06
                            val f3 = sin(2.0 * PI * (baseFreq * 5.404) * dt) * 0.03
                            val shimmer = sin(2.0 * PI * (baseFreq * 2.005) * dt) * 0.05

                            sample += (f1 + f2 + f3 + shimmer) * bellEnv
                        }
                    }
                }

                // PHASE 2: Deep Cinematic Bass Impact, French Horn Swell & Choir Harmonics (3.2s to 7.5s)
                if (t >= 3.2) {
                    val dt = t - 3.2

                    // 1. Heavy sub-bass impact thump at logo reveal (dt 0.0 to 1.2s)
                    val thumpEnv = exp(-dt * 3.2) * (1.0 - exp(-dt * 120.0))
                    val subImpact = sin(2.0 * PI * (52.0 - dt * 10.0).coerceAtLeast(35.0) * dt) * 0.45 * thumpEnv
                    sample += subImpact

                    // 2. Slow majestic orchestral swell & choir sustain (peaking around 1.1s after logo, then sustaining)
                    val swellEnv = if (dt < 1.1) {
                        (dt / 1.1) * (dt / 1.1) // quadratic swell
                    } else {
                        // Warm orchestral decay
                        exp(-(dt - 1.1) * 0.38)
                    }

                    var orchestraSum = 0.0
                    for (tone in droneTones) {
                        // Rich brass & cello harmonics
                        val o1 = sin(2.0 * PI * tone * dt) * 0.18
                        val o2 = sin(2.0 * PI * (tone * 2.01) * dt) * 0.08
                        val o3 = sin(2.0 * PI * (tone * 3.0) * dt) * 0.04
                        orchestraSum += (o1 + o2 + o3)
                    }

                    // 3. Ethereal choir vocal "aah" formant resonance (~720Hz and ~1150Hz)
                    val choirFormant1 = sin(2.0 * PI * 720.0 * dt) * 0.05
                    val choirFormant2 = sin(2.0 * PI * 1150.0 * dt) * 0.03
                    val choirLfo = 1.0 + 0.15 * sin(2.0 * PI * 4.5 * dt) // 4.5Hz gentle choir vibrato

                    sample += (orchestraSum + (choirFormant1 + choirFormant2) * choirLfo) * swellEnv * 0.75
                }

                // Soft saturation limiter to prevent digital clipping
                val limited = if (sample > 0.92) {
                    0.92 + 0.08 * kotlin.math.tanh((sample - 0.92) / 0.08)
                } else if (sample < -0.92) {
                    -0.92 + 0.08 * kotlin.math.tanh((sample + 0.92) / 0.08)
                } else {
                    sample
                }

                buffer[i] = (limited * 32767.0).toInt().coerceIn(-32767, 32767).toShort()
            }

            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(buffer.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            track.write(buffer, 0, buffer.size)
            track.play()
            currentTrack = track
        } catch (_: Exception) {
            // Audio synthesis fallback
        }
    }

    fun stop() {
        try {
            currentTrack?.stop()
            currentTrack?.release()
        } catch (_: Exception) {
        } finally {
            currentTrack = null
        }
    }
}
