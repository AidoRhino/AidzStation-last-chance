package com.example.psx.data

import android.content.Context
import java.io.File

data class MemoryCardBlock(
    val slotIndex: Int,
    val title: String,
    val productCode: String,
    val isUsed: Boolean
)

class MemoryCardManager(private val context: Context) {
    val cardsDir = File(context.filesDir, "memorycards").apply { mkdirs() }
    val savesDir = File(context.filesDir, "saves").apply { mkdirs() }

    val card1File = File(cardsDir, "memcard1.mcr")
    val card2File = File(cardsDir, "memcard2.mcr")

    init {
        ensureCardExists(card1File)
        ensureCardExists(card2File)
        // Also keep pcsx-card1.mcd and pcsx-card2.mcd in savesDir in sync for core file access
        val pcsxCard1 = File(savesDir, "pcsx-card1.mcd")
        val pcsxCard2 = File(savesDir, "pcsx-card2.mcd")
        ensureCardExists(pcsxCard1)
        ensureCardExists(pcsxCard2)
    }

    companion object {
        const val MEMORY_CARD_SIZE = 131072 // 128 KB standard PS1 memory card

        /**
         * Creates a standard formatted PS1 memory card binary with valid Sony directory structures.
         * 128 KB divided into 16 blocks of 8 KB (64 frames of 128 bytes each).
         */
        fun createFormattedMemoryCard(): ByteArray {
            val card = ByteArray(MEMORY_CARD_SIZE)

            // Block 0 / Frame 0: Header Frame
            card[0] = 'M'.code.toByte() // 0x4D
            card[1] = 'C'.code.toByte() // 0x43
            card[127] = ('M'.code xor 'C'.code).toByte() // 0x0E checksum

            // Block 0 / Frames 1 to 15: Directory entries for 15 save slots
            for (f in 1..15) {
                val offset = f * 128
                card[offset] = 0xA0.toByte()      // 0xA0 = Free / Unallocated block flag
                card[offset + 8] = 0x00.toByte()
                card[offset + 9] = 0x00.toByte()
                card[offset + 10] = 0xA0.toByte()
                card[offset + 127] = 0x00.toByte() // (0xA0 xor 0xA0 = 0x00 checksum)
            }

            // Block 0 / Frames 16 to 35: Broken frame list (all 0xFF, checksum 0x00)
            for (f in 16..35) {
                val offset = f * 128
                for (i in 0 until 127) {
                    card[offset + i] = 0xFF.toByte()
                }
                card[offset + 127] = 0x00.toByte()
            }

            // Block 0 / Frames 36 to 63: Unused / Reserved frames (all 0xFF)
            for (f in 36..63) {
                val offset = f * 128
                for (i in 0 until 127) {
                    card[offset + i] = 0xFF.toByte()
                }
                card[offset + 127] = 0x00.toByte()
            }

            return card
        }
    }

    private fun ensureCardExists(file: File) {
        if (!file.exists() || file.length() != MEMORY_CARD_SIZE.toLong()) {
            val formattedCard = createFormattedMemoryCard()
            file.writeBytes(formattedCard)
        }
    }

    fun getMemoryCardBlocks(slot: Int): List<MemoryCardBlock> {
        val file = if (slot == 1) card1File else card2File
        val list = mutableListOf<MemoryCardBlock>()
        if (!file.exists() || file.length() != MEMORY_CARD_SIZE.toLong()) {
            return list
        }

        try {
            val bytes = file.readBytes()
            // Inspect directory frames 1 to 15 (slots 1 to 15)
            for (i in 1..15) {
                val frameOffset = i * 128
                val blockFlag = bytes[frameOffset].toInt() and 0xFF
                val isUsed = (blockFlag and 0xF0) == 0x50 // 0x51 = first block, 0x52 = middle, 0x53 = last

                var title = "Empty Block"
                var prodCode = "SLUS-0000$i"

                if (isUsed) {
                    // Extract Shift-JIS / ASCII title or product code from directory frame
                    val rawCode = String(bytes, frameOffset + 12, 16, Charsets.US_ASCII).trim { it <= ' ' || it == '\u0000' }
                    if (rawCode.isNotEmpty()) prodCode = rawCode
                    title = "Saved Game ($prodCode)"
                }

                list.add(
                    MemoryCardBlock(
                        slotIndex = i,
                        title = title,
                        productCode = prodCode,
                        isUsed = isUsed
                    )
                )
            }
        } catch (_: Exception) {
            for (i in 1..15) {
                list.add(MemoryCardBlock(i, "Block #$i", "SLUS-0000$i", false))
            }
        }
        return list
    }

    fun formatCard(slot: Int): Boolean {
        val file = if (slot == 1) card1File else card2File
        return try {
            val formatted = createFormattedMemoryCard()
            file.writeBytes(formatted)
            // Also sync to pcsx-card
            val pcsxCard = File(savesDir, if (slot == 1) "pcsx-card1.mcd" else "pcsx-card2.mcd")
            pcsxCard.writeBytes(formatted)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun importCard(slot: Int, sourceFile: File): Boolean {
        val target = if (slot == 1) card1File else card2File
        return try {
            val bytes = sourceFile.readBytes()
            if (bytes.size != MEMORY_CARD_SIZE) return false
            target.writeBytes(bytes)
            val pcsxCard = File(savesDir, if (slot == 1) "pcsx-card1.mcd" else "pcsx-card2.mcd")
            pcsxCard.writeBytes(bytes)
            true
        } catch (_: Exception) {
            false
        }
    }
}
