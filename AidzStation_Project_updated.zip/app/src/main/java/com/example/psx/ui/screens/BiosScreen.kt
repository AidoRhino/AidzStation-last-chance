package com.example.psx.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.psx.data.BiosInfo
import com.example.psx.data.BiosManager
import com.example.psx.ui.theme.*
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BiosScreen(
    biosManager: BiosManager,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var biosList by remember { mutableStateOf(biosManager.getDetectedBiosList()) }
    var importStatus by remember { mutableStateOf<String?>(null) }

    BackHandler {
        onBack()
    }

    val biosPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch {
                try {
                    val contentResolver = context.contentResolver
                    val tempFile = File(context.cacheDir, "temp_bios.bin")
                    contentResolver.openInputStream(uri)?.use { input ->
                        FileOutputStream(tempFile).use { output ->
                            input.copyTo(output)
                        }
                    }

                    val result = biosManager.importBiosFile(tempFile)
                    importStatus = result.second
                    biosList = biosManager.getDetectedBiosList()
                } catch (e: Exception) {
                    importStatus = "Error reading BIOS file: ${e.message}"
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "BIOS MANAGEMENT",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("bios_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = PsxTextPrimary)
                    }
                },
                actions = {
                    IconButton(
                        onClick = { biosPickerLauncher.launch(arrayOf("*/*")) },
                        modifier = Modifier.testTag("import_bios_action")
                    ) {
                        Icon(Icons.Default.FileUpload, contentDescription = "Import BIOS", tint = PsxTriangleGreen)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PsxSurfaceDark)
            )
        },
        containerColor = Color.Transparent
    ) { paddingValues ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(Modifier.height(12.dp))

            // HLE Built-in BIOS Active Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = PsxCardSurface),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, PsxTriangleGreen.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(PsxTriangleGreen.copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Verified, contentDescription = null, tint = PsxTriangleGreen)
                    }

                    Column {
                        Text(
                            text = "PCSX HLE BIOS ENGINE",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = PsxTriangleGreen
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = "Built-in High-Level Emulation is enabled. The emulator can boot and run compatible games without requiring copyrighted Sony BIOS dumps.",
                            fontSize = 12.sp,
                            color = PsxTextSecondary,
                            lineHeight = 16.sp
                        )
                    }
                }
            }

            if (importStatus != null) {
                Spacer(Modifier.height(10.dp))
                Text(
                    text = importStatus!!,
                    fontSize = 12.sp,
                    color = PsxYellowAccent,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(PsxCardElevated, RoundedCornerShape(8.dp))
                        .padding(10.dp)
                )
            }

            Spacer(Modifier.height(20.dp))

            Text(
                text = "OFFICIAL HARDWARE BIOS DUMPS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = PsxTextSecondary,
                letterSpacing = 1.sp
            )

            Spacer(Modifier.height(8.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(biosList) { info ->
                    BiosItemCard(info = info)
                }

                item {
                    Spacer(Modifier.height(16.dp))
                    Button(
                        onClick = { biosPickerLauncher.launch(arrayOf("*/*")) },
                        colors = ButtonDefaults.buttonColors(containerColor = PsxCrossBlue),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("select_bios_button")
                    ) {
                        Icon(Icons.Default.FolderOpen, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("SELECT BIOS FILE (512 KB)", fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(30.dp))
                }
            }
        }
    }
}

@Composable
private fun BiosItemCard(info: BiosInfo) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = PsxCardSurface),
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (info.isPresent) PsxTriangleGreen else PsxDarkCharcoal)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = info.fileName.uppercase(),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = PsxTextPrimary
                )
                Text(
                    text = info.region,
                    fontSize = 11.sp,
                    color = PsxTextSecondary
                )
                Text(
                    text = info.description,
                    fontSize = 10.sp,
                    color = PsxTextDisabled
                )
            }

            if (info.isPresent) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = PsxTriangleGreen, modifier = Modifier.size(16.dp))
                    Text("READY", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = PsxTriangleGreen)
                }
            } else {
                Text("NOT FOUND", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = PsxTextDisabled)
            }
        }
    }
}
