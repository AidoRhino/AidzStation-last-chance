package com.example.psx.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.psx.core.AspectRatioMode
import com.example.psx.core.PsxConfiguration
import com.example.psx.core.PsxEmulatorEngine
import com.example.psx.ui.theme.*

@Composable
fun EmulationMenuDialog(
    engine: PsxEmulatorEngine,
    onDismiss: () -> Unit,
    onExitGame: () -> Unit,
    onEditControls: () -> Unit = {}
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var selectedSlot by remember { mutableIntStateOf(engine.currentSaveSlot) }
    var statusText by remember { mutableStateOf(engine.statusMessage.value ?: "") }
    var currentAspect by remember { mutableStateOf(engine.config.aspectRatio) }
    var showRetroAchievements by remember { mutableStateOf(false) }

    if (showRetroAchievements) {
        RetroAchievementsDialog(
            manager = engine.retroAchievements,
            onDismiss = { showRetroAchievements = false }
        )
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
                .clip(RoundedCornerShape(16.dp))
                .border(2.dp, PsxConsoleGrey, RoundedCornerShape(16.dp)),
            color = PsxSurfaceDark,
            tonalElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header with PlayStation Icon
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "EMULATION PAUSED",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            color = PsxTextPrimary,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = engine.currentGameTitle.value ?: "PlayStation 1",
                            fontSize = 13.sp,
                            color = PsxTriangleGreen
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(36.dp)
                            .background(PsxCardElevated, CircleShape)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Resume", tint = PsxTextPrimary)
                    }
                }

                if (statusText.isNotBlank()) {
                    Text(
                        text = statusText,
                        fontSize = 12.sp,
                        color = PsxYellowAccent,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(PsxCardSurface, RoundedCornerShape(6.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }

                // SAVE STATE SLOTS (1 to 5)
                Text("SAVE STATE SLOTS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PsxTextSecondary)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    for (slot in 1..5) {
                        val isSelected = selectedSlot == slot
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) PsxCrossBlue else PsxCardElevated)
                                .clickable { selectedSlot = slot },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Slot $slot",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else PsxTextPrimary
                            )
                        }
                    }
                }

                // Quick Save & Quick Load Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = {
                            val ok = engine.saveSlot(selectedSlot)
                            statusText = if (ok) "Saved to Slot $selectedSlot" else "Error saving state"
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PsxCardElevated),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dialog_save_state_button")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp), tint = PsxTriangleGreen)
                        Spacer(Modifier.width(6.dp))
                        Text("Save State", color = PsxTextPrimary, fontSize = 13.sp)
                    }

                    Button(
                        onClick = {
                            val ok = engine.loadSlot(selectedSlot)
                            statusText = if (ok) "Loaded Slot $selectedSlot" else "Slot $selectedSlot is empty"
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PsxCardElevated),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dialog_load_state_button")
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp), tint = PsxCrossBlue)
                        Spacer(Modifier.width(6.dp))
                        Text("Load State", color = PsxTextPrimary, fontSize = 13.sp)
                    }
                }

                HorizontalDivider(color = PsxDarkCharcoal)

                // Resolution Selector (1x, 2x, 4x)
                Text("INTERNAL RESOLUTION", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PsxTextSecondary)
                var currentRes by remember { mutableIntStateOf(engine.config.internalResolutionScale) }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(1 to "1x Native", 2 to "2x HD", 4 to "4x Ultra HD").forEach { (res, label) ->
                        val isSelected = currentRes == res
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                currentRes = res
                                val newConf = engine.config.copy(internalResolutionScale = res)
                                engine.updateConfiguration(newConf)
                                PsxConfiguration.save(context, newConf)
                                statusText = "Resolution set to $label"
                            },
                            label = { Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PsxTriangleGreen,
                                selectedLabelColor = Color.Black
                            )
                        )
                    }
                }

                HorizontalDivider(color = PsxDarkCharcoal)

                // Aspect Ratio Selector
                Text("ASPECT RATIO", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PsxTextSecondary)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    AspectRatioMode.entries.forEach { mode ->
                        val isSelected = currentAspect == mode
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                currentAspect = mode
                                val isWs = (mode == AspectRatioMode.WIDESCREEN_16_9 || mode == AspectRatioMode.STRETCH_FULL)
                                val newConf = engine.config.copy(
                                    aspectRatio = mode,
                                    isWidescreenHackEnabled = isWs
                                )
                                engine.updateConfiguration(newConf)
                                PsxConfiguration.save(context, newConf)
                                statusText = "Aspect Ratio: ${mode.label}"
                            },
                            label = { Text(mode.label, fontSize = 10.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PsxCrossBlue,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                // Widescreen Hack (16:9) Toggle
                val isWsActive = engine.config.isWidescreenHackEnabled || engine.config.aspectRatio == AspectRatioMode.WIDESCREEN_16_9
                var widescreenHack by remember { mutableStateOf(isWsActive) }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(PsxCardElevated, RoundedCornerShape(8.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Widescreen Hack (16:9)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PsxTextPrimary)
                        Text("Expands 3D geometry and removes borders", fontSize = 10.sp, color = PsxTextSecondary)
                    }
                    Switch(
                        checked = widescreenHack,
                        onCheckedChange = { checked ->
                            widescreenHack = checked
                            val targetAspect = if (checked) AspectRatioMode.WIDESCREEN_16_9 else AspectRatioMode.ORIGINAL_4_3
                            currentAspect = targetAspect
                            val newConf = engine.config.copy(
                                isWidescreenHackEnabled = checked,
                                aspectRatio = targetAspect
                            )
                            engine.updateConfiguration(newConf)
                            PsxConfiguration.save(context, newConf)
                            statusText = if (checked) "16:9 Widescreen Enabled" else "4:3 Standard Enabled"
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = PsxTriangleGreen
                        )
                    )
                }

                // Reset & Fast Forward Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            engine.reset()
                            statusText = "Emulation Reset"
                            onDismiss()
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, tint = PsxCircleRed, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Reset", color = PsxCircleRed)
                    }

                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = PsxTriangleGreen),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Resume", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }

                // RetroAchievements Button
                OutlinedButton(
                    onClick = {
                        showRetroAchievements = true
                    },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = PsxYellowAccent),
                    border = androidx.compose.foundation.BorderStroke(1.dp, PsxYellowAccent.copy(alpha = 0.6f)),
                    modifier = Modifier.fillMaxWidth().testTag("dialog_retro_achievements_button")
                ) {
                    Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = PsxYellowAccent, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("RetroAchievements", color = PsxYellowAccent, fontWeight = FontWeight.Bold)
                }

                // Edit Controls Layout Button
                OutlinedButton(
                    onClick = {
                        onDismiss()
                        onEditControls()
                    },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = PsxTriangleGreen),
                    border = androidx.compose.foundation.BorderStroke(1.dp, PsxTriangleGreen.copy(alpha = 0.6f)),
                    modifier = Modifier.fillMaxWidth().testTag("dialog_edit_controls_button")
                ) {
                    Icon(Icons.Default.TouchApp, contentDescription = null, tint = PsxTriangleGreen, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Edit Controls Layout", color = PsxTriangleGreen, fontWeight = FontWeight.Bold)
                }

                // Exit Game Button
                OutlinedButton(
                    onClick = {
                        onDismiss()
                        onExitGame()
                    },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = PsxTextSecondary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dialog_exit_game_button")
                ) {
                    Icon(Icons.Default.ExitToApp, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Exit to Dashboard")
                }
            }
        }
    }
}
