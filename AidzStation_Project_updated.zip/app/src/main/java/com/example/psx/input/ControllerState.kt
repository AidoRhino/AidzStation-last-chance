package com.example.psx.input

import android.view.KeyEvent
import android.view.MotionEvent
import com.example.psx.core.LibretroDefs

class ControllerState {
    // Joypad buttons bitmask or flags
    @Volatile var dpadUp: Boolean = false
    @Volatile var dpadDown: Boolean = false
    @Volatile var dpadLeft: Boolean = false
    @Volatile var dpadRight: Boolean = false

    @Volatile var cross: Boolean = false    // X (Button B in libretro)
    @Volatile var circle: Boolean = false   // O (Button A in libretro)
    @Volatile var square: Boolean = false   // [] (Button Y in libretro)
    @Volatile var triangle: Boolean = false // /\ (Button X in libretro)

    @Volatile var l1: Boolean = false
    @Volatile var r1: Boolean = false
    @Volatile var l2: Boolean = false
    @Volatile var r2: Boolean = false
    @Volatile var l3: Boolean = false
    @Volatile var r3: Boolean = false

    @Volatile var start: Boolean = false
    @Volatile var select: Boolean = false

    // Analog sticks (-32768 to 32767)
    @Volatile var leftStickX: Short = 0
    @Volatile var leftStickY: Short = 0
    @Volatile var rightStickX: Short = 0
    @Volatile var rightStickY: Short = 0

    fun getButtonState(id: Int): Short {
        val isUp = dpadUp || (leftStickY < -16000)
        val isDown = dpadDown || (leftStickY > 16000)
        val isLeft = dpadLeft || (leftStickX < -16000)
        val isRight = dpadRight || (leftStickX > 16000)

        val pressed = when (id) {
            LibretroDefs.RETRO_DEVICE_ID_JOYPAD_B -> cross
            LibretroDefs.RETRO_DEVICE_ID_JOYPAD_A -> circle
            LibretroDefs.RETRO_DEVICE_ID_JOYPAD_Y -> square
            LibretroDefs.RETRO_DEVICE_ID_JOYPAD_X -> triangle
            LibretroDefs.RETRO_DEVICE_ID_JOYPAD_UP -> isUp
            LibretroDefs.RETRO_DEVICE_ID_JOYPAD_DOWN -> isDown
            LibretroDefs.RETRO_DEVICE_ID_JOYPAD_LEFT -> isLeft
            LibretroDefs.RETRO_DEVICE_ID_JOYPAD_RIGHT -> isRight
            LibretroDefs.RETRO_DEVICE_ID_JOYPAD_START -> start
            LibretroDefs.RETRO_DEVICE_ID_JOYPAD_SELECT -> select
            LibretroDefs.RETRO_DEVICE_ID_JOYPAD_L -> l1
            LibretroDefs.RETRO_DEVICE_ID_JOYPAD_R -> r1
            LibretroDefs.RETRO_DEVICE_ID_JOYPAD_L2 -> l2
            LibretroDefs.RETRO_DEVICE_ID_JOYPAD_R2 -> r2
            LibretroDefs.RETRO_DEVICE_ID_JOYPAD_L3 -> l3
            LibretroDefs.RETRO_DEVICE_ID_JOYPAD_R3 -> r3
            else -> false
        }
        return if (pressed) 1 else 0
    }

    fun getAnalogState(index: Int, id: Int): Short {
        return when (index) {
            LibretroDefs.RETRO_DEVICE_INDEX_ANALOG_LEFT -> {
                if (id == LibretroDefs.RETRO_DEVICE_ID_ANALOG_X) leftStickX else leftStickY
            }
            LibretroDefs.RETRO_DEVICE_INDEX_ANALOG_RIGHT -> {
                if (id == LibretroDefs.RETRO_DEVICE_ID_ANALOG_X) rightStickX else rightStickY
            }
            else -> 0
        }
    }

    // Handles physical Bluetooth / USB gamepads
    fun onKeyDown(keyCode: Int): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> dpadUp = true
            KeyEvent.KEYCODE_DPAD_DOWN -> dpadDown = true
            KeyEvent.KEYCODE_DPAD_LEFT -> dpadLeft = true
            KeyEvent.KEYCODE_DPAD_RIGHT -> dpadRight = true
            KeyEvent.KEYCODE_BUTTON_A -> cross = true
            KeyEvent.KEYCODE_BUTTON_B -> circle = true
            KeyEvent.KEYCODE_BUTTON_X -> square = true
            KeyEvent.KEYCODE_BUTTON_Y -> triangle = true
            KeyEvent.KEYCODE_BUTTON_L1 -> l1 = true
            KeyEvent.KEYCODE_BUTTON_R1 -> r1 = true
            KeyEvent.KEYCODE_BUTTON_L2 -> l2 = true
            KeyEvent.KEYCODE_BUTTON_R2 -> r2 = true
            KeyEvent.KEYCODE_BUTTON_THUMBL -> l3 = true
            KeyEvent.KEYCODE_BUTTON_THUMBR -> r3 = true
            KeyEvent.KEYCODE_BUTTON_START -> start = true
            KeyEvent.KEYCODE_BUTTON_SELECT -> select = true
            else -> return false
        }
        return true
    }

    fun onKeyUp(keyCode: Int): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> dpadUp = false
            KeyEvent.KEYCODE_DPAD_DOWN -> dpadDown = false
            KeyEvent.KEYCODE_DPAD_LEFT -> dpadLeft = false
            KeyEvent.KEYCODE_DPAD_RIGHT -> dpadRight = false
            KeyEvent.KEYCODE_BUTTON_A -> cross = false
            KeyEvent.KEYCODE_BUTTON_B -> circle = false
            KeyEvent.KEYCODE_BUTTON_X -> square = false
            KeyEvent.KEYCODE_BUTTON_Y -> triangle = false
            KeyEvent.KEYCODE_BUTTON_L1 -> l1 = false
            KeyEvent.KEYCODE_BUTTON_R1 -> r1 = false
            KeyEvent.KEYCODE_BUTTON_L2 -> l2 = false
            KeyEvent.KEYCODE_BUTTON_R2 -> r2 = false
            KeyEvent.KEYCODE_BUTTON_THUMBL -> l3 = false
            KeyEvent.KEYCODE_BUTTON_THUMBR -> r3 = false
            KeyEvent.KEYCODE_BUTTON_START -> start = false
            KeyEvent.KEYCODE_BUTTON_SELECT -> select = false
            else -> return false
        }
        return true
    }

    fun onGenericMotionEvent(event: MotionEvent): Boolean {
        if (event.source and android.view.InputDevice.SOURCE_JOYSTICK == android.view.InputDevice.SOURCE_JOYSTICK) {
            val lx = event.getAxisValue(MotionEvent.AXIS_X)
            val ly = event.getAxisValue(MotionEvent.AXIS_Y)
            val rx = event.getAxisValue(MotionEvent.AXIS_Z)
            val ry = event.getAxisValue(MotionEvent.AXIS_RZ)

            leftStickX = (lx * 32767).toInt().coerceIn(-32768, 32767).toShort()
            leftStickY = (ly * 32767).toInt().coerceIn(-32768, 32767).toShort()
            rightStickX = (rx * 32767).toInt().coerceIn(-32768, 32767).toShort()
            rightStickY = (ry * 32767).toInt().coerceIn(-32768, 32767).toShort()

            val hatX = event.getAxisValue(MotionEvent.AXIS_HAT_X)
            val hatY = event.getAxisValue(MotionEvent.AXIS_HAT_Y)
            dpadLeft = hatX < -0.5f
            dpadRight = hatX > 0.5f
            dpadUp = hatY < -0.5f
            dpadDown = hatY > 0.5f
            return true
        }
        return false
    }

    fun reset() {
        dpadUp = false
        dpadDown = false
        dpadLeft = false
        dpadRight = false
        cross = false
        circle = false
        square = false
        triangle = false
        l1 = false
        r1 = false
        l2 = false
        r2 = false
        l3 = false
        r3 = false
        start = false
        select = false
        leftStickX = 0
        leftStickY = 0
        rightStickX = 0
        rightStickY = 0
    }
}
