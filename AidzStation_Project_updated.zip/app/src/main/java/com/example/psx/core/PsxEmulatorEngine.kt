package com.example.psx.core

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.Rect
import android.os.Build
import android.util.Log
import android.view.SurfaceHolder
import com.example.psx.audio.PsxAudioPlayer
import com.example.psx.input.ControllerState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

class PsxEmulatorEngine(
    private val context: Context
) {
    companion object {
        private const val TAG = "PsxEmulatorEngine"
        private const val TARGET_FPS_NTSC = 60.0
        private const val FRAME_TIME_NS = (1_000_000_000.0 / TARGET_FPS_NTSC).toLong()
    }

    private val _config = MutableStateFlow(PsxConfiguration.load(context))
    val configState: StateFlow<PsxConfiguration> = _config.asStateFlow()
    val config: PsxConfiguration get() = _config.value

    fun updateConfiguration(newConfig: PsxConfiguration) {
        _config.value = newConfig
        libretroBridge.config = newConfig
        audioPlayer.setVolume(newConfig.masterVolume)
        PsxConfiguration.save(context, newConfig)
        Log.i(TAG, "Configuration updated and saved: scale=${newConfig.internalResolutionScale}x, aspect=${newConfig.aspectRatio}, vsync=${newConfig.isVsyncEnabled}")
    }

    fun reloadConfiguration() {
        val loaded = PsxConfiguration.load(context)
        _config.value = loaded
        libretroBridge.config = loaded
        audioPlayer.setVolume(loaded.masterVolume)
    }

    val audioPlayer = PsxAudioPlayer()
    val controllerState = ControllerState()

    val systemDir = File(context.filesDir, "bios").apply { mkdirs() }
    val saveDir = File(context.filesDir, "saves").apply { mkdirs() }
    val memoryCardDir = File(context.filesDir, "memorycards").apply { mkdirs() }

    val libretroBridge = LibretroBridge(context, systemDir, saveDir, audioPlayer, controllerState, _config.value)
    val demoGameEngine = PsxDemoGameEngine(audioPlayer, controllerState)
    val retroAchievements = com.example.psx.data.RetroAchievementsManager(context)

    private val _currentFrame = MutableStateFlow<Bitmap?>(null)
    val currentFrame: StateFlow<Bitmap?> = _currentFrame.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _isPaused = MutableStateFlow(false)
    val isPaused: StateFlow<Boolean> = _isPaused.asStateFlow()

    private val _fps = MutableStateFlow(60.0)
    val fps: StateFlow<Double> = _fps.asStateFlow()

    private val _currentGameTitle = MutableStateFlow<String?>("PlayStation 3D Tech Demo")
    val currentGameTitle: StateFlow<String?> = _currentGameTitle.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private var currentActiveGameFile: File? = null
    private var isUsingNativeCore = false

    private val isLoopRunning = AtomicBoolean(false)
    private var emulationThread: Thread? = null

    var currentSaveSlot: Int = 1

    // Hardware accelerated rendering via SurfaceView
    private var surfaceHolder: SurfaceHolder? = null
    private val renderPaint = Paint().apply {
        isFilterBitmap = true
        isDither = false
    }
    private val scanlinePaint = Paint().apply {
        color = android.graphics.Color.argb(45, 0, 0, 0)
        strokeWidth = 1.8f
    }
    private var frameSkipCounter = 0
    private val srcRect = Rect()
    private val dstRect = Rect()

    init {
        // Wire bridge video callback to direct SurfaceView renderer
        libretroBridge.onFrameRendered = { bmp ->
            renderFrame(bmp)
        }
    }

    fun setRenderSurface(holder: SurfaceHolder?) {
        surfaceHolder = holder
    }

    fun renderFrame(bmp: Bitmap) {
        val cfg = config
        if (cfg.frameSkip > 0) {
            frameSkipCounter++
            if (frameSkipCounter % (cfg.frameSkip + 1) != 0) {
                return
            }
        }

        val holder = surfaceHolder
        if (holder != null && holder.surface.isValid) {
            val canvas = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                try {
                    holder.lockHardwareCanvas()
                } catch (e: Exception) {
                    holder.lockCanvas()
                }
            } else {
                holder.lockCanvas()
            }

            if (canvas != null) {
                try {
                    val canvasW = canvas.width
                    val canvasH = canvas.height

                    val isWidescreen = cfg.isWidescreenHackEnabled ||
                        cfg.aspectRatio == AspectRatioMode.WIDESCREEN_16_9 ||
                        cfg.aspectRatio == AspectRatioMode.STRETCH_FULL

                    srcRect.set(0, 0, bmp.width, bmp.height)

                    if (cfg.aspectRatio == AspectRatioMode.STRETCH_FULL) {
                        dstRect.set(0, 0, canvasW, canvasH)
                    } else if (cfg.integerScaling || cfg.aspectRatio == AspectRatioMode.INTEGER_SCALE) {
                        val scale = minOf(canvasW / bmp.width, canvasH / bmp.height).coerceAtLeast(1)
                        val w = bmp.width * scale
                        val h = bmp.height * scale
                        val left = (canvasW - w) / 2
                        val top = (canvasH - h) / 2
                        dstRect.set(left, top, left + w, top + h)
                    } else if (isWidescreen) {
                        // 16:9 anamorphic presentation: fit a 16:9 rect, centered, no cropping
                        val targetRatio = 16.0f / 9.0f
                        val w: Int
                        val h: Int
                        if (canvasW.toFloat() / canvasH > targetRatio) {
                            h = canvasH; w = (h * targetRatio).toInt()
                        } else {
                            w = canvasW; h = (w / targetRatio).toInt()
                        }
                        val left = (canvasW - w) / 2
                        val top = if (canvasW > canvasH) (canvasH - h) / 2 else (canvasH * 0.05f).toInt()
                        dstRect.set(left, top, left + w, top + h)
                    } else {
                        // AUTO or ORIGINAL_4_3
                        val targetRatio = 4.0f / 3.0f
                        val screenRatio = canvasW.toFloat() / canvasH.toFloat()
                        val w: Int
                        val h: Int
                        if (screenRatio > targetRatio) {
                            h = canvasH
                            w = (h * targetRatio).toInt()
                        } else {
                            w = canvasW
                            h = (w / targetRatio).toInt()
                        }
                        val left = (canvasW - w) / 2
                        val top = if (canvasW > canvasH) (canvasH - h) / 2 else (canvasH * 0.05f).toInt()
                        dstRect.set(left, top, left + w, top + h)
                    }

                    // Authentic PS1 black background / pillarbox
                    if (dstRect.left > 0 || dstRect.top > 0 || dstRect.right < canvasW || dstRect.bottom < canvasH) {
                        canvas.drawColor(android.graphics.Color.BLACK)
                    }

                    renderPaint.isFilterBitmap = cfg.textureFiltering == TextureFiltering.SMOOTH
                    renderPaint.isDither = cfg.isDitheringEnabled
                    canvas.drawBitmap(bmp, srcRect, dstRect, renderPaint)

                    // CRT scanline filter
                    if (cfg.crtScanlines) {
                        var y = dstRect.top.toFloat()
                        val step = 3.2f
                        while (y < dstRect.bottom) {
                            canvas.drawLine(dstRect.left.toFloat(), y, dstRect.right.toFloat(), y, scanlinePaint)
                            y += step
                        }
                    }
                } finally {
                    holder.unlockCanvasAndPost(canvas)
                }
            }
        } else {
            _currentFrame.value = bmp
        }
    }

    fun startDemoGame() {
        stop()
        currentActiveGameFile = null
        isUsingNativeCore = false
        _currentGameTitle.value = "PlayStation 3D Tech Demo"
        _currentFrame.value = demoGameEngine.bitmap
        retroAchievements.loadAchievementsForGameAsync("PlayStation 3D Tech Demo")
        startLoop()
    }

    fun loadAndStartGame(gameFile: File): Boolean {
        stop()
        currentActiveGameFile = gameFile
        _currentGameTitle.value = gameFile.nameWithoutExtension
        retroAchievements.loadAchievementsForGameAsync(gameFile.nameWithoutExtension)

        // Track recently played game for dashboard shortcuts
        val filtered = config.recentGamePaths.filter { it != gameFile.absolutePath }
        val updatedRecent = listOf(gameFile.absolutePath) + filtered
        updateConfiguration(
            config.copy(
                lastPlayedGamePath = gameFile.absolutePath,
                recentGamePaths = updatedRecent.take(6)
            )
        )

        // Attempt native PCSX-ReARMed core
        val loadedCore = if (!libretroBridge.isInitialized) libretroBridge.loadCore() else true
        if (loadedCore) {
            val gameLoaded = libretroBridge.loadGame(gameFile)
            if (gameLoaded) {
                isUsingNativeCore = true
                _statusMessage.value = "Running with PCSX-ReARMed Native Core"
                startLoop()
                return true
            } else {
                val err = libretroBridge.lastErrorMessage ?: "Failed to open ${gameFile.name} in PCSX core"
                _statusMessage.value = err
                Log.e("PsxEmulatorEngine", err)
                return false
            }
        } else {
            val err = libretroBridge.lastErrorMessage ?: "PCSX native core could not be initialized"
            _statusMessage.value = err
            Log.e("PsxEmulatorEngine", err)
            return false
        }
    }

    private fun startLoop() {
        if (isLoopRunning.getAndSet(true)) return

        audioPlayer.start()
        _isPlaying.value = true
        _isPaused.value = false

        emulationThread = Thread({
            var lastFpsCalc = System.currentTimeMillis()
            var framesRendered = 0

            while (isLoopRunning.get()) {
                val loopStart = System.nanoTime()

                if (!_isPaused.value) {
                    if (isUsingNativeCore) {
                        libretroBridge.runFrame()
                    } else {
                        demoGameEngine.updateAndRender()
                        renderFrame(demoGameEngine.bitmap)
                    }
                    framesRendered++
                }

                // FPS calculation every 1000ms
                val nowMs = System.currentTimeMillis()
                if (nowMs - lastFpsCalc >= 1000) {
                    val currentCalculatedFps = (framesRendered * 1000.0) / (nowMs - lastFpsCalc)
                    _fps.value = (currentCalculatedFps * 10.0).toInt() / 10.0
                    framesRendered = 0
                    lastFpsCalc = nowMs
                }

                // Base target frame time calculated from native core FPS (59.94 NTSC or 50.0 PAL)
                val baseFps = if (isUsingNativeCore && libretroBridge.targetFps > 20.0) {
                    libretroBridge.targetFps
                } else {
                    TARGET_FPS_NTSC
                }
                val baseFrameTimeNs = (1_000_000_000.0 / baseFps).toLong()

                // Adaptive dynamic pacing driven by audio buffer state:
                // Prevents audio buffer overflow (robotic distortion/crackling) and underflow (audio cutouts)
                val bufferedSamples = audioPlayer.getBufferedCount()
                val audioPacingOffsetNs = if (!config.isFastForwardActive && isUsingNativeCore) {
                    when {
                        bufferedSamples > 4000 -> -350_000L // Audio buffer filling up; advance video frame pacing slightly
                        bufferedSamples > 2800 -> -150_000L
                        bufferedSamples < 800 -> +350_000L  // Audio buffer low; yield slightly to prevent underruns
                        bufferedSamples < 1500 -> +150_000L
                        else -> 0L
                    }
                } else {
                    0L
                }

                val targetFrameTime = if (config.isFastForwardActive) {
                    (baseFrameTimeNs / config.fastForwardSpeed).toLong()
                } else if (config.profile == PerformanceProfile.BATTERY_SAVER) {
                    (baseFrameTimeNs * 1.05).toLong()
                } else {
                    (baseFrameTimeNs + audioPacingOffsetNs).coerceAtLeast(5_000_000L)
                }

                val elapsedNs = System.nanoTime() - loopStart
                val sleepNs = targetFrameTime - elapsedNs
                if (sleepNs > 2_000_000L) {
                    java.util.concurrent.locks.LockSupport.parkNanos(sleepNs - 1_200_000L)
                }

                // Brief sub-millisecond settling without burning full CPU core
                while (System.nanoTime() - loopStart < targetFrameTime && isLoopRunning.get()) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        Thread.onSpinWait()
                    } else {
                        Thread.yield()
                    }
                }
            }
        }, "PsxEmulationWorkerThread").apply {
            priority = Thread.MAX_PRIORITY
            start()
        }
    }

    fun pause() {
        _isPaused.value = true
        audioPlayer.pause()
        demoGameEngine.isPaused = true
    }

    fun resume() {
        _isPaused.value = false
        audioPlayer.start()
        demoGameEngine.isPaused = false
    }

    fun togglePause() {
        if (_isPaused.value) resume() else pause()
    }

    fun reset() {
        if (isUsingNativeCore) {
            libretroBridge.reset()
        } else {
            demoGameEngine.updateAndRender()
        }
        _statusMessage.value = "Emulation Reset"
    }

    fun quickSave(): Boolean {
        return saveSlot(currentSaveSlot)
    }

    fun quickLoad(): Boolean {
        return loadSlot(currentSaveSlot)
    }

    fun saveSlot(slot: Int): Boolean {
        currentSaveSlot = slot
        val gamePrefix = currentActiveGameFile?.nameWithoutExtension ?: "demo"
        val stateFile = File(saveDir, "${gamePrefix}_slot$slot.state")

        val wasPaused = _isPaused.value
        if (!wasPaused) {
            audioPlayer.pause()
        }

        val success = if (isUsingNativeCore) {
            libretroBridge.saveState(stateFile)
        } else {
            demoGameEngine.saveMemoryCard(stateFile)
        }

        if (!wasPaused) {
            audioPlayer.start()
        }

        _statusMessage.value = if (success) "Saved to Slot $slot" else "Failed to save state"
        return success
    }

    fun loadSlot(slot: Int): Boolean {
        currentSaveSlot = slot
        val gamePrefix = currentActiveGameFile?.nameWithoutExtension ?: "demo"
        val stateFile = File(saveDir, "${gamePrefix}_slot$slot.state")
        if (!stateFile.exists() || stateFile.length() <= 0) {
            _statusMessage.value = "Slot $slot is empty"
            return false
        }

        val wasPaused = _isPaused.value
        if (!wasPaused) {
            audioPlayer.pause()
        }

        val success = if (isUsingNativeCore) {
            libretroBridge.loadState(stateFile)
        } else {
            demoGameEngine.loadMemoryCard(stateFile)
        }

        if (!wasPaused) {
            audioPlayer.start()
        }

        _statusMessage.value = if (success) "Loaded Slot $slot" else "Failed to load state"
        return success
    }

    fun stop() {
        isLoopRunning.set(false)
        emulationThread?.interrupt()
        try {
            emulationThread?.join(500)
        } catch (e: Exception) {
            // Ignore
        }
        emulationThread = null
        audioPlayer.pause()
        if (isUsingNativeCore) {
            libretroBridge.unloadGame()
        }
        _isPlaying.value = false
        _isPaused.value = false
    }

    fun release() {
        stop()
        audioPlayer.release()
        libretroBridge.shutdown()
        controllerState.reset()
    }
}
