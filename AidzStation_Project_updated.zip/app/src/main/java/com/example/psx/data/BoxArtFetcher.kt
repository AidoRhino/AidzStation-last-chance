package com.example.psx.data

import android.content.Context
import android.net.Uri
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.BufferedReader
import java.io.File
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

object BoxArtFetcher {
    private const val TAG = "BoxArtFetcher"
    private const val LIBRETRO_RAW_URL = "https://raw.githubusercontent.com/libretro-thumbnails/Sony_-_PlayStation/master/Named_Boxarts"

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    // In-memory cache of all 9,301 official Libretro PS1 box art filenames
    private var cachedIndex: List<String>? = null

    fun getCoverDir(context: Context): File {
        return File(context.filesDir, "covers").apply { mkdirs() }
    }

    /**
     * Retrieves cached cover. Automatically purges corrupt or 0-byte placeholders
     * (< 2 KB) so valid covers can be downloaded.
     */
    fun getCachedCover(context: Context, gameId: String): File? {
        val safeName = Math.abs(gameId.hashCode()).toString() + ".png"
        val file = File(getCoverDir(context), safeName)
        if (file.exists() && file.length() < 512) {
            file.delete()
            return null
        }
        return if (file.exists() && file.length() >= 512) file else null
    }

    /**
     * Loads the bundled index of official PS1 box art filenames from assets.
     */
    private fun getOrLoadIndex(context: Context): List<String> {
        cachedIndex?.let { return it }

        val list = mutableListOf<String>()
        try {
            context.assets.open("ps1_boxart_index.txt").use { stream ->
                BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).useLines { lines ->
                    lines.forEach { line ->
                        val trimmed = line.trim()
                        if (trimmed.isNotEmpty()) {
                            list.add(trimmed)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not load ps1_boxart_index.txt from assets: ${e.message}")
        }
        cachedIndex = list
        return list
    }

    /**
     * Tokenize string for fuzzy title matching (handles Roman numerals, etc.)
     */
    private fun tokenize(s: String): Set<String> {
        var clean = s.lowercase()
        clean = clean.replace(Regex("\\bvii\\b"), "7")
        clean = clean.replace(Regex("\\bviii\\b"), "8")
        clean = clean.replace(Regex("\\bix\\b"), "9")
        clean = clean.replace(Regex("\\biv\\b"), "4")
        clean = clean.replace(Regex("\\bvi\\b"), "6")
        clean = clean.replace(Regex("\\biii\\b"), "3")
        clean = clean.replace(Regex("\\bii\\b"), "2")
        return Regex("[a-z0-9]+").findAll(clean).map { it.value }.toSet()
    }

    /**
     * Finds the exact matching official Libretro box art filename for a game title,
     * with robust multi-disc handling (e.g. "Final Fantasy IX Disc 1" -> "Final Fantasy IX (USA) (Disc 1).png").
     */
    fun findBestMatchingFilename(context: Context, rawTitle: String): String? {
        val titles = getOrLoadIndex(context)

        // 1. Strip file extension and brackets
        var q = rawTitle.trim()
        q = q.replace(Regex("\\.(cue|bin|iso|chd|pbp|m3u|img)$", RegexOption.IGNORE_CASE), "").trim()

        // Exact match with .png
        val exactName = "$q.png"
        for (t in titles) {
            if (t.equals(exactName, ignoreCase = true)) return t
        }

        // 2. Extract disc number if present ("Disc 1", "disc 2", etc.)
        val discMatch = Regex("(?i)\\bdisc\\s*(\\d+)\\b").find(q)
        val discNumber = discMatch?.groupValues?.getOrNull(1)

        // 3. Clean normalized query: strip disc tags, [tags], (tags), underscores
        var cleanQ = q
            .replace(Regex("(?i)\\bdisc\\s*\\d+\\b"), "")
            .replace(Regex("\\[.*?\\]"), "")
            .replace(Regex("(?i)\\(track\\s*\\d+\\)"), "")
            .replace(Regex("(?i)\\((usa|europe|japan|en|fr|de|es|it)\\)"), "")
            .replace(Regex("\\(.*?\\)"), "")
            .replace("_", " ")
            .replace(":", " - ")
            .replace(Regex("\\s+"), " ")
            .trim()

        val preferredRegions = listOf(
            "(USA)",
            "(Europe)",
            "(Japan)",
            "(Europe, Australia)",
            "(USA) (Disc 1)",
            "(Europe) (Disc 1)",
            "(Europe) (En,Fr,De,Es,It)"
        )

        // 4. If disc number was present, try region + disc forms first
        if (discNumber != null) {
            val discRegions = listOf(
                "(USA) (Disc $discNumber)",
                "(Europe) (Disc $discNumber)",
                "(Japan) (Disc $discNumber)",
                "(Europe, Australia) (Disc $discNumber)"
            )
            for (dr in discRegions) {
                val target = "$cleanQ $dr.png"
                for (t in titles) {
                    if (t.equals(target, ignoreCase = true)) return t
                }
            }
        }

        // 5. Try standard region-appended forms
        for (reg in preferredRegions) {
            val target = "$cleanQ $reg.png"
            for (t in titles) {
                if (t.equals(target, ignoreCase = true)) return t
            }
        }

        // 6. Try prefix match (e.g. "Crash Bandicoot - Warped" for "Crash Bandicoot 3")
        val prefix = "$cleanQ ".lowercase()
        for (reg in preferredRegions) {
            for (t in titles) {
                val tl = t.lowercase()
                if (tl.startsWith(prefix) && tl.contains(reg.lowercase())) {
                    return t
                }
            }
        }

        // 7. Token-based matching (handles subtitle variations, Roman numerals, apostrophes)
        val queryTokens = tokenize(cleanQ)
        if (queryTokens.isNotEmpty()) {
            var bestMatch: String? = null
            var bestScore = 0.0

            for (t in titles) {
                val cTokens = tokenize(t)
                val cFiltered = cTokens.filter { it !in setOf("usa", "europe", "japan", "disc", "demo", "edc", "png", "rev") }
                if (cFiltered.isEmpty()) continue

                val common = queryTokens.intersect(cFiltered.toSet())
                var score = common.size.toDouble() / queryTokens.size.toDouble()

                if (cTokens.contains("usa")) score += 0.05
                else if (cTokens.contains("europe")) score += 0.03

                if (score > bestScore) {
                    bestScore = score
                    bestMatch = t
                }
            }

            if (bestScore >= 0.70 && bestMatch != null) {
                return bestMatch
            }
        }

        return null
    }

    /**
     * Automatically fetches official PS1 box art from the internet and caches it.
     */
    suspend fun fetchBoxArt(context: Context, gameId: String, gameTitle: String): String? = withContext(Dispatchers.IO) {
        val cached = getCachedCover(context, gameId)
        if (cached != null) return@withContext cached.absolutePath

        val matchedFilename = findBestMatchingFilename(context, gameTitle)
        Log.i(TAG, "Search for '$gameTitle' matched official boxart: $matchedFilename")

        val targetFile = File(getCoverDir(context), "${Math.abs(gameId.hashCode())}.png")

        if (matchedFilename != null) {
            val encoded = URLEncoder.encode(matchedFilename, "UTF-8").replace("+", "%20")
            val url = "$LIBRETRO_RAW_URL/$encoded"
            if (downloadAndSaveImage(url, targetFile)) {
                return@withContext targetFile.absolutePath
            }
        }

        // Direct candidate fallbacks if index lookup didn't succeed
        val clean = gameTitle
            .replace(Regex("(?i)\\bdisc\\s*\\d+\\b"), "")
            .replace(Regex("\\.(cue|bin|iso|chd|pbp|m3u|img)$", RegexOption.IGNORE_CASE), "")
            .replace(Regex("\\[.*?\\]"), "")
            .replace(Regex("\\(.*?\\)"), "")
            .replace("_", " ")
            .trim()

        val directCandidates = listOf(
            "$clean (USA).png",
            "$clean (Europe).png",
            "$clean (Japan).png",
            "$clean.png"
        )

        for (candidate in directCandidates) {
            val encoded = URLEncoder.encode(candidate, "UTF-8").replace("+", "%20")
            val url = "$LIBRETRO_RAW_URL/$encoded"
            if (downloadAndSaveImage(url, targetFile)) {
                return@withContext targetFile.absolutePath
            }
        }

        null
    }

    private fun downloadAndSaveImage(url: String, targetFile: File): Boolean {
        return try {
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "AidzStation-PSX/1.0")
                .build()

            httpClient.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body
                    if (body != null) {
                        val tempFile = File(targetFile.parentFile, targetFile.name + ".tmp")
                        FileOutputStream(tempFile).use { out ->
                            body.byteStream().copyTo(out)
                        }
                        // Validate image length: Real PS1 covers are at least 2KB
                        if (tempFile.length() >= 2048) {
                            if (targetFile.exists()) targetFile.delete()
                            tempFile.renameTo(targetFile)
                            Log.i(TAG, "Downloaded box art from $url (size=${targetFile.length()} bytes)")
                            return true
                        } else {
                            tempFile.delete()
                        }
                    }
                }
            }
            false
        } catch (e: Exception) {
            Log.w(TAG, "Download error for $url: ${e.message}")
            false
        }
    }

    suspend fun saveCustomCover(context: Context, gameId: String, imageUri: Uri): String? = withContext(Dispatchers.IO) {
        try {
            val targetFile = File(getCoverDir(context), "${Math.abs(gameId.hashCode())}.png")
            val bitmap = context.contentResolver.openInputStream(imageUri)?.use { input ->
                android.graphics.BitmapFactory.decodeStream(input)
            }
            if (bitmap != null) {
                FileOutputStream(targetFile).use { out ->
                    bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 95, out)
                }
                bitmap.recycle()
                if (targetFile.exists() && targetFile.length() >= 512) {
                    return@withContext targetFile.absolutePath
                }
            } else {
                // Direct stream copy fallback
                context.contentResolver.openInputStream(imageUri)?.use { input ->
                    FileOutputStream(targetFile).use { output ->
                        input.copyTo(output)
                    }
                }
                if (targetFile.exists() && targetFile.length() >= 512) {
                    return@withContext targetFile.absolutePath
                }
            }
            null
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save custom cover: ${e.message}", e)
            null
        }
    }

    suspend fun saveCustomCoverFromUrl(context: Context, gameId: String, imageUrl: String): String? = withContext(Dispatchers.IO) {
        try {
            val targetFile = File(getCoverDir(context), "${Math.abs(gameId.hashCode())}.png")
            if (downloadAndSaveImage(imageUrl, targetFile)) {
                targetFile.absolutePath
            } else {
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save cover from URL: ${e.message}")
            null
        }
    }
}
