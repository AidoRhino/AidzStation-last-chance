package com.example

import android.os.Bundle
import android.view.KeyEvent
import android.view.MotionEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.example.psx.core.PsxEmulatorEngine
import com.example.psx.data.BiosManager
import com.example.psx.data.GameItem
import com.example.psx.data.GameRepository
import com.example.psx.data.MemoryCardManager
import com.example.psx.ui.components.PlayStationPatternBackground
import com.example.psx.ui.screens.*
import com.example.psx.ui.theme.PlayStationTheme
import com.example.psx.ui.theme.PsxNearBlack
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

enum class PsxScreen {
    BOOT_SEQUENCE,
    DASHBOARD,
    GAME_LIBRARY,
    EMULATION,
    BIOS_MANAGER,
    MEMORY_CARDS,
    SETTINGS,
    SETUP_WIZARD,
    EDIT_CONTROLS
}

class MainActivity : ComponentActivity() {
    private lateinit var engine: PsxEmulatorEngine
    private lateinit var repository: GameRepository
    private lateinit var biosManager: BiosManager
    private lateinit var memoryCardManager: MemoryCardManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        applyFullScreenMode()

        engine = PsxEmulatorEngine(this)
        repository = GameRepository(this)
        biosManager = BiosManager(this)
        memoryCardManager = MemoryCardManager(this)

        // Preload and cache games in background for instant startup
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                repository.refreshGameLibrary()
            } catch (_: Exception) {}
        }

        setContent {
            PlayStationTheme(darkTheme = true) {
                val initialScreen = remember {
                    if (engine.config.fastBoot) PsxScreen.DASHBOARD else PsxScreen.BOOT_SEQUENCE
                }
                var currentScreen by remember { mutableStateOf(initialScreen) }
                var launchErrorMessage by remember { mutableStateOf<String?>(null) }
                val isPlaying by engine.isPlaying.collectAsStateWithLifecycle()

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = androidx.compose.ui.graphics.Color.Transparent
                ) { innerPadding ->
                    PlayStationPatternBackground(
                        modifier = Modifier.fillMaxSize()
                    ) {
                        when (currentScreen) {
                            PsxScreen.BOOT_SEQUENCE -> {
                                Ps1BootSequenceScreen(
                                    onFinished = {
                                        currentScreen = PsxScreen.DASHBOARD
                                    }
                                )
                            }
                            PsxScreen.DASHBOARD -> {
                                DashboardScreen(
                                    engine = engine,
                                    repository = repository,
                                    biosManager = biosManager,
                                    onLaunchGame = { game ->
                                        if (game.isBuiltIn || game.file == null) {
                                            engine.startDemoGame()
                                            currentScreen = PsxScreen.EMULATION
                                        } else {
                                            val ok = engine.loadAndStartGame(game.file)
                                            if (ok) {
                                                launchErrorMessage = null
                                                currentScreen = PsxScreen.EMULATION
                                            } else {
                                                launchErrorMessage = engine.statusMessage.value ?: "Could not boot ${game.title}"
                                                currentScreen = PsxScreen.GAME_LIBRARY
                                            }
                                        }
                                    },
                                    onNavigateToLibrary = { currentScreen = PsxScreen.GAME_LIBRARY },
                                    onNavigateToBios = { currentScreen = PsxScreen.BIOS_MANAGER },
                                    onNavigateToMemoryCard = { currentScreen = PsxScreen.MEMORY_CARDS },
                                    onNavigateToSettings = { currentScreen = PsxScreen.SETTINGS },
                                    onNavigateToWizard = { currentScreen = PsxScreen.SETUP_WIZARD },
                                    onNavigateToEditControls = { currentScreen = PsxScreen.EDIT_CONTROLS }
                                )
                            }
                            PsxScreen.GAME_LIBRARY -> {
                                GameLibraryScreen(
                                    repository = repository,
                                    onLaunchGame = { game ->
                                        if (game.isBuiltIn || game.file == null) {
                                            engine.startDemoGame()
                                            currentScreen = PsxScreen.EMULATION
                                        } else {
                                            val ok = engine.loadAndStartGame(game.file)
                                            if (ok) {
                                                launchErrorMessage = null
                                                currentScreen = PsxScreen.EMULATION
                                            } else {
                                                launchErrorMessage = engine.statusMessage.value ?: "Could not boot ${game.title}"
                                            }
                                        }
                                    },
                                    errorMessage = launchErrorMessage,
                                    onDismissError = { launchErrorMessage = null },
                                    onBack = { currentScreen = PsxScreen.DASHBOARD },
                                    onNavigateSettings = { currentScreen = PsxScreen.SETTINGS },
                                    onNavigateControls = { currentScreen = PsxScreen.EDIT_CONTROLS },
                                    onNavigateMemoryCards = { currentScreen = PsxScreen.MEMORY_CARDS }
                                )
                            }
                            PsxScreen.EMULATION -> {
                                EmulationScreen(
                                    engine = engine,
                                    onExitGame = {
                                        currentScreen = PsxScreen.DASHBOARD
                                    }
                                )
                            }
                            PsxScreen.BIOS_MANAGER -> {
                                BiosScreen(
                                    biosManager = biosManager,
                                    onBack = { currentScreen = PsxScreen.DASHBOARD }
                                )
                            }
                            PsxScreen.MEMORY_CARDS -> {
                                MemoryCardScreen(
                                    memoryCardManager = memoryCardManager,
                                    onBack = { currentScreen = PsxScreen.DASHBOARD }
                                )
                            }
                            PsxScreen.SETTINGS -> {
                                SettingsScreen(
                                    engine = engine,
                                    onBack = { currentScreen = PsxScreen.DASHBOARD },
                                    onNavigateToEditControls = { currentScreen = PsxScreen.EDIT_CONTROLS }
                                )
                            }
                            PsxScreen.EDIT_CONTROLS -> {
                                EditControlsLayoutScreen(
                                    onDismiss = { currentScreen = PsxScreen.DASHBOARD }
                                )
                            }
                            PsxScreen.SETUP_WIZARD -> {
                                SetupWizardScreen(
                                    engine = engine,
                                    biosManager = biosManager,
                                    onComplete = { currentScreen = PsxScreen.DASHBOARD }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        applyFullScreenMode()
    }

    private fun applyFullScreenMode() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val insetsController = WindowCompat.getInsetsController(window, window.decorView)
        insetsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        insetsController.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (::engine.isInitialized && engine.controllerState.onKeyDown(keyCode)) {
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        if (::engine.isInitialized && engine.controllerState.onKeyUp(keyCode)) {
            return true
        }
        return super.onKeyUp(keyCode, event)
    }

    override fun onGenericMotionEvent(event: MotionEvent?): Boolean {
        if (::engine.isInitialized && event != null && engine.controllerState.onGenericMotionEvent(event)) {
            return true
        }
        return super.onGenericMotionEvent(event)
    }
}
