package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val PsxDarkColorScheme = darkColorScheme(
    primary = PsxCrossBlue,
    onPrimary = Color.White,
    primaryContainer = PsxCardElevated,
    onPrimaryContainer = PsxTextPrimary,
    secondary = PsxTriangleGreen,
    onSecondary = Color.Black,
    secondaryContainer = PsxCardSurface,
    onSecondaryContainer = PsxTextPrimary,
    tertiary = PsxCircleRed,
    onTertiary = Color.White,
    background = PsxNearBlack,
    onBackground = PsxTextPrimary,
    surface = PsxSurfaceDark,
    onSurface = PsxTextPrimary,
    surfaceVariant = PsxCardSurface,
    onSurfaceVariant = PsxTextSecondary,
    outline = PsxConsoleGrey.copy(alpha = 0.5f),
    outlineVariant = PsxDarkCharcoal
)

private val PsxLightColorScheme = lightColorScheme(
    primary = PsxCrossBlue,
    onPrimary = Color.White,
    primaryContainer = PsxLightGrey.copy(alpha = 0.3f),
    onPrimaryContainer = PsxNearBlack,
    secondary = PsxTriangleGreen,
    onSecondary = Color.Black,
    tertiary = PsxCircleRed,
    onTertiary = Color.White,
    background = Color(0xFFE2E4E8),
    onBackground = PsxNearBlack,
    surface = Color(0xFFECEEF2),
    onSurface = PsxNearBlack,
    surfaceVariant = PsxLightGrey,
    onSurfaceVariant = PsxDarkCharcoal,
    outline = PsxConsoleGrey
)

@Composable
fun PlayStationTheme(
    darkTheme: Boolean = true, // Default to iconic console dark styling
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) PsxDarkColorScheme else PsxLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

// Backwards compatibility alias
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    PlayStationTheme(darkTheme = true, content = content)
}
