package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Authentic Original PlayStation Palette (1994 Hardware Aesthetic)
val PsxConsoleGrey = Color(0xFF8B8B8B)
val PsxLightGrey = Color(0xFFB0B0B0)
val PsxDarkCharcoal = Color(0xFF222428)
val PsxNearBlack = Color(0xFF141518)
val PsxSurfaceDark = Color(0xFF1C1E22)
val PsxCardSurface = Color(0xFF2B2D33)
val PsxCardElevated = Color(0xFF373A42)

// Iconic Four Button Colors & PS Heritage Accents
val PsxCrossBlue = Color(0xFF2979FF)
val PsxCircleRed = Color(0xFFFF1744)
val PsxSquarePink = Color(0xFFFF4081)
val PsxTriangleGreen = Color(0xFF00E676)
val PsxYellowAccent = Color(0xFFFFD600)

val PsxTextPrimary = Color(0xFFF0F2F5)
val PsxTextSecondary = Color(0xFFA0A5B0)
val PsxTextDisabled = Color(0xFF656A75)
