package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.psx.core.AspectRatioMode
import com.example.psx.core.PerformanceProfile
import com.example.psx.core.PsxConfiguration
import com.example.psx.data.BiosManager
import com.example.psx.data.GameRepository
import com.example.psx.data.MemoryCardManager
import com.example.psx.input.ControllerState
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `verify app name resource`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("PlayStation Retro", appName)
    }

    @Test
    fun `verify game repository built-in demo game`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = GameRepository(context)
        val games = repo.games.value
        assertTrue("Game library must contain at least the built-in PS1 demo", games.isNotEmpty())
        assertEquals("PlayStation 3D Polygonal & SPU Demo", games.first().title)
    }

    @Test
    fun `verify bios manager detects definitions`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val biosManager = BiosManager(context)
        val list = biosManager.getDetectedBiosList()
        assertTrue("Bios manager must list recognized official BIOS models", list.size >= 5)
        assertTrue(list.any { it.fileName.contains("scph1001", ignoreCase = true) })
    }

    @Test
    fun `verify memory cards are initialized with 128KB`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val memCardManager = MemoryCardManager(context)
        assertEquals(131072L, memCardManager.card1File.length())
        assertEquals(131072L, memCardManager.card2File.length())
        val blocks = memCardManager.getMemoryCardBlocks(1)
        assertEquals(15, blocks.size)
    }

    @Test
    fun `verify controller state mapping`() {
        val state = ControllerState()
        state.cross = true
        state.triangle = true
        assertEquals(1.toShort(), state.getButtonState(com.example.psx.core.LibretroDefs.RETRO_DEVICE_ID_JOYPAD_B))
        assertEquals(1.toShort(), state.getButtonState(com.example.psx.core.LibretroDefs.RETRO_DEVICE_ID_JOYPAD_X))
        assertEquals(0.toShort(), state.getButtonState(com.example.psx.core.LibretroDefs.RETRO_DEVICE_ID_JOYPAD_START))
    }

    @Test
    fun `verify configuration persistence`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val config = PsxConfiguration(
            profile = PerformanceProfile.ENHANCED,
            aspectRatio = AspectRatioMode.WIDESCREEN_16_9,
            internalResolutionScale = 2
        )
        PsxConfiguration.save(context, config)
        val loaded = PsxConfiguration.load(context)
        assertEquals(PerformanceProfile.ENHANCED, loaded.profile)
        assertEquals(AspectRatioMode.WIDESCREEN_16_9, loaded.aspectRatio)
        assertEquals(2, loaded.internalResolutionScale)
    }
}
